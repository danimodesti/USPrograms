from apex import Apex
from math import inf 

def get_valued_graph_data():
    # Obtenha nome do arquivo com o grafo a ser aberto
    file_name = input()

    # Ler info do pajek ---
    # Retirar info da qtd de vertices do grafo para fazer lista de adjacencia
    file = open(file_name, "r")
    
    if not file:
        print("Arquivo nao encontrado! =(")

    # Ler info do pajek ---
    # Retirar info da qtd de vertices do grafo para fazer lista de adjacencia
    for line in file.readlines():
        if line.startswith("*Vertices"):
            apex_amt = int(line.split()[-1]) # Obter apenas um elemento da lista, o ultimo
            
            # Criando lista com cada um dos vertices como elemento ---
            graph_apexes = list(range(apex_amt)) # Vertices do grafo, contando a partir de 0 (v1 = 0)
            
            # Criando lista com cada uma das arestas do grafo como elemento ---
            graph_edges = []
        # O grafo eh dirigido ou nao? Checa aqui ---
        elif line.startswith("*Edges"):
            is_directed = False
        elif line.startswith("*Arcs"):
            is_directed = True
        elif len(line.strip()) == 0:
            continue
        else:
            # Informacoes da linha para esse ex.: vertices que fazem aresta e o valor da aresta
            line = line.strip()

            graph_edges.append(line) # Arestas do grafo + valor da aresta
        
    return [apex_amt, graph_apexes, graph_edges, is_directed]

# Esta funcao considera que o grafo eh valorado para o tratamento dos dados
def create_adjacency_list(graph_info):
    apex_amt = graph_info[0]
    graph_apexes = graph_info[1]
    graph_edges = graph_info[2] # Guarda os vertices que formam aresta + o valor de cada aresta
    is_directed = graph_info[3]

    # Fazendo a lista de adjacencia ---
    # Criando lista de listas (cada vertice tem sua lista dos outros vertices com os 
    # quais faz uma aresta)
    adjacency_list = [] # Mostra as arestas entre o vertice representado pelo indice
                        # e cada elemento apontado por ele
    
    # Criando slots para cada vertice para poder inserir suas conexoes/arestas reciprocas
    for i in range(apex_amt):
        adjacency_list.append([])
    
    for edge in graph_edges:
        edge_info = edge.split() # Contem os vertices que fazem aresta + o valor da aresta entre eles formada
        
        # Armazena o segundo vertice no indice do primeiro + o valor da aresta
        # Exemplo de uso: se temos 6 1 1913 como edge_info, no indice 5 da lista tera
        # uma sublista contendo 0 (representa vertice 1) como o vertice que se conecta ao 6 
        # e o 1913 como o peso da aresta, ficando no indice 5: [0, 1913].
        apex_and_value = []
        apex_and_value.append(graph_apexes[int(edge_info[1]) - 1])
        apex_and_value.append(int(edge_info[2]))
        adjacency_list[int(edge_info[0]) - 1].append(apex_and_value)

        # Fazer valer 'simetria' (se vi se liga a vj, vj se liga a vi) --> SE NAO DIRIGIDO
        if not is_directed:
            apex_and_value[0] = graph_apexes[int(edge_info[0]) - 1]
            adjacency_list[int(edge_info[1]) - 1].append(apex_and_value)

    return adjacency_list

# Seguindo algoritmo em slide de aula, passando o grafo e o vertice inicial para busca
def breadth_first_search(root_apex, adjacency_list):
    # Busca em Largura a partir do vertice root_apex ---
    # O algoritmo retorna as distancias entre esse vertice e todos os outros do grafo
    root_distance = [None] * len(adjacency_list) # Inicializando distancias

    # Criando listas de controle:
    # - a cinza guarda os vertices atualmente percorridos
    # - a preta guarda os vertices ja utilizados
    # - a branca guarda os vertices nao utilizados/nao percorridos
    grey_queue = []
    grey_queue.append(root_apex) # Comecamos percorrendo o vertice passado por argumento
    black_list = []
    white_list = list(range(len(adjacency_list)))

    root_distance[root_apex] = 0 # A distancia do vertice ate si mesmo eh nula
    white_list.remove(root_apex)
    while len(grey_queue) > 0: # Enquanto fila nao for vazia
        curr_bfs_apex = grey_queue.pop(0)
        black_list.append(curr_bfs_apex)
        # Criar copia da lista de adjacencia apenas com os vertices que interessam (que fazem aresta com o atual)
        make_edge = list(adjacency_list[curr_bfs_apex]) # Estes vertices se conectam ao vertice
                                                        # percorrido atualmente
        # Enquanto ainda houver vertices conectados ao atualmente percorrido
        for edge in make_edge:
            if edge in white_list:
                white_list.remove(edge)
                root_distance[edge] = root_distance[curr_bfs_apex] + 1
                grey_queue.append(edge) # Rotular como cinza

    return root_distance # Retornando o vetor de distancias em relacao a raiz da bfs

def depth_first_search(adjacency_list: list, chosen_apex: Apex, previous: Apex, has_cicle: list, comp_apex_amt, compon):
    # Funcao das cores dos vertices:
    # - cinza -> vertices descobertos pela primeira vez
    # - preto -> vertices aos quais todos os v. adjacentes a ele ja sao descobertos
    # - branco -> vertices nao utilizados/nao percorridos (inicializacao dos v.)

    # Vertice percorrido agora --- 
    chosen_apex.set_apex_as_gray() # Comecamos percorrendo o vertice passado por argumento
    comp_apex_amt[compon] += 1

    # Enquanto ainda houver vertices conectados ao atualmente percorrido
    for apex in adjacency_list[chosen_apex.value]:
        if apex.color == "white":
            # Pilha via recursao
            depth_first_search(adjacency_list, apex, chosen_apex, has_cicle, comp_apex_amt, compon)
        elif apex.color == "gray" and previous and previous.value != apex.value: # tem aresta de retorno
            has_cicle[0] = True

    # Terminou de usar o vertice v escolhido
    chosen_apex.set_apex_as_black() # Vertice finalizado ---

def print_graph_info(graph_info):
    apex_amt = graph_info[0]
    graph_apexes = graph_info[1]
    graph_edges = graph_info[2]

    print(f"Vertices do grafo (lembrando que conta a partir do 0, entao v1 = 0):")

    for apex in graph_apexes:
        print(apex)

    print(f"Arestas do grafo: {graph_edges}\n")

def print_adjacency_list(adjacency_list):
    i = 0
    for list in adjacency_list:
        print(i)
        for item in list:
            print(f"\t{item}")
        i += 1

def print_bfs_info(root_distance, grey_queue, black_list, white_list):
    print(f"Root distance: {root_distance}")
    print(f"Fila cinza: {grey_queue}")
    print(f"Lista preta: {black_list}")
    print(f"Lista branca: {white_list}")

# Para buscar componentes conexas
def has_white_apexes(graph_info):
    for apex in graph_info[1]: # Procurar em todos os vertices do grafo
        if apex.color == "white":
            return apex

    return None # Ja terminaram as componentes do grafo para percorrer


def dijkstra_minimum_way(root_apex, adjacency_list):
    src_dist = [inf] * len(adjacency_list) # Inicializando distancias em relacao ao vertice de origem
    src_dist[root_apex] = 0 # Nao ha distancia entre o vertice e ele mesmo

    # Conjunto S com vertices com caminhos minimos desde a origem ja definidos
    already_done_apexes = [] # Nenhum vertice foi percorrido ainda

    priority_queue = list(range(len(adjacency_list))) # Contem os vertices do grafo
    
    # O vertice de inicio deve estar no comeco da lista (eh o vertice de menor estimativa de cam. minimo)
    priority_queue.remove(root_apex)
    priority_queue.insert(0, root_apex)    

    curr_apex = priority_queue.pop(0)

    while len(priority_queue) > 0:
        already_done_apexes.append(curr_apex)

        for connection in adjacency_list[curr_apex]: # Acessar as conexoes/arestas feitas pelo vertice atual
            # Teste de relaxamento --- 
            if src_dist[connection[0]] > float(src_dist[curr_apex]) + float(connection[1]):
                if connection[0] != root_apex:
                    src_dist[connection[0]] = src_dist[curr_apex] + connection[1]

        # Atualize fila de prioridade, se necessario
        # Se a distancia agora for menor que a que esta no topo
        closest_apex = priority_queue[0]
        for i in range(1, len(priority_queue)):
            if src_dist[priority_queue[i]] < src_dist[closest_apex]:
                closest_apex = priority_queue[i]

        if closest_apex != priority_queue[0]:
            priority_queue.remove(closest_apex)
            priority_queue.insert(0, closest_apex)

        curr_apex = priority_queue.pop(0)

    return src_dist