#
# Danielle Modesti — 12543544
# Grafos — 3o semestre — Professor Kuruvilla
# 01/07/2022
#

from graph import *

def main():
    graph_info = get_valued_graph_data()
    adjacency_list = create_adjacency_list(graph_info)

    apex_amt = len(adjacency_list)

    my_matrix = []

    columns_len = [1] * apex_amt

    for apex in range(apex_amt):
        # Para achar caminho mais curto de origem unica (vertice de origem eh enviado a funcao).
        # Retorna vetor de distancias para cada um dos vertices em relacao ao vertice de origem
        distances_from_apex = dijkstra_minimum_way(apex, adjacency_list)

        # Aqui, calcula-se a maior qtd de espacos necessarios para cada coluna de numeros,
        # em columns_len
        counter = 0
        for number in distances_from_apex:
            if len(str(number)) > columns_len[counter]:
                columns_len[counter] = len(str(number))
            counter += 1
        
        my_matrix.append(distances_from_apex)

    for line in my_matrix:
        counter = 0
        for number in line:
            if len(str(number)) < columns_len[counter]:
                space_amt = columns_len[counter] - len(str(number))
            
                for space in range(space_amt):
                    print(" ", end="")
            print(number, end=" ")
            counter += 1
        print()


if __name__ == "__main__":
    main()