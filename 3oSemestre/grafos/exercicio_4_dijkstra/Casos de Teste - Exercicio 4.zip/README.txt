Arquivo zip gerado em: 28/10/2023 19:44:59 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Exercício 4