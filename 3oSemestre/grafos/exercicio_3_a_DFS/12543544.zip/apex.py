class Apex:
    def __init__(self, value):
        self._value = value # Numero do vertice
        self._color = "white" 

    @property
    def value(self):
        return self._value

    @value.getter
    def value(self):
        return self._value

    @property
    def color(self):
        return self._color

    @color.getter
    def color(self):
        return self._color

    def set_apex_as_gray(self):
        self._color = "gray"

    def set_apex_as_black(self):
        self._color = "black"

    def __str__(self):
        return f"Vertice {self.value} - cor {self._color}"