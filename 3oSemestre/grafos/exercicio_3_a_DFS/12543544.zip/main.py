#
# Danielle Modesti — 12543544
# Grafos — 3o semestre — Professor Kuruvilla
# 15/06/2022
#

from graph import *

def main():
    graph_info = get_graph_data()
    adjacency_list = create_adjacency_list(graph_info)

    # Passar vertice de origem e anterior a ele (para comecar, nao eh nenhum vertice)
    has_cicle = [False] # Serve para a DFS

    # Vertice ainda nao percorrido, o qual inicia novo componente conexo
    apex_to_research = has_white_apexes(graph_info)
    component_amt = 0
    component_apex_amt = []
    while apex_to_research:
        component_amt += 1
        component_apex_amt.append(0) # Nenhum vertice nessa componente no momento
        depth_first_search(adjacency_list, apex_to_research, None, has_cicle, component_apex_amt, component_amt - 1)
        apex_to_research = has_white_apexes(graph_info)

    print(component_amt)
    for component in sorted(component_apex_amt, reverse=True):
        print(component)

if __name__ == "__main__":
    main()