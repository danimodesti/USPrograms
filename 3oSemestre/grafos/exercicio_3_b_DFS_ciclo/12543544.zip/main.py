#
# Danielle Modesti — 12543544
# Grafos — 3o semestre — Professor Kuruvilla
# 15/06/2022
#

from graph import *

def main():
    graph_info = get_graph_data()
    adjacency_list = create_adjacency_list(graph_info)

    # Passar vertice de origem e anterior a ele (para comecar, nao eh nenhum vertice)
    has_cicle = [False]
    depth_first_search(adjacency_list, graph_info[1][0], None, has_cicle)

    if has_cicle[0]:
        print("S")
    else:
        print("N")

if __name__ == "__main__":
    main()