from enum import Enum
class Cor(Enum):
    BRANCO = 0
    CINZA = 1
    PRETO = 2

class Vertice:
    def __init__(self, id, tempo_c=None, tempo_p=None):
        self.id = id
        self.visitado = False
        self.cor = Cor.BRANCO
        self.tempo_c = tempo_c
        self.tempo_p = tempo_p

    def eh_branco(self):
        return self.cor == Cor.BRANCO

    def eh_cinza(self):
        return self.cor == Cor.CINZA

    def eh_preto(self):
        return self.cor == Cor.PRETO

    def __eq__(self, outro_vertice):
        return self.id == outro_vertice.id

    def __str__(self):
        cor = ""

        if self.cor == Cor.BRANCO:
            cor = "BRANCO"
        elif self.cor == Cor.CINZA:
            cor = "CINZA"
        elif self.cor == Cor.PRETO:
            cor = "PRETO"

        s = f"{self.id} - {cor} - ({self.tempo_c}, {self.tempo_p})" 

        return s
