from vertice import *
from sys import stdin

class ListaAdjacencia:
    tempo = 1

    def incrementar_tempo():
        ListaAdjacencia.tempo += 1

    def resetar_tempo():
        ListaAdjacencia.tempo = 1

    def __init__(self):
        ##### Lendo Pajek do pajek #####

        #>>>> Inicializando alguns valores #####
        self.n_vertices = int(stdin.readline().split()[1])
        self.listas = []
        self.vertices = []

        for i in range(self.n_vertices):
            self.listas.append([])
            self.vertices.append(Vertice(i + 1))
        #<<<<

        # Testa segunda linha para saber se grafo é dirigido
        segunda_linha = stdin.readline()

        self.dirigido = segunda_linha.startswith("*Arcs")

        # adiciona arestas (ou arcos)
        for linha in stdin:
            if len(linha.strip()):
                v1, v2 = (int(s) for s in linha.split())
                self.adicionar_aresta(v1, v2)

        ##### Fim da leitura do Pajek ######

        ###### Fazendo dfs em todos os componentes conexos ######
        while True:
            vertice_branco = self.algum_vertice_branco()

            if not vertice_branco:
                break

            self.dfs(vertice_branco)

        #### Resetando Tempo #####
        ListaAdjacencia.resetar_tempo()

    def get_adjacentes_a(self, id: int):
        return self.listas[id - 1]

    def get_vertice(self, id: int):
        return self.vertices[id - 1]

    def adicionar_aresta(self, v1: int, v2: int):
        self.get_adjacentes_a(v1).append(self.get_vertice(v2))

        if not self.dirigido:
            self.get_adjacentes_a(v2).append(self.get_vertice(v1))
    
    def remover_aresta(self, v1: int, v2: int): 
        self.get_adjacentes_a(v1).remove(self.get_vertice(v2))
        self.get_adjacentes_a(v2).remove(self.get_vertice(v1))

    def pintar_de_cinza(self, v: int):
        self.get_vertice(v).cor = Cor.CINZA
    
    def pintar_de_preto(self, v: int):
        self.get_vertice(v).cor = Cor.PRETO

    def visitar(self, v: int):
        self.get_vertice(v).visitado = True

    def resetar_grafo(self):
        for vertice in self.vertices:
            vertice.cor = Cor.BRANCO
            vertice.visitado = False

    def imprimir_vertices_info(self):
        for vertice in self.vertices:
            print(vertice)

    def algum_vertice_branco(self):
        for vertice in self.vertices:
            if vertice.eh_branco():
                return vertice.id

        return None

    def dfs(self, vertice: int):
        self.pintar_de_cinza(vertice)
        self.get_vertice(vertice).tempo_c = ListaAdjacencia.tempo
        ListaAdjacencia.incrementar_tempo()
        
        for vizinho in self.get_adjacentes_a(vertice):
            if vizinho.eh_branco():
                self.dfs(vizinho.id)

        self.pintar_de_preto(vertice)
        self.get_vertice(vertice).tempo_p = ListaAdjacencia.tempo
        ListaAdjacencia.incrementar_tempo()

    def __str__(self):
        s = "Lista de Adjacência\n"

        v = 1

        for lista in self.listas:
            s += str(v) + " - "
            for vertice in lista:
                s += str(vertice.id) + " "
            s += "\n"
            v += 1
        
        return s
