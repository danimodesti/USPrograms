
# Danielle Modesti - N°USP: 12543544
# Hélio Nogueira Cardoso - N°USP: 10310227

from vertice import Vertice
from ListaAdjacencia import ListaAdjacencia

def main():
    # Lendo a entrada com os dados do grafo e criando-o em forma de lista de adjacência.
    grafo = ListaAdjacencia()

    # Definindo o subconjunto de vértices em relação aos quais é preciso remover um,
    # para que seja possível uma única coloração deles.
    envolvidos = [1, 2, 4, 8, 9, 10, 12, 13, 14]

    # Para fazer isso, recolhe-se as arestas formadas entre a lista de envolvidos. 
    # Isso pois o que impede o subconjunto de vértices de ser colorido com a mesma
    # cor é o fato de que pelo menos dois deles são vizinhos.
    adjacencias_envolvidos = []

    for i in envolvidos:
        for j in envolvidos:
            if Vertice(i) in grafo.get_adjacentes_a(j):
                adjacencias_envolvidos.append([i, j])

    # Procurando um vértice que esteja presente em todas as arestas recolhidas 
    # entre os envolvidos.
    vertice_em_todas_as_arestas = -1

    for par in adjacencias_envolvidos:
        esta_ligado_a_todos = True
        candidato = par[0]

        for ligacoes in adjacencias_envolvidos:
            if candidato != ligacoes[0] and candidato != ligacoes[1]:
                esta_ligado_a_todos = False
                break

        if esta_ligado_a_todos:
            vertice_em_todas_as_arestas = candidato
            break

    # Se há um vértice que esteja presente em todas as conexões feitas entre os envolvidos,
    # a remoção dele permitiria que nenhum par dos vértices envolvidos seja de vizinhos,
    # o que também permitiria a coloração deste subconjunto com uma única cor.
    if vertice_em_todas_as_arestas != -1:
        print(vertice_em_todas_as_arestas)
    else: 
        print("Não há um vértice que, ao ser removido, permita que os vértices sejam coloridos com uma única cor.")

if __name__=='__main__':
    main() 