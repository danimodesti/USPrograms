#
# Danielle Modesti — 12543544
# Grafos — 3o semestre — Professor Kuruvilla
# 21/05/2022
#

from graph import *

def main():
    graph_info = get_graph_data()
    adjacency_list = create_adjacency_list(graph_info)

    apex_amt = len(adjacency_list)

    for apex in range(apex_amt):
        distances_from_apex = breadth_first_search(apex, adjacency_list)
        new_matrix_line = str(distances_from_apex).replace("[", "").replace("]", "").replace(",", "")
        print(new_matrix_line)
    

if __name__ == "__main__":
    main()