/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Organizacao de Arquivos - 3o semestre (2022.1)
 * Primeiro Exercicio Pratico - registro de pessoas
 *
 * TAD utils - cabecalho [visao do usuario]
 */

#ifndef UTILS_H
#define UTILS_H

char *read_line_allocate();

/* Funcao nao aloca (para vetor de tamanho estatico)
 *
 */
void read_line(char *string);

/*
 * Essa funcao foi dada pelo monitor.
 *
*/
void binarioNaTela(char *nomeArquivoBinario);

int string_length(char *string);

void *memory_copy(void *dest, void *src, size_t n_bytes);

#endif