/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Organizacao de Arquivos - 3o semestre (2022.1)
 * Primeiro Exercicio Pratico - registro de pessoas
 *
 * TAD person - cabecalho [visao do usuario]
 */

#ifndef PERSON_H
#define PERSON_H

typedef struct Person person_t;

person_t *create_person();

void read_person(person_t *new_person);

void print_person(person_t *person);

void complete_person_info(person_t *person);

void set_person_name(person_t *person, char *value);

void set_person_last_name(person_t *person, char *value);

void set_person_email(person_t *person, char *value);

void set_person_nationality(person_t *person, char *value);

void set_person_age(person_t *person, int value);

char *get_person_name(person_t *person);

char *get_person_last_name(person_t *person);

char *get_person_email(person_t *person);

char *get_person_nationality(person_t *person);

int get_person_age(person_t *person);

void destroy_person(person_t **person);

#endif