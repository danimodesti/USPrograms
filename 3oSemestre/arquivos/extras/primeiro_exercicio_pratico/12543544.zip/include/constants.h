/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Organizacao de Arquivos - 3o semestre (2022.1)
 * Primeiro Exercicio Pratico - registro de pessoas
 *
 * TAD constants - cabecalho [visao do usuario]
 */

#ifndef CONSTANTS_H
#define CONSTANTS_H

#define TRUE 1
#define FALSE 0

#define SUCCESS 2
#define ERROR -1

#define BUFFER_SIZE 15

#define GARBAGE '$'

#endif