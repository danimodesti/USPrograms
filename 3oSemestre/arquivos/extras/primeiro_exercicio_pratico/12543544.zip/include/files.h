/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Organizacao de Arquivos - 3o semestre (2022.1)
 * Primeiro Exercicio Pratico - registro de pessoas
 *
 * TAD files - cabecalho [visao do usuario]
 */

#ifndef FILES_H
#define FILES_H

#include "person.h"

FILE *create_file(char *file_name);

FILE *open_file(char *file_name);

void write_register(FILE *file_ptr, person_t *person);

void print_register(person_t *person);

void read_register(FILE *file_ptr, person_t *person);

int read_register_by_RRN(FILE *file_ptr, person_t *person, int RRN);

#endif