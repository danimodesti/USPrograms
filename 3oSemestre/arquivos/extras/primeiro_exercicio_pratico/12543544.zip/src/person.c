/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Organizacao de Arquivos - 3o semestre (2022.1)
 * TAD person - implementacao
 * 
 */

#include <stdio.h>
#include <stdlib.h>

#include "constants.h"
#include "person.h"
#include "utils.h"

// Foram dados os tamanhos dos campos do registro de pessoa
struct Person {
    char first_name[51];
    char last_name[51];
    char email[81];
    char nationality[51];
    int age;
};

person_t *create_person() {
    person_t *new_person = (person_t *) malloc(sizeof(person_t));
    
    return new_person;
}

void read_person(person_t *new_person) {    
    read_line(new_person->first_name);
    read_line(new_person->last_name);
    read_line(new_person->email);
    read_line(new_person->nationality);
    scanf("%d", &new_person->age);
}

void print_person(person_t *person) {
    printf("Firstname: %s\n", person->first_name);
    printf("Lastname: %s\n", person->last_name);
    printf("Email: %s\n", person->email);
    printf("Nationality: %s\n", person->nationality);
    printf("Age: %d\n\n", person->age);
}

/*
 * Para trabalhar com arquivos no  run.codes, devemos definir
 * um lixo a completar o campo de tamanho fixo. Alem disso, foi
 * orientado para que salvemos o '\0'.
 *
 */
void complete_person_info(person_t *person) {
    int name_len = string_length(person->first_name);
    int garbage_amt = 51 - ++name_len; // Aproveitando o '\0'

    for (int i = 0; i < garbage_amt; i++) {
        person->first_name[name_len++] = GARBAGE;
    }

    int last_name_len = string_length(person->last_name);
    garbage_amt = 51 - ++last_name_len; // Aproveitando o '\0'

    for (int i = 0; i < garbage_amt; i++) {
        person->last_name[last_name_len++] = GARBAGE;
    }

    int email_len = string_length(person->email);
    garbage_amt = 81 - ++email_len; // Aproveitando o '\0'

    for (int i = 0; i < garbage_amt; i++) {
        person->email[email_len++] = GARBAGE;
    }

    int nationality_len = string_length(person->nationality);
    garbage_amt = 51 - ++nationality_len; // Aproveitando o '\0'

    for (int i = 0; i < garbage_amt; i++) {
        person->nationality[nationality_len++] = GARBAGE;
    }
}

void set_person_name(person_t *person, char *value) {
    memory_copy(person->first_name, value, 51);    
}

void set_person_last_name(person_t *person, char *value) {
    memory_copy(person->last_name, value, 51);
}

void set_person_email(person_t *person, char *value) {
    memory_copy(person->email, value, 81);
}

void set_person_nationality(person_t *person, char *value) {
    memory_copy(person->nationality, value, 51);
}

void set_person_age(person_t *person, int value) {
    person->age = value;
}

char *get_person_name(person_t *person) {
    return person->first_name;    
}

char *get_person_last_name(person_t *person) {
    return person->last_name;
}

char *get_person_email(person_t *person) {
    return person->email;
}

char *get_person_nationality(person_t *person) {
    return person->nationality;
}

int get_person_age(person_t *person) {
    return person->age;
}

void destroy_person(person_t **person) {
    free(*person);
    *person = NULL;
}