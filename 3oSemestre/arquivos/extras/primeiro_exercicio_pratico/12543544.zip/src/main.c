/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Organizacao de Arquivos - 3o semestre (2022.1)
 * Primeiro Exercicio Pratico - registro de pessoas
 * 
 */
 
#include <stdio.h>
#include <stdlib.h>

#include "constants.h"
#include "files.h"
#include "utils.h"
#include "person.h"

typedef enum Command {
    GET_ESPECIFIED_DATA = 1,
    GET_ONLY_FILE_NAME = 2,
    GET_REGISTER_RRN = 3
} command_t;

int main() {
    int option;
    scanf("%d ", &option);

    // Recebendo nome do arquivo a manipular
    char *file_to_manage = read_line_allocate();

    // Declarando variaveis aqui pois o switch nao permite isso dentro dele.
    int number_of_registers;
    char check_entry;
    FILE *retrieved_data;
    int RRN;

    person_t *curr_person = NULL;
    
    switch ((command_t)option) {
        case GET_ESPECIFIED_DATA: // Para gravacao de registro
            // Quantos registros serao lidos
            scanf("%d", &number_of_registers);
            FILE *output_file = create_file(file_to_manage);
            curr_person = create_person();
            
            for (int i = 0; i < number_of_registers; i++) {
                read_person(curr_person);
                
                // Preparando formato de informacoes da pessoa pro arquivo
                // (definindo lixo, colocando '\0' etc)
                complete_person_info(curr_person);
                write_register(output_file, curr_person);
            }

            fclose(output_file);

            // Funcao para comparacao no runcodes (saida da func. 1)
            binarioNaTela(file_to_manage);
            break;
        case GET_ONLY_FILE_NAME: // Para recuperacao de registro
            retrieved_data = open_file(file_to_manage);
            curr_person = create_person();

            // Enquanto o fread ler entrada valida
            while ((fread(&check_entry, sizeof(char), 1, retrieved_data)) != 0) {
                // Voltar o cursor
                fseek(retrieved_data, -sizeof(char), SEEK_CUR);
                read_register(retrieved_data, curr_person);
                print_person(curr_person);
            }

            fclose(retrieved_data);
            break;
        case GET_REGISTER_RRN: // Para recuperacao de registro
            retrieved_data = open_file(file_to_manage);  
            scanf("%d", &RRN); // Registro a ser lido
            curr_person = create_person();  
            int is_RRN_valid = read_register_by_RRN(retrieved_data, curr_person, RRN);
            if (is_RRN_valid) {
                print_person(curr_person);
            }

            fclose(retrieved_data);
            break;
        default:
            printf("Digite um comando válido (1, 2 ou 3).");
    }

    // Liberando memoria dinamicamente alocada
    if (curr_person) {
        destroy_person(&curr_person);
    }

    free(file_to_manage);

    return EXIT_SUCCESS;
}