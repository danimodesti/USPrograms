/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Organizacao de Arquivos - 3o semestre (2022.1)
 * TAD files - implementacao
 * 
 */

#include <stdio.h>
#include <stdlib.h>
 
#include "constants.h"
#include "files.h"

FILE *create_file(char *file_name) {
    // Criando um arquivo de saida
    FILE *new_file = NULL;
    new_file = fopen(file_name, "wb");

    if (!new_file) {
        printf("Arquivo %s nao existe.\n", file_name);
        free(file_name);
        exit(1);
    }

    return new_file;
}

void write_register(FILE *file_ptr, person_t *person) {
    fwrite(get_person_name(person), sizeof(char), 51, file_ptr);
    fwrite(get_person_last_name(person), sizeof(char), 51, file_ptr);
    fwrite(get_person_email(person), sizeof(char), 81, file_ptr);
    fwrite(get_person_nationality(person), sizeof(char), 51, file_ptr);
    int age = get_person_age(person);
    fwrite(&age, sizeof(int), 1, file_ptr);
}

FILE *open_file(char *file_name) {
    FILE *file_ptr = NULL;
    file_ptr = fopen(file_name, "rb");

    if (!file_ptr) {
        printf("Falha no processamento do arquivo");
        free(file_name);
        exit(0);
    }

    return file_ptr;
}

void read_register(FILE *file_ptr, person_t *person) {
    char read_value[51];
    fread(read_value, sizeof(char), 51, file_ptr);
    set_person_name(person, read_value);

    fread(read_value, sizeof(char), 51, file_ptr);
    set_person_last_name(person, read_value);

    char read_email[81];
    fread(read_email, sizeof(char), 81, file_ptr);
    set_person_email(person, read_email);

    fread(read_value, sizeof(char), 51, file_ptr);
    set_person_nationality(person, read_value);

    int read_age;
    fread(&read_age, sizeof(int), 1, file_ptr);
    set_person_age(person, read_age);
}

int read_register_by_RRN(FILE *file_ptr, person_t *person, int RRN) {
    int byte_offset = RRN * 238;
    int is_RRN_valid = FALSE;

    fseek(file_ptr, 0, SEEK_END);
    long int file_ending = ftell(file_ptr);

    if (file_ending < (byte_offset + 238) || RRN < 0) {
        printf("Não foi possível ler o arquivo");
    }

    else {
        fseek(file_ptr, byte_offset, SEEK_SET);
        read_register(file_ptr, person);
        is_RRN_valid = TRUE;
    }

    return is_RRN_valid;
}