//
// Created by rzimmerdev on 23/05/2022.
//
#include <stdio.h>
#include <stdbool.h>

#ifndef T1_CSV_UTILS_H
#define T1_CSV_UTILS_H

void csv_to_bin(FILE *csv, FILE *dest, bool is_fixed);

#endif //T1_CSV_UTILS_H
