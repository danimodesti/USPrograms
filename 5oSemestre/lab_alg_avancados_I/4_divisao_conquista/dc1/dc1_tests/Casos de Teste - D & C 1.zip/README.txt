Arquivo zip gerado em: 28/04/2023 14:20:05 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: D & C 1