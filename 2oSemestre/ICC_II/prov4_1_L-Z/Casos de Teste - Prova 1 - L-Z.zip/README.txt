Arquivo zip gerado em: 28/10/2023 18:57:44 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Prova 1 - L-Z