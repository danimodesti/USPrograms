/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Introducao a Ciencia da Computacao II - 2° Semestre de 2021
 * Exercicio 03: Busca Indexada com Lista Encadeada
 * TAD linked list - cabecalho [visao do usuario]
 */

#ifndef LINKED_LIST_H
#define LINKED_LIST_H

typedef struct list list_t; 

/* 
 * Cria/aloca uma estrutura de lista, retornando-a.
 * Atribui NULL ao conteudo da lista (inicio, fim), ainda nao definido. Tambem
 * atribui tamanho zero a lista.
 * Retorna NULL se nao foi possivel criar a estrutura lista.
*/
list_t *create();

/*
 * Libera memoria dinamicamente alocada para a estrutura lista e seu conteudo 
 * interno. Se isso ja ocorreu, retorna ERROR. 
 * Se for bem sucedido, atribui NULL a estrutura.
 * Retorna SUCCESS.
 */
int destroy(list_t **l);

/*
 * Adiciona o elemento x a sua posicao correta da lista.
 * Se a lista nao existir, retorna ERROR. Se bem sucedida, retorna SUCCESS.
 *
 */
int push_by_value(list_t *l, char *x);

/*
 * Exibe a quantidade de elementos que foi pedida.
 */
void print_element_amt(list_t *l, int element_amt);

/*
 * Busca um elemento na lista, retornando 1 se encontra lo
 * e 0 caso contrario. Tambem retorna por referencia a quantidade de nos
 * percorridos na lista ate chegar ao elemento (se nao alcanca lo, isto
 * fica com valor zero).
 */
int search_list (list_t *l, char *word_to_search, int *visited_node_amt);

/*
 * Criar ou atualizar vetor de indices para a lista encadeada. Retorna a quantidade
 * de letras diferentes validas.
 */
int update_index_array(list_t *l);

#endif