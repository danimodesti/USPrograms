/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Introducao a Ciencia da Computacao II - 2° Semestre de 2021
 * Exercicio 03: Busca Indexada com Lista Encadeada
 * TAD constants - cabecalho [visao do usuario]
 */

#define TRUE 1
#define FALSE 0

#define SUCCESS 2
#define ERROR -1

#define BUFFER_SIZE 15

#define ALPHABET_SIZE 26