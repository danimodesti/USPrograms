/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Introducao a Ciencia da Computacao II - 2° Semestre de 2021
 * Exercicio 03: Busca Indexada com Lista Encadeada
 * TAD string utils - implementacao
 */

#include <stdio.h>
#include <stdlib.h>
#include "constants.h"
#include "string_utils.h"

int string_length(char *string) {
    int length = 0;
    while (string[length] != '\0') {
        length++;
    }

    return length;
}

int content_comparison(char *string_1, char *string_2) {
    int str_1_length, str_2_length;
    str_1_length = string_length(string_1);
    str_2_length = string_length(string_2);

    if (str_1_length != str_2_length) {
        return FALSE;
    }

    int i = 0;
    while (string_1[i] != '\0') {
        if (string_1[i] != string_2[i]) {
            return FALSE;
        }
        i++;
    }

    return TRUE;
}

char *read_until(char terminator) {
    char curr_char;
    int str_len = 0;
    char *str = NULL;

    // Consumir chars possivelmente restantes no buffer
    do {
        curr_char = getchar();
    } while (curr_char == '\r' || curr_char == '\n' || curr_char == ' ');

    // Devolver char se valido
    if (curr_char != EOF) {
        ungetc(curr_char, stdin);
    }

    str = (char *) malloc(BUFFER_SIZE * sizeof(char));

    do {
        curr_char = getchar();
        str_len++;

        if (curr_char != terminator && curr_char != '\r' && curr_char != '\n' && curr_char != EOF) {
            // Teste do buffer
            if (str_len % BUFFER_SIZE == 0) {
                str = (char *) realloc(str, ((str_len / BUFFER_SIZE+1) * BUFFER_SIZE) * sizeof(char));
            }

            str[str_len - 1] = curr_char;
        }

        else {
            str[str_len - 1] = '\0';
        }

    } while (curr_char != terminator && curr_char != '\r' && curr_char != '\n' && curr_char != EOF);

    if (!str) {
        return NULL;
    } 

    // Corrigir a alocacao
    str = (char *) realloc(str, str_len * sizeof(char));

    return str;
}

char *read_line(FILE *stream) {
    char curr_char;
    int str_len = 0;
    char *str = NULL;

    // Consumir chars possivelmente restantes no buffer
    do {
        curr_char = fgetc(stream);
    } while (curr_char == '\r' || curr_char == '\n' || curr_char == ' ');

    // Devolver char se valido
    if (curr_char != EOF) {
        ungetc(curr_char, stream);
    }

    str = (char *) malloc(BUFFER_SIZE * sizeof(char));

    do {
        curr_char = fgetc(stream);
        str_len++;

        if (curr_char != '\r' && curr_char != '\n' && curr_char != EOF) {
            // Teste do buffer
            if (str_len % BUFFER_SIZE == 0) {
                str = (char *) realloc(str, ((str_len / BUFFER_SIZE+1) * BUFFER_SIZE) * sizeof(char));
            }

            str[str_len - 1] = curr_char;
        }

        else {
            str[str_len - 1] = '\0';
        }

    } while (curr_char != '\r' && curr_char != '\n' && curr_char != EOF);

    if (!str) {
        return NULL;
    } 

    // Corrigir a alocacao
    str = (char *) realloc(str, str_len * sizeof(char));

    return str;
}

int string_compare(char *string_1, char *string_2) {
    // Adaptacao de strcmp para verificar se palavra vem antes na ASCII ou
    // nao.

    int diff = 0; // as strings aqui nao sao diferentes

    int i = 0;
    while (string_1[i] != '\0' && string_2[i] != '\0' && diff == 0) { // sai do while se uma das strings (ou ambas) 
                                                                    // acabarem, OU se os chars (que sao inteiros na
                                                                    // ASCII) forem diferentes, dando diff != 0
        diff += string_1[i] - string_2[i];                              
        i++;
    }

    // quanto mais avancamos na tabela ascii, maiores sao os valores pros chars

    if (diff == 0) { 
        diff = string_length(string_1) - string_length(string_2);
    }

    // Se diff == 0, strings iguais;
    // Se diff < 0, string_1 < string_2 (na ASCII, ela vem antes);
    // se diff > 0, string_2 < string_1 (na ASCII, ela vem antes).

    return diff;
}

void *memory_copy(void *dest, void *src, size_t n_bytes) {
    char *d = (char *)dest;
    char *s = (char *)src;

    for (int i = 0; i < (int)n_bytes; i++) {
        d[i] = s[i];
    }

    return dest;
}

void string_append(char **string_1, char **string_2) {
    int string_1_size = string_length(*string_1);
    printf("tamanho string 1: %d\n", string_1_size);
    int string_2_size = string_length(*string_2);
    printf("tamanho string 2: %d\n", string_2_size);

    // Fazer o append na string 1
    *string_1 = (char *) realloc(*string_1, (string_1_size + string_2_size + 1) * sizeof(char));

    int j = 0;
    for (int i = string_1_size; j < string_2_size; i++, j++) {
        (*string_1)[i] = (*string_2)[j];
    }

    (*string_1)[string_1_size + string_2_size] = '\0';
}

char get_first_char(char *string) {
    return string[0];
}