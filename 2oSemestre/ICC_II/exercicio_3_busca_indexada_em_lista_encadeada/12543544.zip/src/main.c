/*
 * Nome: Danielle Modesti
 * N° USP: 12543544
 * Codigo do Curso: SCC0201
 * Disciplina: Introducao a Ciencia da Computacao II - 2° Semestre de 2021
 * Exercicio 03: Busca Indexada com Lista Encadeada
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include "constants.h"
#include "linked_list.h"
#include "string_utils.h"

typedef enum Commands {
    FREE_MEMORY,
    READ_FILE_AND_CREATE_LIST,
    CREATE_OR_UPDATE_INDEX_ARRAY,
    SEARCH_WORD
} command_t;

int main() {
    int command;
    list_t *list = create();
    int is_array_updated = FALSE;

    do {
        scanf("%d", &command);

        if (command == READ_FILE_AND_CREATE_LIST) {
            char *file_to_open = read_line(stdin);
            FILE *fp = fopen(file_to_open, "r");
            
            if (!fp) {
                printf("Arquivo invalido! =(\n");
                free(file_to_open);

                return EXIT_FAILURE;
            }

            while (!feof(fp)) {
                char *new_word = read_line(fp);
                push_by_value(list, new_word);
            }

            fclose(fp);
            free(file_to_open);

            print_element_amt(list, 3);
            is_array_updated = FALSE;
        }

        else if (command == CREATE_OR_UPDATE_INDEX_ARRAY) {
            int valid_chars_amt = update_index_array(list);
            printf("%d\n", valid_chars_amt);
            is_array_updated = TRUE;
        }

        else if (command == SEARCH_WORD) {
            char *word_to_search = read_line(stdin);

            if (!is_array_updated) {
                printf("Vetor de indices nao atualizado.\n");
            }

            else {
                int visited_node_amt = 0;
                int found_element = search_list(list, word_to_search, &visited_node_amt);
                if (found_element == TRUE) {
                    printf("%d\n", visited_node_amt);
                }

                else {
                    printf("Palavra nao existe na lista.\n");
                }
            }

            free(word_to_search);
        }
    } while (command != FREE_MEMORY);

    // Se chegou aqui, o comando foi o de liberar memoria.
    destroy(&list);

    return EXIT_SUCCESS;
}