/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Introducao a Ciencia da Computacao II - 2° Semestre de 2021
 * Exercicio 03: Busca Indexada com Lista Encadeada
 * TAD linked list - implementacao
 */

#include <stdio.h>
#include <stdlib.h>
#include "constants.h"
#include "linked_list.h"
#include "string_utils.h"

typedef struct node node_t;

struct node {
    char *data;
    node_t *next;
};

struct list {
    node_t *head, *end;
    node_t **index_array;
    int size;
};

list_t *create() {
    list_t *l = (list_t *) malloc(sizeof(list_t));

    if (!l) {
        return NULL;
    }

    l->head = NULL;
    l->end = NULL;
    l->size = 0;

    // Vetor de indices
    l->index_array = NULL;

    return l;
}

int destroy(list_t **l) {
    if (*l) {
        node_t *p = (*l)->head;

        while (p) {
            (*l)->head = p->next;

            if (p->data) {
                free(p->data);
            }

            free(p);
            p = (*l)->head;
        }

        // Liberar o vetor de indices
        if ((*l)->index_array) {
            free((*l)->index_array);
        }

        free(*l);

        *l = NULL;

        return SUCCESS;
    }

    return ERROR;
}

int push_by_value(list_t *l, char *word) {
    if (!l) {
        return ERROR;
    }

    // Vamos inserir novo no para receber elemento x
    node_t *p = (node_t *) malloc(sizeof(node_t));

    p->data = word;
    p->next = NULL;

    // Se nao houver nenhum elemento na lista, este sera o primeiro.
    if (!l->head) {
        l->head = p;
        l->end = p;
    }

    // Se houver elementos na lista,

    // O char da palavra inserida agora eh o maior de todos? (ultimo elemento da lista)
    else if (get_first_char(l->end->data) < get_first_char(word)) {
        l->end->next = p;
        l->end = p;
    }

    // Inserir palavra no meio
    else {
        node_t *q = l->head;
        node_t *prev = NULL;

        // Achar posicao correta
        while (get_first_char(q->data) < get_first_char(word)) {
            prev = q;
            q = q->next;
        }
        
        // A palavra de menor char eh a que esta sendo adicionada agora? 
        if (!prev) {
            p->next = l->head;
            l->head = p;
        }

        else {
            prev->next = p;
            p->next = q;
        }
    }

    l->size++;

    return SUCCESS;
}

void print_element_amt(list_t *l, int element_amt) {
    node_t *p = l->head;
    int printed = 0;
    while (p && printed < element_amt) {
        printf("%s\n", p->data);
        p = p->next;
        printed++;
    }
}

int update_index_array(list_t *l) {
    // Criando o vetor de indices
    if (!l->index_array) {
        l->index_array = (node_t **) calloc(ALPHABET_SIZE, sizeof(node_t *));
    }

    // Atualizando vetor de indices
    node_t *curr_node = l->head;
    node_t *prev_node = NULL;

    // Contar quantos elementos contem seu ponteiro apontando para algum no da lista
    int valid_chars_amt = 0;

    while (curr_node) {
        char curr_char = get_first_char(curr_node->data);

        if (!prev_node || get_first_char(prev_node->data) != curr_char) {
            l->index_array[curr_char - 'a'] = curr_node;
            valid_chars_amt++;
        }

        prev_node = curr_node;
        curr_node = curr_node->next;
    }

    return valid_chars_amt;
}

int search_list(list_t *l, char *word_to_search, int *visited_node_amt) {
    if (!l || !l->index_array) {
        return ERROR;
    }

    // Acessar vetor de indices com a primeira letra da palavra passada.
    // Existem palavras que comecam com esse char na lista?
    int has_words_with_this_char = FALSE;
    int i = 0;
    while (!has_words_with_this_char && i < ALPHABET_SIZE) {
        if (l->index_array[i] && get_first_char(l->index_array[i]->data) == get_first_char(word_to_search)) {
            has_words_with_this_char = TRUE;
        }

        else {
            i++;
        }
    }

    // Procurar pela palavra. Ela existe na lista?
    int is_element_in_list = FALSE;

    // Contar quantos nos foram percorridos
    *visited_node_amt = 0;

    if (has_words_with_this_char) {
        // Comecar a busca na posicao de inicio com as palavras de mesma
        // primeira letra.
        node_t *p = l->index_array[i];

        while (get_first_char(p->data) == get_first_char(word_to_search) && !is_element_in_list) {
            if (content_comparison(p->data, word_to_search) == TRUE) {
                is_element_in_list = TRUE;
            }

            else {
                p = p->next;
                (*visited_node_amt)++;
            }
        }
    }

    return is_element_in_list;
}