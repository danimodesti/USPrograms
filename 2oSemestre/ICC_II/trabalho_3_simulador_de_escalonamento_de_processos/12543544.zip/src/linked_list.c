/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Introducao a Ciencia da Computacao II - 2° Semestre de 2021
 * Trabalho 03: Simulador de Escalonamento de Processos
 * TAD list - implementacao
 */

#include <stdio.h>
#include <stdlib.h>
#include "constants.h"
#include "linked_list.h"
#include "process.h"

typedef struct node node_t;

struct node {
    process_t *data;
    node_t *next;
};

struct list {
    node_t *head, *end, *curr;
    int size;
};

list_t *create() {
    list_t *l = (list_t *) malloc(sizeof(list_t));

    if (!l) {
        return NULL;
    }

    l->head = NULL;
    l->end = NULL;
    l->curr = NULL;
    l->size = 0;

    return l;
}

int destroy(list_t **l) {
    if (*l) {
        node_t *p = (*l)->head;

        while (p) {
            (*l)->head = p->next;

            if (p->data) {
                destroy_process(&p->data);
            }

            free(p);
            p = (*l)->head;
        }

        free(*l);

        *l = NULL;

        return SUCCESS;
    }

    return ERROR;
}

int push_by_value(list_t *l, process_t *x) {
    if (!l) {
        return ERROR;
    }

    // Vamos inserir novo no para receber elemento x
    node_t *new = (node_t *) malloc(sizeof(node_t));

    new->data = x;
    new->next = NULL;

    // Se nao houver nenhum elemento na lista, este sera o primeiro.
    if (!l->head) {
        l->head = new;
        l->curr = new;
        l->end = new;
    } 

    // Se houver elementos na lista, controlar as prioridades.
    // Inserir ou no inicio ou no meio
    else { 
        node_t *curr = l->head;
        node_t *prev = NULL;

        while (curr && get_priority(new->data) < get_priority(curr->data)) {
            prev = curr;
            curr = curr->next;
        }

        while (curr && get_priority(new->data) == get_priority(curr->data) && get_code(new->data) > get_code(curr->data)) {
            prev = curr;
            curr = curr->next;
        }

        // Maior prioridade de todos! [novo inicio]
        if (!prev) {
            new->next = l->head;
            l->head = new;
            l->curr = new;
        }

        // Acabou a lista
        else if (!curr) {
            l->end->next = new;
            l->end = new;
        }

        // Inserir no meio
        else {
            prev->next = new;
            new->next = curr;
        }
    }

    l->size++;

    return SUCCESS;
}

void execute_process_on_list(list_t *l, int curr_quantum) {
    decrement_process_remaining_quanta(l->curr->data);

    if (get_remaining_quanta(l->curr->data) == 0) {
        print_process(l->curr->data, curr_quantum);
        pop_by_value(l, l->curr->data);
    }

    else {
        l->curr = l->curr->next;

        if (!l->curr) {
            l->curr = l->head;
        }
    }
}

int size(list_t *l) {
    if (!l) {
        return ERROR;
    }

    return l->size;
}

// Remove e atualiza o ponteiro para no atual.
int pop_by_value(list_t *l, process_t *process_to_pop) {
    if (!l) {
        return ERROR;
    }

    node_t *prev = NULL;
    node_t *curr = l->head;

    // Encontrar o elemento que desejamos remover
    while (curr) {
        // Elemento encontrado:
        if (curr->data == process_to_pop) {
            // 1o caso: remover elemento do inicio, como uma fila
            if (!prev) {
                l->head = curr->next;  // Mudar o inicio
                l->curr = l->head;
            }

            // 2o caso: remover elemento do fim, como uma pilha
            else if (curr == l->end) {
                l->end = prev;
                l->end->next = NULL;
                l->curr = l->head;
            }

            // 3o caso: remover elemento do meio, desfazendo o no atual
            else {
                prev->next = curr->next;
                l->curr = prev->next;
            }

            // Desalocando processo
            destroy_process(&process_to_pop);

            // Desalocando no
            free(curr);

            l->size--;

            return SUCCESS;
        }

        else {
            prev = curr;
            curr = curr->next;
        }
    }

    return ERROR;
}