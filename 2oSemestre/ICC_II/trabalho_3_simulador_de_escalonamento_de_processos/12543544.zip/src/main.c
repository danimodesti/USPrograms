/*
 * Nome: Danielle Modesti
 * N° USP: 12543544
 * Codigo do Curso: SCC0201
 * Disciplina: Introducao a Ciencia da Computacao II - 2° Semestre de 2021
 * Trabalho 03: Simulador de Escalonamento de Processos
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include "constants.h"
#include "linked_list.h"
#include "process.h"

int main() {
    // Salvar os processos da entrada num vetor de processos
    // 'Lista' de processos
    int process_amt = 0;
    process_t **array = NULL;  

    int curr_int = 0;
    int curr_index = 0;
    while ((curr_int = getchar()) != EOF) {
        ungetc(curr_int, stdin);
        process_t *new_process = create_process();

        process_amt++;
        array = (process_t **) realloc(array, process_amt * sizeof(process_t *));
        array[curr_index] = new_process;
        curr_index++;
    }

    // Ordenar por quantum para entrada no escalonador. Depois, checar codigos iguais.
    ordenate_processes(array, process_amt);

    // Submeter processos a lista (que simula um escalonador de processos)
    list_t *l = create();

    // Iniciar contagem de quantum
    int curr_quantum = 1;
    int start_index = 0;

    // Repassar processos para o simulador 
    while (start_index < process_amt) {
        while (start_index < process_amt && get_entry_quantum(array[start_index]) == curr_quantum) {
            push_by_value(l, array[start_index++]);
        }

        execute_process_on_list(l, curr_quantum);
        curr_quantum++;
    }

    // Repassou tudo para a lista
    free(array);

    // Continuar a simular o escalonador
    while (size(l) > 0) {
        execute_process_on_list(l, curr_quantum);
        curr_quantum++;
    }

    // Liberando memoria dinamicamente alocada
    destroy(&l);

    return EXIT_SUCCESS;
}