/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Introducao a Ciencia da Computacao II - 2° Semestre de 2021
 * Trabalho 03: Simulador de Escalonamento de Processos 
 * TAD process - implementacao
 */

#include <stdio.h>
#include <stdlib.h>
#include "process.h"
#include "constants.h"

struct Process {
    int code;
    int entry_quantum;
    int remaining_quanta;
    int priority;
};

process_t *create_process() {
    process_t *p = (process_t *) malloc(sizeof(process_t));

    if (!p) {
        return NULL;
    }

    scanf("%d %d %d %d", &p->code, &p->entry_quantum, &p->remaining_quanta, &p->priority);
    if (!p->code || !p->entry_quantum || !p->remaining_quanta || !p->priority) {
        return NULL;
    }

    return p;
}

void print_process(process_t *p, int curr_quantum) {
    printf("%d %d\n", p->code, curr_quantum);
}

int destroy_process(process_t **p) {
    if (*p) {
        free(*p);

        *p = NULL;

        return SUCCESS;
    }

    return ERROR;
}

// Ordenar por entrada no escalonador
int quantum_comparator(process_t *p_1, process_t *p_2) {
    if (!p_1 || !p_2) {
        return FALSE;
    }

    return p_2->entry_quantum > p_1->entry_quantum;
}

// Algoritmo de ordenacao utilizado por ser eficiente para pequenas entradas
void insertion_sort(process_t **vector, int vector_size) {
    int i = 1;

    while (i < vector_size) {
        process_t *key = vector[i];
        int j = i - 1;

        while (j >= 0 && quantum_comparator(key, vector[j])) {
            vector[j + 1] = vector[j];
            j--;
        }

        vector[j + 1] = key;
        i++;
    }
}

void set_process_code(process_t *p, int value) {
    p->code = value;
}

void check_processes_codes(process_t **array, int array_size) {
    int has_duplicated_code = FALSE;
    int i = array_size;
    int j;
    while (!has_duplicated_code && --i > 0) {
        j = 0;
        while (j < i && !has_duplicated_code) {
            if (get_code(array[i]) == get_code(array[j])) {
                has_duplicated_code = TRUE;
            }

            else {
                j++;
            }
        }
    }

    if (has_duplicated_code) {
        set_process_code(array[i], get_code(array[j]) + 1);

        // Checar se ja resolveu o problema de codigos iguais.
        check_processes_codes(array, array_size);
    }
}

void ordenate_processes(process_t **array, int array_size) {
    // Ordenar por quantum de entrada no escalonador.
    insertion_sort(array, array_size);

    // Checar por processos de mesmo codigo.
    check_processes_codes(array, array_size);
}

int get_entry_quantum(process_t *p) {
    return p->entry_quantum;
}

int get_priority(process_t *p) {
    return p->priority;
}

int get_code(process_t *p) {
    return p->code;
}

int get_remaining_quanta(process_t *p) {
    return p->remaining_quanta;
}

void decrement_process_remaining_quanta(process_t *p) {
    if (p->remaining_quanta > 0) {
        p->remaining_quanta--;
    }
}