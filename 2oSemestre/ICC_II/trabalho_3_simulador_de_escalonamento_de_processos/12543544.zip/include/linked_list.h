/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Introducao a Ciencia da Computacao II - 2° Semestre de 2021
 * Trabalho 03: Simulador de Escalonamento de Processos 
 * TAD list - cabecalho [visao do usuario]
 */

#ifndef LINKED_LIST_H
#define LINKED_LIST_H

#include "process.h"

typedef struct list list_t; 

/* 
 * Cria/aloca uma estrutura de lista, retornando-a.
 * Atribui NULL ao conteudo da lista (inicio, fim, ptr. atual), ainda nao definido. Tambem
 * atribui tamanho zero a lista.
 * Retorna NULL se nao foi possivel criar a estrutura lista.
*/
list_t *create();

/*
 * Libera memoria dinamicamente alocada para a estrutura lista e seu conteudo 
 * interno. Se isso ja ocorreu, retorna ERROR. 
 * Se for bem sucedido, atribui NULL a estrutura.
 * Retorna SUCCESS.
 */
int destroy(list_t **l);

/*
 * Adiciona o elemento x ao fim da lista.
 * Se a lista nao existir, retorna ERROR. Se bem sucedida, retorna SUCCESS.
 *
 */
int push_by_value(list_t *l, process_t *x);

/*
 * Insere um novo elemento x ao indice especificado da lista.
 * Se a lista nao existe ou eh passado um indice invalido, retorna ERROR.
 * Se bem sucedida, retorna SUCCESS.
 */
int push_to_index(list_t *l, int index, process_t *x);

/*
 * Retorna o tamanho atual da lista.
 * Se ela nao existir, retorna ERROR.
 */
int size(list_t *l);

/*
 * Remove um elemento da lista pela passagem de seu valor.
 * Se a lista nao existe ou se a retirada foi mal sucedida, retorna ERROR. 
 * Se bem sucedida, retorna SUCCESS.
 */
int pop_by_value(list_t *l, process_t *process_to_pop);

/*
 * Remove um elemento da lista pela passagem de seu indice e de uma variavel que
 * guardara o valor que sai da lista por passagem de referencia.
 * Se a lista nao existe ou se a retirada foi mal sucedida, retorna ERROR.
 * Se bem sucedida, retorna SUCCESS.
 */
int pop_by_index(list_t *l, int index, process_t **element);

/*
 * Retorna o tamanho da lista. Se esta nao existe, retorna ERROR.
 */
int size(list_t *l);

/*
 * Controla o simulador de escalonamento de processos, intercalando
 * ponteiros de execucao e remocoes de processos (quando esta eh feita,
 * imprime a informacao do processo removido).
 */
void execute_process_on_list(list_t *l, int curr_quantum);

#endif