/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Introducao a Ciencia da Computacao II - 2° Semestre de 2021
 * Trabalho 03: Simulador de Escalonamento de Processos 
 * TAD process - cabecalho [visao do usuario]
 */

#ifndef PROCESS_H
#define PROCESS_H

typedef struct Process process_t;

// Cria uma estrutura de processo, retornando NULL se a alocacao deu errado.
process_t *create_process();

// Exibe o codigo do processo e o quantum no qual foi removido.
void print_process(process_t *p, int curr_quantum);

// Desaloca a estrutura do processo, retornando SUCCESS se deu certo
// e ERROR se nao pode desalocar.
int destroy_process(process_t **p);

void ordenate_processes(process_t **array, int array_size);

int get_entry_quantum(process_t *p);

int get_code(process_t *p);

int get_priority(process_t *p);

int get_remaining_quanta(process_t *p);

void decrement_process_remaining_quanta(process_t *p);

#endif