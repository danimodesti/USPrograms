/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Lab. ICC II — 2° semestre de 2021
 * Codificacao de Huffman — aplicacao — exercicio modulo III
 * TAD tree — implementacao
 */

#include <stdio.h>
#include <stdlib.h>
#include "binary_tree.h"
#include "constants.h"

// Funcao para criar uma arvore. Criamos um ponteiro para o tipo de dado arvore,
// alocando-o.
binary_tree_t *create_bin_tree(node_t *root) {
	binary_tree_t *tree = (binary_tree_t *) malloc(sizeof(binary_tree_t));

	// Arvore vazia
	tree->root = root;

	return tree;
}

// Destruir a arvore. Precisamos chegar ate uma folha e, chegando nela,
// a removemos (free) e voltamos para o anterior.
// Para navegar por entre a arvore, toda vez que descemos para um no mais abaixo, 
// usamos recursao. Para voltar, voltamos da recursao. 
void destroy_bin_tree(binary_tree_t **bin_tree) {
	if (!(*bin_tree)) {
		return;
	}
	
	destroy_node(&(*bin_tree)->root);
	free(*bin_tree);
	*bin_tree = NULL;
}

// Imprimiremos os dados da arvore da seguinte forma [notacao LISP]:
// temos o no 5(3, 6) -> notacao com no(filho_esq, filho_dir)

// se um dos filhos do 5 tem filhos, abrimos mais um parenteses.
// ex.: 5(3, 6(2, 1))  ...
// se for ponteiro NULL, podemos escrever: 5(3, 6(2, x)) -> no 6 tem apenas
// filho esquerdo.
void print_bin_tree(node_t *root) {
	if (root) {
		printf("simbolo: %c, frequencia: %d(", get_node_symbol(root), get_node_frequency(root));
		// Chamada recursiva
		print_bin_tree(get_node_child(root, LEFT));

		// Na volta da recursao acima,
		printf(",");
		print_bin_tree(get_node_child(root, RIGHT));
		printf(")");
	}
	
	// Raiz nula
	else {
		printf("x");
	}
}

// Altura de uma arvore
int bin_tree_height(node_t *root) {
	// Arvore vazia, sem altura
	if (!root) {
		return 0;
	}

	// Se raiz existe (o que ja me da altura 1), encontramos a altura da subarvore
	// da esquerda + 1.
	// Calcular altura subarvore da direita + 1
	int left_height = 1 + bin_tree_height(get_node_child(root, LEFT));
	int right_height = 1 + bin_tree_height(get_node_child(root, RIGHT));

	// Achar o maximo entre eles para a altura da arvore.
	if (left_height > right_height) {
		return left_height;
	}

	return right_height;
}