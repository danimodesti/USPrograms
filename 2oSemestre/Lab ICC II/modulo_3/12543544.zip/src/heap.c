/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Lab. ICC II — 2° semestre de 2021
 * Codificacao de Huffman — aplicacao — exercicio modulo III
 * TAD estrutura heap — implementacao
 */

#include <stdio.h>
#include <stdlib.h>
#include "constants.h"
#include "heap.h"
#include "node.h"

struct HeapQueue {
	// Eh o numero de elementos armazenados na heap
	int heap_size;

	// a Heap em si, que armazena os nos
		// obtem-se vetor de ponteiros para node_t
	node_t **heap;
};

heap_queue_t *create_heap_queue() {
	// Criar ponteiro f, que recebe alocacao de uma fila de prioridade.
	// como o vetor de node_t, heap, eh estatico e de tamanho MAX, aqui ele ja
	// eh alocado sem grandes preocupacoes, mas poderiamos faze lo dinamico, 
	// tendo a necessidade extra de aloca lo!
	heap_queue_t *heap_queue = (heap_queue_t *) malloc(sizeof(heap_queue_t));

	// fila comeca vazia. Se temos 1 elemento na fila, n aponta para 1, que eh a 
	// proxima posicao vazia do vetor. Como n comeca em zero, a posicao/indice 0
	// eh a proxima posicao vazia onde inseriremos o elemento.
	heap_queue->heap_size = 0;

	// Aloque espaco para a estrutura heap dinamica
	heap_queue->heap = (node_t **) malloc(sizeof(node_t *));

	return heap_queue;
}

// -------------------------- Controle de Min e Max Heap ---------------------------------------------------------------
// O elemento em element_index subira na arvore heap
void go_up_on_heap_tree(heap_queue_t *hq, int element_index) {
	// variavel usada na troca de elementos (swap)
	node_t *tmp;

	int father_index = (int)((element_index - 1) / 2);

	// se i tem pai e que seja menor que i
		// verificar prioridades dos nos
		// dentro do node_t, cheque o campo prioridade

	// Faremos MIN HEAP, pois queremos elementos com MENORES PRIORIDADES saindo primeiro, ou seja, no topo da fila heap!
	if (father_index >= 0 && get_node_frequency(hq->heap[element_index]) < get_node_frequency(hq->heap[father_index])) {
		// Troca ambos
		tmp = hq->heap[element_index];
		hq->heap[element_index] = hq->heap[father_index];
		hq->heap[father_index] = tmp;

		// Continue subindo o elemento ate posicao correta
		go_up_on_heap_tree(hq, father_index);
	}
}

// Desce o elemento que esta, inicialmente, na posicao element_index do vetor que representa a estrutura heap.
void go_down_on_heap_tree(heap_queue_t *hq, int element_index) {
	// Variavel usada na troca (swap)
	node_t *tmp;

	// Indice do filho do elemento em element_index
	int child_index = 2 * element_index + 1;

	// Se o elemento no indice passado como argumento tem filhos
	if (child_index < hq->heap_size) {
		// Se tem filho direito, tambem tem esquerdo.
		if (child_index < hq->heap_size - 1) {
			// Pega o menor filho (Min Heap)
			if (get_node_frequency(hq->heap[child_index]) > get_node_frequency(hq->heap[child_index + 1])) {
				child_index++;
			}
		}

		// Compare com o pai - logica de min heap
		if (get_node_frequency(hq->heap[child_index]) < get_node_frequency(hq->heap[element_index])) {
			// Troca ambos (swap)
			tmp = hq->heap[element_index];
			hq->heap[element_index] = hq->heap[child_index];
			hq->heap[child_index] = tmp;
			
			// Continue descendo o mesmo elemento ate chegar na prioridade certa
			go_down_on_heap_tree(hq, child_index);
		}
	}
}

int push_to_heap_queue(heap_queue_t *heap_queue, node_t *node_to_push) {
	// I - Insira elemento na proxima posicao do vetor

	// Aloque espaco na heap para o novo no (novo ponteiro para no da heap)
	heap_queue->heap = (node_t **) realloc(heap_queue->heap, (heap_queue->heap_size + 1) * sizeof(node_t *));

	heap_queue->heap[heap_queue->heap_size] = node_to_push;

	// II - Subir o elemento na posicao correta, mantendo MinHeap
	go_up_on_heap_tree(heap_queue, heap_queue->heap_size);

	// Atualize proxima posicao
	heap_queue->heap_size++;

	return SUCCESS; // Insercao com sucesso	
}

int pop_from_heap_queue(heap_queue_t *heap_queue, node_t **node_to_pop) {
	if (!is_heap_queue_empty(heap_queue)) {
		// Retorne no por referencia
		*node_to_pop = heap_queue->heap[0];

		heap_queue->heap_size--;

		// Coloque o ultimo elemento da fila na raiz.
		heap_queue->heap[0] = heap_queue->heap[heap_queue->heap_size];

		// Conserte o MinHeap
		go_down_on_heap_tree(heap_queue, 0);

		return SUCCESS; 
	}

	return ERROR;
}

int is_heap_queue_empty(heap_queue_t *heap_queue) {
	if (!heap_queue) {
		return ERROR;
	}

	return (heap_queue->heap_size == 0);
}

void destroy_heap_queue(heap_queue_t **heap_queue) {
	for (int i = 0; i < (*heap_queue)->heap_size; i++) {
		if ((*heap_queue)->heap[i]) {
			destroy_node(&(*heap_queue)->heap[i]);
		}
	}

	free((*heap_queue)->heap);

	if ((*heap_queue)) {
		free((*heap_queue));
	}

	*heap_queue = NULL;
}

void print_heap(heap_queue_t *hq) {
	for (int i = 0; i < hq->heap_size; i++) {
		printf("nó %d:chave - %c, prioridade - %d\n", i, get_node_symbol(hq->heap[i]), get_node_frequency(hq->heap[i]));
	}
}

int heap_queue_size(heap_queue_t *heap_queue) {
	return heap_queue->heap_size;
}