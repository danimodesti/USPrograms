#include <stdlib.h>
#include "coding.h"
#include "constants.h"
#include "node.h"
#include "string_utils.h"

// Percurso pos ordem para codificacao dos chars
void encoding(node_t *root, string_t code_buffer_array, int top, string_t *encoded_chars) {
	// Vai para a esquerda
    if (get_node_child(root, LEFT)) {
		code_buffer_array[top] = '0';
		encoding(get_node_child(root, LEFT), code_buffer_array, top + 1, encoded_chars);
	}

    // Vai para a direita
	if (get_node_child(root, RIGHT)) {
		code_buffer_array[top] = '1';
		encoding(get_node_child(root, RIGHT), code_buffer_array, top + 1, encoded_chars);
	}

	// Eh no-folha (manipule no-raiz)
	if (!get_node_child(root, LEFT) && !get_node_child(root, RIGHT)) {
        // Fim do preenchimento do buffer
        code_buffer_array[top] = '\0';

		// Copiar codificacao q esta no code_buffer_array, de zeros e uns, para o indice da tabela
		// que representa o char codificado encontrado.
        int curr_char = get_node_symbol(root);
        encoded_chars[curr_char] = (string_t) realloc(encoded_chars[curr_char], (top + 1) * sizeof(uchar));
		string_copy(code_buffer_array, encoded_chars[curr_char]);
	}
}

uchar decoding(node_t *root, string_t secret_message, int *curr_message_index) {
    // Eh no-folha - caractere pôde ser decodificado
    if (!get_node_child(root, LEFT) && !get_node_child(root, RIGHT)) {
        return get_node_symbol(root);
    }

    if (secret_message[(*curr_message_index)] == '0') {
        (*curr_message_index)++;
        return decoding(get_node_child(root, LEFT), secret_message, curr_message_index);
    }

    else {
        (*curr_message_index)++;
        return decoding(get_node_child(root, RIGHT), secret_message, curr_message_index);
    }
}

string_t make_coded_message(string_t *correspondance_table, string_t message_to_be_coded, int message_length) {
    string_t message = (string_t) malloc(BUFFER_SIZE * sizeof(uchar));
    message[0] = '\0';
    int curr_message_len = 0;

    for (int i = 0; i < message_length; i++) {
        curr_message_len = string_length(correspondance_table[(message_to_be_coded[i])]) + string_length(message);

        // Corrigir alocacao se necessario
        if (curr_message_len % BUFFER_SIZE == 0) {
            message = (string_t) realloc(message, ((curr_message_len / BUFFER_SIZE + 1) * BUFFER_SIZE) * sizeof(uchar));
        }

        // Repassar codigo do char atual
        string_append(&message, &(correspondance_table[(message_to_be_coded[i])]));
    }

    message[curr_message_len] = '\0';

    // Corrigir alocacao
    message = (string_t) realloc(message, (curr_message_len + 1) * sizeof(uchar));

    return message;
}