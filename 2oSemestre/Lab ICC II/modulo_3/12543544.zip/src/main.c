/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Lab. ICC II — 2° semestre de 2021
 * Codificacao de Huffman — aplicacao — exercicio modulo III
 * 
 */

#include <stdio.h>
#include <stdlib.h>

#include "binary_tree.h"
#include "coding.h"
#include "constants.h"
#include "heap.h"
#include "node.h"
#include "string_utils.h"

int main() {
    // Conjunto de dados recebidos, I_1
    string_t string_to_compress = read_line(stdin);
    int string_to_compress_length = string_length(string_to_compress);

    /* Gerar conjunto alfabeto A equivalente, analisando a frequencia de cada
    char na string e formando conjunto com esses dados.
    
    Como todos os chars estao na tabela ASCII estendida, criamos, inicialmente, um
    array com 256 possibilidades de correspondencia de codificacao para o alfabeto A.
     */
    uchar *ascii_alphabet = (uchar *) calloc(ASCII_SIZE, sizeof(uchar));
    
    for (int i = 0; i < string_to_compress_length; i++) {
        (ascii_alphabet[string_to_compress[i]])++;
    }

    // Criaremos uma arvore Heap para retirar os elementos com base em prioridades (mais ou menos
    // frequentes) [este sera o conjunto mencionado na especificacao da atividade]
    heap_queue_t *heap_queue = create_heap_queue();

    // Atencao aos chars nao utilizados. Crie nos somente para as posicoes com valores > 0,
    // que foram devidamente contabilizados na string a ser comprimida.
    for (int i = 0; i < ASCII_SIZE; i++) {
        if (ascii_alphabet[i] > 0) {
            node_t *new_node = create_node();
            set_node_symbol(new_node, i);
            set_node_frequency(new_node, ascii_alphabet[i]);

            push_to_heap_queue(heap_queue, new_node);
        }
    }

    // Retirar, sem reposicao, os dois nos com menor frequencia dentre os inseridos
    node_t *first_node_to_pop = NULL, *second_node_to_pop = NULL;
    while (heap_queue_size(heap_queue) > 1) {
        // No p1
        pop_from_heap_queue(heap_queue, &first_node_to_pop);

        // No p2
        pop_from_heap_queue(heap_queue, &second_node_to_pop);

        // No p3
        int orphan_node_frequency = get_node_frequency(first_node_to_pop) + get_node_frequency(second_node_to_pop);
        node_t *orphan_node = create_node();
        set_node_frequency(orphan_node, orphan_node_frequency);
        set_node_symbol(orphan_node, EMPTY_VALUE);

        set_node_child(orphan_node, first_node_to_pop, LEFT);
        set_node_child(orphan_node, second_node_to_pop, RIGHT);

        push_to_heap_queue(heap_queue, orphan_node);
    }

    // Na Heap Queue, temos apenas um no, que sera o no raiz da arvore de Huffman, possuindo
    // ligacao com todos os outros.
    node_t *huffman_root = NULL;
    pop_from_heap_queue(heap_queue, &huffman_root);
    binary_tree_t *huffman_tree = create_bin_tree(huffman_root);

    // Codificacao da string de entrada — mapeamento
    // O maximo de memoria que pode ser ocupado por cada codificacao tem o mesmo tamanho que a altura da arvore
    int huffman_tree_height = bin_tree_height(huffman_root);
    string_t code_buffer_array = (string_t) malloc(huffman_tree_height * sizeof(uchar));
    int top = 0;

    // Vetor de strings para guardar a codificacao [256 unsigned char * -> 256 strings com codigos]
    // os chars nao usados serao representados por null em codigo
    string_t *encoded_chars = (string_t *) calloc(ASCII_SIZE, sizeof(string_t));
    encoding(huffman_root, code_buffer_array, top, encoded_chars);

    // String S codificada
    string_t secret_message = make_coded_message(encoded_chars, string_to_compress, string_to_compress_length);

    int secret_message_length = string_length(secret_message);
    int curr_message_index_to_decode = 0;

    string_t decoded_message = (string_t) malloc((string_to_compress_length + 1) * sizeof(uchar));
    int curr_decoded_index = 0;
    while (curr_message_index_to_decode < secret_message_length) {
        decoded_message[curr_decoded_index++] = decoding(huffman_root, secret_message, &curr_message_index_to_decode);
    }

    decoded_message[curr_decoded_index] = '\0';

    // Saida 
    printf("%s\n", decoded_message);
    double compression_index = secret_message_length / (8 * (double)string_to_compress_length);
    printf("Indice de compressao: %.2lf\n", compression_index);

    // -------------------------------------------------------------------------
    // --------------- Desalocar memoria dinamicamente alocada ---------------
    free(ascii_alphabet);
    free(string_to_compress);

    for (int i = 0; i < ASCII_SIZE; i++) {
        if (encoded_chars[i]) {
            free(encoded_chars[i]);
        }
    }

    free(encoded_chars);
    free(code_buffer_array);
    free(secret_message);
    free(decoded_message);
    destroy_heap_queue(&heap_queue);
    destroy_bin_tree(&huffman_tree);

    return EXIT_SUCCESS;
}