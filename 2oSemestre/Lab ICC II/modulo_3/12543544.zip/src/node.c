/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Lab. ICC II — 2° semestre de 2021
 * Codificacao de Huffman — aplicacao — exercicio modulo III
 * TAD node — implementacao
 */

#include <stdio.h>
#include <stdlib.h>
#include "constants.h"
#include "node.h"

struct Node {
    int symbol;
    int frequency;
    node_t *left_child, *right_child;
};

node_t *create_node() {
    node_t *new_node = (node_t *) malloc(sizeof(node_t));
    
    new_node->left_child = NULL;
    new_node->right_child = NULL;

    return new_node;
}

void set_node_symbol(node_t *node, int symbol) {
    node->symbol = symbol;
}

void set_node_frequency(node_t *node, int frequency) {
    node->frequency = frequency;
}

int get_node_symbol(node_t *node) {
    if (node) {
        return node->symbol;
    }

    return ERROR;
}

int get_node_frequency(node_t *node) {
    if (node) {
        return node->frequency;
    }

    return ERROR;
}

void destroy_node(node_t **node) {
    if (!(*node)) {
        return;
    }
    
    if ((*node)->left_child) {
        destroy_node(&(*node)->left_child);
    }

    if ((*node)->right_child) {
        destroy_node(&(*node)->right_child);
    }

    free((*node));
    *node = NULL;
}

void set_node_child(node_t *parent_node, node_t *child_node, child_t child) {
    switch(child) {
        case LEFT:
            parent_node->left_child = child_node;
            break;
        case RIGHT:
            parent_node->right_child = child_node;
            break;
    }
}

node_t *get_node_child(node_t *parent_node, child_t child) {
    switch(child) {
        case LEFT:
            return parent_node->left_child;
        case RIGHT:
            return parent_node->right_child;
        default:
            return NULL;
    }
}

void print_node(node_t *node) {
    printf("Simbolo: %c, frequencia: %d\n", node->symbol, node->frequency);
    if (node->left_child) {
        printf("Dados filho esquerdo:\n");
        print_node(node->left_child);
    }

    if (node->right_child) {
        printf("Dados filho direito:\n");
        print_node(node->right_child);
    }
}