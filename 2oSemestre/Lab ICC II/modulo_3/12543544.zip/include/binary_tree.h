/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Lab. ICC II — 2° semestre de 2021
 * Codificacao de Huffman — exercicio modulo III
 * TAD tree — cabecalho [visao do usuario]
 */

#ifndef BINARY_TREE_H
#define BINARY_TREE_H

#include "node.h"

// Arvore em si
typedef struct tree {
    node_t *root;
} binary_tree_t;

/* |create_bin_tree| 
 * Aloca arvore vazia (root = NULL) e a retorna.
 * @return (binary_tree_t *): ponteiro para arvore alocada.
 */
binary_tree_t *create_bin_tree(node_t *root);

/* |destroy_bin_tree| 
 * Desaloca recursivamente uma arvore a partir de um no root.
 * @param root (node_t *): ponteiro para no a partir do qual checar (root da subarvore checada).
 */
void destroy_bin_tree(binary_tree_t **bin_tree);

/* |print_bin_tree| 
 * Imprime recursivamente uma arvore a partir de um no root.
 * @param root (node_t *): ponteiro para no a partir do qual imprimir (root da subarvore impressa).
 */
void print_bin_tree(node_t *root);

/* |bin_tree_height| 
 * Retorna o tamanho da arvore.
 * @param root (node_t *): ponteiro para no a partir do qual buscar a altura.
 * @return (int): inteiro que representa a altura da arvore. 
 */
int bin_tree_height(node_t *root);

#endif