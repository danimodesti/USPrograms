/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Lab. ICC II - 2° semestre de 2021
 * Codificacao de Huffman — exercicio modulo III
 * TAD constants - cabecalho [visao do usuario]
 */

#define TRUE 1
#define FALSE 0

#define SUCCESS 6
#define ERROR -1

#define ASCII_SIZE 256
#define BUFFER_SIZE 30

#define EMPTY_VALUE -10