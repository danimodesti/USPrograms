/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Lab. ICC II — 2° semestre de 2021
 * Codificacao de Huffman — exercicio modulo III
 * TAD coding — cabecalho [visao do usuario]
 */

#ifndef CODING_H
#define CODING_H

#include "node.h"
#include "string_utils.h"

typedef unsigned char uchar;

// Estas funcoes lidam com a codificacao de Huffman em si

// Gere a correspondencia de caracteres em binario
void encoding(node_t *root, string_t code_buffer_array, int top, string_t *encoded_chars);

// Traduza o binario da mensagem para seu conteudo original
uchar decoding(node_t *root, string_t secret_message, int *curr_message_index);

// Com a correspondencia de caracteres em binario, codifique a mensagem.
string_t make_coded_message(string_t *correspondance_table, string_t message_to_be_coded, int message_length);

#endif