/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Lab. ICC II — 2° semestre de 2021
 * Codificacao de Huffman — exercicio modulo III
 * TAD node — cabecalho [visao do usuario]
 */

#ifndef NODE_H
#define NODE_H

typedef struct Node node_t;

typedef enum Child {
    LEFT,
    RIGHT
} child_t;

node_t *create_node();

void set_node_symbol(node_t *node, int symbol);

void set_node_frequency(node_t *node, int frequency);

void set_node_child(node_t *parent_node, node_t *child_node, child_t child);

int get_node_symbol(node_t *node);

int get_node_frequency(node_t *node);

node_t *get_node_child(node_t *parent_node, child_t child);

void destroy_node(node_t **node);

void print_node(node_t *node);

#endif