/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Lab. ICC II — 2° semestre de 2021
 * Codificacao de Huffman — exercicio modulo III
 * TAD estrutura heap — cabecalho [visao do usuario]
 */

#ifndef HEAP_H
#define HEAP_H

#include "node.h"

typedef struct HeapQueue heap_queue_t;

heap_queue_t *create_heap_queue();

// Segue a logica de Min Heap para adicionar um valor a fila de prioridade.
int push_to_heap_queue(heap_queue_t *heap_queue, node_t *node_to_push);

// Retira o primeiro elemento (o menor de todos) da fila de prioridade.
int pop_from_heap_queue(heap_queue_t *heap_queue, node_t **node_to_pop);

int is_heap_queue_empty(heap_queue_t *heap_queue);

// Desaloca todos os componentes da fila de prioridade e atribui NULL a estrutura de dados.
void destroy_heap_queue(heap_queue_t **heap_queue);

void print_heap(heap_queue_t *heap_queue);

// Retorna o tamanho da fila de prioridade.
int heap_queue_size(heap_queue_t *heap_queue);

#endif