/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Lab. ICC II - 2° semestre de 2021
 * Codificacao de Huffman — exercicio modulo III
 * TAD string utils - cabecalho [visao do usuario]
 */

#ifndef STRING_UTILS_H
#define STRING_UTILS_H

#include <stdio.h>

// ASCII estendida: unsigned char *
// Senao: char *
typedef unsigned char * string_t; 

// Recebe uma string e retorna seu tamanho, sem considerar o '\0' (char terminador)
int string_length(string_t string);

// Compara se o conteudo de duas strings e igual, retornando TRUE se sim e FALSE se nao.
int content_comparison(string_t string_1, string_t string_2);

// Le string ate chegar num terminator, como ' ', '\r' ou '\n, retornando a.
string_t read_until(char terminator);

// Le ate o fim da linha ('\r' ou '\n), retornando string.
string_t read_line(FILE *stream);

/*
 * Compara duas strings e retorna TRUE caso a string 2 venha antes da 1 na ASCII,
 * ou FALSE caso as strings sejam as mesmas ou a string 1 venha antes da 2 na ASCII (significa
 * que nao ha prioridade da string 2 em relacao a 1).
 */
int string_compare(string_t string_1, string_t string_2);

// Copia o conteudo da memoria de uma variavel para outra. Eh importante que se tenha
// espaco o suficiente alocado para tal.
void *memory_copy(void *dest, void *src, size_t n_bytes);

// Garanta que ha espaco o suficiente para copiar o conteudo da string src para a string dest.
void string_copy(string_t string_src, string_t string_dest);

void string_append(string_t *string_dest, string_t *string_src);

char get_first_char(string_t string);

string_t make_coded_message(string_t *correspondance_table, string_t message_to_be_coded, int message_length);

#endif