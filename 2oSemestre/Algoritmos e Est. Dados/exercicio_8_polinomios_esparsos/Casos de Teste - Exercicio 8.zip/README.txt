Arquivo zip gerado em: 31/01/2023 19:12:57 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Exercício 8