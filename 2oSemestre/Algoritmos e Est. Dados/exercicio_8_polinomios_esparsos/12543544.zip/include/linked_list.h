/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * Exercicio 08 - Polinomios Esparsos 
 * TAD list - cabecalho [visao do usuario]
 */

#ifndef LINKED_LIST_H
#define LINKED_LIST_H

#define TRUE 1
#define FALSE 0

#define SUCCESS 2
#define ERROR -2

typedef struct list list_t; 

/* 
 * Cria/aloca uma estrutura de lista, retornando-a.
 * Atribui NULL ao conteudo da lista (inicio, fim), ainda nao definido. Tambem
 * atribui tamanho zero a lista.
 * Retorna NULL se nao foi possivel criar a estrutura lista.
*/
list_t *create();

/*
 * Libera memoria dinamicamente alocada para a estrutura lista e seu conteudo 
 * interno. Se isso ja ocorreu, retorna ERROR. 
 * Se for bem sucedido, atribui NULL a estrutura.
 * Retorna SUCCESS.
 */
int destroy(list_t **l);

/*
 * Adiciona o elemento x ao fim da lista.
 * Se a lista nao existir, retorna ERROR. Se bem sucedida, retorna SUCCESS.
 *
 */
int push_by_value(list_t *l, int x);

/*
 * Insere um novo elemento x ao indice especificado da lista.
 * Se a lista nao existe ou eh passado um indice invalido, retorna ERROR.
 * Se bem sucedida, retorna SUCCESS.
 */
int push_to_index(list_t *l, int index, int x);

/*
 * Retorna o tamanho atual da lista.
 * Se ela nao existir, retorna ERROR.
 */
int size(list_t *l);

/*
 * Remove um elemento da lista pela passagem de seu valor por referencia. Assim, 
 * se pode receber na main o valor que esta saindo.
 * Se a lista nao existe ou se a retirada foi mal sucedida, retorna ERROR. 
 * Se bem sucedida, retorna SUCCESS.
 */
int pop_by_value(list_t *l, int *x);

/*
 * Remove um elemento da lista pela passagem de seu indice e de uma variavel que
 * guardara o valor que sai da lista por passagem de referencia.
 * Se a lista nao existe ou se a retirada foi mal sucedida, retorna ERROR.
 * Se bem sucedida, retorna SUCCESS.
 */
int pop_by_index(list_t *l, int index, int *element);

/*
 * Retorna o tamanho da lista. Se esta nao existe, retorna ERROR.
 */
int size(list_t *l);

/*
 * Exibe a lista inteira.
 */
void print_list(list_t *l);

/*
 * Rotaciona os elementos da lista para a direita em uma unidade.
 */
void rotate_list(list_t *l);

/*
 * Reverte os elementos da lista, retornando os elementos espelhados.
 */
void revert_list(list_t *l);

/*
 * Permite acesso a dados de um determinado no da lista.
 */
int get_index_info(list_t *l, int index);

/*
 * Permite dar novo valor ao no da lista.
 */
int subscribe_index_info(list_t *l, int index, int new_value);

#endif