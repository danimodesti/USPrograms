/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * Exercicio 08 - Polinomios Esparsos 
 * TAD polynomial - cabecalho [visao do usuario]
 */

#ifndef POLYNOMIAL_H
#define POLYNOMIAL_H

#include "linked_list.h"

typedef struct Polynomial polynomial_t; 

/* 
 * Cria/aloca uma estrutura de polinomio, retornando-a.
 * Atribui NULL ao conteudo do polinomio, ainda nao definido. Tambem
 * atribui tamanho grau '0' ao polinomio.
 * Retorna NULL se nao foi possivel criar a estrutura polinomio.
*/
polynomial_t *create_poly();

int set_max_degree(polynomial_t *p);

int set_coefficients(polynomial_t *p, int *new_coefficient);

void print_polynomial(polynomial_t *p);

int get_degree(polynomial_t *p);

int get_coefficient(polynomial_t *p, int degree);

/*
 * Permite realiza operacao de soma de polinomios inseridos em uma lista de 
 * polinomios.
 */
polynomial_t *polynomial_sum(polynomial_t **p_list, int p_list_size);

/*
 * Libera memoria dinamicamente alocada para a estrutura polinomio e seu conteudo 
 * interno. Se isso ja ocorreu, retorna ERROR. 
 * Se for bem sucedido, atribui NULL a estrutura.
 * Retorna SUCCESS.
 */
int destroy_poly(polynomial_t **p);

#endif