/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * Exercicio 08 - Polinomios Esparsos - aplicacao
 */

#include <stdio.h>
#include <stdlib.h>
#include "linked_list.h"
#include "polynomial.h"

int main() {
    int case_amt;
    scanf("%d", &case_amt);

    // Para cada caso teste da entrada,
    for (int i = 0; i < case_amt; i++) {
        // Criar a lista/o vetor de polinomios
        int poly_amt;
        scanf("%d", &poly_amt);
        polynomial_t **polynomial_list = (polynomial_t **) malloc(poly_amt * sizeof(polynomial_t *));

        // Salvar cada polinomio no vetor de polinomios e seus coeficientes  em uma lista 
        // de coeficientes (os quais sao int e serao armazenados em nos)
        for (int j = 0; j < poly_amt; j++) {
            polynomial_t *new_poly = create_poly();

            int coefficient;
            while ((coefficient = getchar()) != ')') {
                if (coefficient != '(' && coefficient != ',' && coefficient != '\r' && coefficient != '\n') {
                    ungetc(coefficient, stdin);
                    
                    int coefficient;
                    scanf("%d", &coefficient);
                    set_coefficients(new_poly, &coefficient);
                    set_max_degree(new_poly);
                }
            }

            // Inserir o novo polinomio no vetor de polinomios
            polynomial_list[j] = new_poly;
        }

        // Operacao de soma
        polynomial_t *sum = polynomial_sum(polynomial_list, poly_amt);
        printf("(");
        print_polynomial(sum);
        printf(")");
        destroy_poly(&sum);
        printf("\n");

        // ---------------------------------------------------------------------------------------------------
        // Liberando memoria: 
        // Liberar itens da lista/vetor de polinomios (ou seja, liberar as listas/os polinomios)
        for (int j = 0; j < poly_amt; j++) {
            destroy_poly(&polynomial_list[j]);
        }

        // Liberar lista/vetor de polinomios
        free(polynomial_list);
    }

    return EXIT_SUCCESS;
}