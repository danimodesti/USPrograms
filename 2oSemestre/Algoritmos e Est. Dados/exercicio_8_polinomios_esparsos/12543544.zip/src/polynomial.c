/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * Exercicio 08 - Polinomios Esparsos
 * TAD polynomial - implementacao
 */

#include <stdio.h>
#include <stdlib.h>
#include "polynomial.h"

struct Polynomial {
    list_t *coefficients;
    int degree;
};

polynomial_t *create_poly() {
    polynomial_t *p = (polynomial_t *) malloc(sizeof(polynomial_t));

    if (!p) {
        return NULL;
    }

    p->coefficients = NULL;
    p->degree = 0;

    return p;
}

int set_coefficients(polynomial_t *p, int *new_coefficient) {
    if (!p->coefficients) {
        p->coefficients = create();
    }

    push_by_value(p->coefficients, *new_coefficient);

    if (!p->coefficients) {
        return ERROR;
    }

    return SUCCESS;
}

int set_max_degree(polynomial_t *p) {
    if (!p->coefficients) {
        return ERROR;
    }

    p->degree = size(p->coefficients) - 1;

    return SUCCESS;
}

int get_degree(polynomial_t *p) {
    return p->degree;
}

int get_coefficient(polynomial_t *p, int degree) {
    return get_index_info(p->coefficients, degree);
}

void print_polynomial(polynomial_t *p) {
    print_list(p->coefficients);
}

polynomial_t *polynomial_sum(polynomial_t **p_list, int p_list_size) {
    // Armazenar o resultado no seguinte polinomio
    polynomial_t *sum = create_poly();

    // Qual eh o grau desse polinomio resultante? Procurar o maior grau possivel
    // Assumir que o maior grau eh o grau do primeiro polinomio da lista/vetor de polinomios
    int max_degree = p_list[0]->degree;
    for (int i = 1; i < p_list_size; i++) {
        if (p_list[i]->degree > max_degree) {
            max_degree = p_list[i]->degree;
        }
    }

    sum->degree = max_degree;

    int initializer = 0;
    for (int i = 0; i <= sum->degree; i++) {
        // Inicializar coeficientes
        set_coefficients(sum, &initializer);
        
        // Vamos, agora, somar os coeficientes.
        int curr_degree_coef = 0;
        for (int j = 0; j < p_list_size; j++) {
            if (i <= p_list[j]->degree)  {
                curr_degree_coef += get_coefficient(p_list[j], i);
            }
        }

        subscribe_index_info(sum->coefficients, i, curr_degree_coef);   
    }

    return sum;
}

int destroy_poly(polynomial_t **p) {
    if (*p) {
        destroy(&(*p)->coefficients);

        free(*p);

        *p = NULL;

        return SUCCESS;
    }

    return ERROR;
}