/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * Exercicio 09 - Grandes Numeros
 * TAD doubly linked list - implementacao
 */

#include <stdio.h>
#include <stdlib.h>
#include "constants.h"
#include "doubly_linked_list.h"

typedef struct node node_t;

struct node {
    int data;
    node_t *prev, *next;
};

struct list {
    node_t *head, *end;
    int size;
};

list_t *create() {
    list_t *l = (list_t *) malloc(sizeof(list_t));
    
    // Falha de alocacao
    if (!l) {
        return NULL;
    }

    // Indicar que a lista esta vazia
    l->head = NULL;
    l->end = NULL;
    l->size = 0;

    return l;
}

int destroy(list_t **l) {
    if (*l) {
        // Desalocar cada no separadamente
        node_t *p = (*l)->head;

        while (p) {
            (*l)->head = (*l)->head->next;

            free(p);
            p = (*l)->head;
        }
        // Liberar a estrutura lista por inteiro, junto com os ponteiros de inicio e fim
        free(*l);

        *l = NULL;

        return SUCCESS;
    }

    return ERROR;
}

int push(list_t *l, int x) {
    if (!l) {
        return ERROR;
    }

    // Criar o no a ser inserido
    node_t *p = (node_t *) malloc(sizeof(node_t));
    p->data = x;
    p->next = NULL;
    p->prev = NULL;

    // Associar o no a lista l
    // Possibilidades para insercao:

    // 1) inserir a lista vazia: inicio e fim apontam para NULL
    // 2) inserir no inicio da lista
    // 3) inserir no meio da lista
    // 4) inserir no fim da lista

    // Criar ponteiro adicional para percorrer a lista e encontrar onde o no
    // deve ser inserido
    // Usar tambem um ponteiro anterior
    node_t *aux, *prev;
    prev = NULL;
    aux = l->head;

    // Inserindo ordenado na lista
    // aux nulo se chegou ao fim da lista
    while (aux && x > aux->data) {
        prev = aux;
        aux = aux->next;
    }

    // caso onde x ja existe na lista (e estamos considerando que nao ha elementos
    // repetidos)
    // aux != NULL para verificar se aux nao chegou ao fim da lista, evitando segfault
    if (aux && x == aux->data)  {
        free(p);
        return ERROR; // falha na insercao do elemento
    }

    // Podemos inserir o elemento - verificar 4 casos
    
    if (!prev) {
        // Casos possiveis: 1) ou 2)
        // Se for lista vazia: l->head eh NULL. Entao o proximo a partir desse
        // primeiro no agora adicionado sera NULL.
        // Ja se adicionamos no inicio, o inicio anterior da lista se torna o segundo
        // elemento.
        p->next = l->head;

        // Se a lista ja tiver elementos, atualizar o anterior do novo no inserido
        if (l->head) {
            l->head->prev = p;
        }

        // Atualizar o inicio
        l->head = p;
    }

    // Lista nao vazia (prev != NULL)
        // Inserindo no meio ou no fim da lista 
    else {
        // prev != NULL, entao tem um ponteiro para o seu proximo
        p->next = prev->next;
        prev->next = p;

        // Inserindo no meio da lista
        if (p->next) {
            // Anterior do proximo elemento eh o elemento a ser inserido no meio
            p->next->prev = p;
        }

        // p->next == NULL significa que adiciona ao fim da lista
        else {
            l->end = p;
        }

        p->prev = prev;
    }

    l->size++;

    return SUCCESS; // Deu certo a insercao
}

int push_to_index(list_t *l, int index, int x) {
    if (!l) {
        return ERROR;
    }

    // Receba indice valido
    if (index < 0) {
        return ERROR;
    }

    // Vamos inserir novo no para receber elemento x
    node_t *p = (node_t *) malloc(sizeof(node_t));

    p->data = x;
    p->next = NULL;
    p->prev = NULL;

    // Se nao tiver nada na lista, sera o primeiro indice de qualquer modo
    if (!l->head) {
        l->head = p;
        l->end = p;
    } 

    else { 
        // Adicionar ao inicio da lista
        if (index == 0) {
            l->head->prev = p;
            p->next = l->head;
            l->head = p;
        }

        // Adicionar ao final da lista
        else if (index > size(l) - 1) {
            p->prev = l->end;
            l->end->next = p;
            l->end = p;
        }

        // Adicionar ao meio da lista
        else {
            node_t *n = l->head;
            // Percorrer a lista ate chegar no indice desejado
            for (int i = 0; i < index; i++) {
                n->prev = n;
                n = n->next;
            }

            n->prev->next = p;
            p->next = n;
        }
    }

    l->size++;

    return SUCCESS;
}

int pop(list_t *l, int x) {
    // Fazer busca na lista, procurando pelo elemento
    // Remover e atualizar ponteiros
     if (!l) {
        return ERROR;
    }

    node_t *p = l->head;
    node_t *prev = NULL;

    // Buscando pelo elemento a remover
    // se o p->data for > que o x, o elemento nao existe (nessa aplicacao, a lista
    //esta ordenada)
    while (p && x > p->data) {
        prev = p;
        p = p->next;
    }


    if (!p) {
        return ERROR; // Nao encontrou o elemento
    }

    // Se encontrou,
    // remover do inicio, do meio ou do fim?

    // Removendo primeiro elemento da lista
    if (!prev) {
        l->head = l->head->next;

        // O novo inicio nao tem anterior
        if (l->head) {
            l->head->prev = NULL;
        }

        // Lista ficara vazia, com l->head e l->fim nulos
        else {
            l->end = NULL;
        }

        // Liberar o no desconectado
        free(p);
    }

    // Remocao de elemento no meio ou no fim
    else {
        // Removendo do fim da lista 
        if (!p->next) {
            l->end = p->prev;

            // Proximo do anterior sera nulo, pois sera o fim da lista agora
            prev->next = NULL;
            free(p);
        }

        // Removendo do meio da lista
        else {
            prev->next = p->next;
            p->next->prev = prev;
            free(p);
        }
    }

    return SUCCESS; // Remocao deu certo
}

void print(list_t *l) {
    if (!l) {
        return;
    }

    node_t *p = l->head;

    while (p) {
        printf("%d ", p->data);
        p = p->next;
    }

    printf("\n");
}

void reverse_print(list_t *l) {
     if (!l) {
        return;
    }

    node_t *p = l->end;

    while (p) {
        printf("%d", p->data);
        p = p->prev;
    }

    printf("\n");
}

int size(list_t *l) {
    if (!l) {
        return ERROR;
    }

    return l->size;
}

int get_index_info(list_t *l, int index) {
    if (!l) {
        return ERROR;
    }

    if (index >= size(l) || index < 0) {
        return ERROR;
    }

    node_t *p = l->head;
    
    // Encontrar o elemento que desejamos obter
    for (int i = 0; i < index; i++) {
        p = p->next;
    }

    // Retornar o elemento 
    return p->data;
}

// Retornar elemento retirado por referencia, por meio de *element
int pop_by_index(list_t *l, int index, int *element) {
    if (!l) {
        return ERROR;
    }

    if (index >= size(l) || index < 0) {
        return ERROR;
    }

    node_t *p = l->head;
    node_t *prev = NULL;
    
    // Encontrar o elemento que desejamos remover
    for (int i = 0; i < index; i++) {
        prev = p;
        p = p->next;
    }

    // Retornar o elemento por referencia
    *element = p->data;

    // 1. Se for do inicio, index == 0 e vamos retirar o l->head e modifica lo
    // para o elemento a seguir

    if (!prev) {
        l->head = p->next;
    }

    // 2. Se for do fim, index == list_size e vamos retirar o l->end e modifica lo
    // para o elemento anterior

    else if (p == l->end) {
        l->end = prev;
        l->end->next = NULL;
    }

    // 3. Se for do meio, 0 < index < list_size e vamos retirar um no qualquer
    // da lista, modificando o next do prev para tal

    else {
        prev->next = p->next;
    }

    free(p); // Remover elemento atual da lista
    l->size--;

    return SUCCESS;
}