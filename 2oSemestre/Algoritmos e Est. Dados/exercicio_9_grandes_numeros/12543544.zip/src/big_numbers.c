/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * Exercicio 09 - Grandes Numeros
 * TAD big numbers - implementacao
 */

#include <stdio.h>
#include <stdlib.h>
#include "big_numbers.h"
#include "constants.h"
#include "doubly_linked_list.h"
#include "string_utils.h"

struct BigNumber {
    list_t *digits;
    int digits_amt;
    int is_negative;
};

bignum_t *create_big_number(char *str) {
    bignum_t *b = (bignum_t *) malloc(sizeof(bignum_t));

    if (!b) {
        return NULL;
    }

    b->digits = create();
    if (!b->digits) {
        return NULL;
    }

    // Teste de sinal
    b->is_negative = FALSE;
    if (str[0] == '-') {
        b->is_negative = TRUE;
    }

    int start = 0; 
    if (b->is_negative) {
        start = 1;
    }

    // Descartar zeros a esquerda
    while (str[start] == '0' && start < string_size(str) - 1) {
        start++;
    }

    set_digits_amt(b, string_size(str) - start);

    for (int i = start; i < string_size(str); i++) {

        push_to_index(b->digits, 0, (int)(str[i] - '0'));
    }

    return b;
}

// Somar dois numeros grandes passados por parametro.
// Nao precisa criar esse bignum. Ele eh criado aqui dentro.
bignum_t *big_number_sum(bignum_t *first, bignum_t *second) {
    // Armazenar o resultado no seguinte polinomio
    bignum_t *sum = (bignum_t *) malloc(sizeof(bignum_t));
    sum->digits = create();

    // Verificacao de sinais
    int is_addition;
    if (first->is_negative && second->is_negative) {
        sum->is_negative = TRUE;
        is_addition = TRUE;
    }

    else if (!first->is_negative && !second->is_negative) {
        sum->is_negative = FALSE;
        is_addition = TRUE;
    }

    // Sinais opostos - de quem eh o maior modulo?
    else {
        is_addition = FALSE;

        if (is_first_abs_smaller(first, second)) {
            sum->is_negative = second->is_negative;
        }

        else if (is_first_abs_bigger(first, second)) {
            sum->is_negative = first->is_negative;
        }

        // Mesmo modulo e sinais opostos - resulta 0 na soma
        else {
            is_addition = FALSE;
            sum->is_negative = FALSE;
        }
    }

    // O maior grande numero tem maior valor absoluto
    if (is_first_abs_smaller(first, second)) {
        bignum_t *tmp = first;
        first = second;
        second = tmp;
    }

    int i = 0;
    int carry_out = 0;
    while (i < get_digits_amt(first) || i < get_digits_amt(second)) {
        int sum_curr_index;
        if (is_addition) {
            sum_curr_index = get_digit(first, i) + get_digit(second, i) + carry_out;
        
            // Verificar overflow da casa decimal (0 se nao ha e 1 se ha)
            carry_out = sum_curr_index / 10;
        }

        // Eh uma subtracao
        else {
            sum_curr_index = get_digit(first, i) - get_digit(second, i) - carry_out + 10;
            carry_out = 1 - sum_curr_index / 10;
        }

        push_to_index(sum->digits, size(sum->digits), sum_curr_index % 10);
        
        sum->digits_amt++;
        i++;
    }

    // Se continuar com overflow,
    if (carry_out) {
        push_to_index(sum->digits, size(sum->digits), carry_out);
        sum->digits_amt++;
    }

    // Descartar zeros a esquerda
    int j = size(sum->digits) - 1;
    while (j > 0 && get_index_info(sum->digits, j) == 0) {
        int element_to_pop = 1;
        pop_by_index(sum->digits, j, &element_to_pop);
        set_digits_amt(sum, j);
        j--;
    }

    return sum;
}

void print_big_number(bignum_t *b) {
    if (b->is_negative) {
        printf("-");
    }
    reverse_print(b->digits);
}

void set_digits_amt(bignum_t *b, int value) {
    b->digits_amt = value;
}

int get_digits_amt(bignum_t *b) {
    return b->digits_amt;
}

int are_numbers_equal(bignum_t *first, bignum_t *second) {
    int equality;
    if (is_big_number_negative(first) != is_big_number_negative(second)) {
        equality = FALSE;
    }

    else if (get_digits_amt(first) == get_digits_amt(second)) {
        equality = TRUE; // Supondo que sejam iguais
        
        int i = 0;
        while (equality && i < get_digits_amt(first)) {
            if (get_index_info(first->digits, i) != get_index_info(second->digits, i)) {
                equality = FALSE;
            }

            i++;
        }
    }

    else {
        equality = FALSE;
    }

    return equality;
}

int is_first_abs_bigger(bignum_t *first, bignum_t *second) {
    if (get_digits_amt(first) > get_digits_amt(second)) {
        return TRUE;
    }

    else if (are_numbers_equal(first, second)) {
        return FALSE;
    }

    // Teste de valores 
    else if (get_digits_amt(first) == get_digits_amt(second)) {
        int is_first_bigger = FALSE;

        int i = get_digits_amt(first) - 1;
        while (i >= 0 && get_digit(first, i) == get_digit(second, i)) {
            i--;
        }

        if (get_digit(first, i) > get_digit(second, i)) {
            is_first_bigger = TRUE;
        }

        return is_first_bigger;
    }

    else {
        return FALSE;
    }
}

int is_first_abs_smaller(bignum_t *first, bignum_t *second) {
    if (get_digits_amt(first) < get_digits_amt(second)) {
        return TRUE;
    }

    else if (are_numbers_equal(first, second)) {
        return FALSE;
    }

    // Teste de valores 
    else if (get_digits_amt(first) == get_digits_amt(second)) {
        int is_first_smaller = FALSE;

        int i = get_digits_amt(first) - 1;
        while (i >= 0 && get_digit(first, i) == get_digit(second, i)) {
            i--;
        }

        if (get_digit(first, i) < get_digit(second, i)) {
            is_first_smaller = TRUE;
        }

        return is_first_smaller;
    }

    else {
        return FALSE;
    }
}

int is_first_bigger(bignum_t *first, bignum_t *second) {
    // Testar sinais diferentes - primeiro numero naturalmente maior que segundo
    if (!is_big_number_negative(first) && is_big_number_negative(second)) {
        return TRUE;
    }

    // Se os sinais sao iguais, testar quantidade de digitos
    else if (is_big_number_negative(first) == is_big_number_negative(second)) {
        if (get_digits_amt(first) > get_digits_amt(second)) {
            return TRUE;
        }

        else if (are_numbers_equal(first, second)) {
            return FALSE;
        }

        // Teste de valores 
        else if (get_digits_amt(first) == get_digits_amt(second)) {
            int is_first_bigger = FALSE;

            int i = get_digits_amt(first) - 1;
            while (i >= 0 && get_digit(first, i) == get_digit(second, i)) {
                i--;
            }

            if (get_digit(first, i) > get_digit(second, i)) {
                is_first_bigger = TRUE;
            }

            return is_first_bigger;
        }

        else {
            return FALSE;
        }
    }

    else {
        return FALSE;
    }
}

int is_first_smaller(bignum_t *first, bignum_t *second) {
    if (is_big_number_negative(first) && !is_big_number_negative(second)) {
        return TRUE;
    }

    else if (is_big_number_negative(first) == is_big_number_negative(second)) {
        if (get_digits_amt(first) < get_digits_amt(second)) {
            return TRUE;
        } 

        else if (are_numbers_equal(first, second)) {
            return FALSE;
        }

        // Teste de valores 
        else if (get_digits_amt(first) == get_digits_amt(second)) {
            int is_first_smaller = FALSE;

            int i = get_digits_amt(first) - 1;
            while (i >= 0 && get_digit(first, i) == get_digit(second, i)) {
                i--;
            }

            if (get_digit(first, i) < get_digit(second, i)) {
                is_first_smaller = TRUE;
            }

            return is_first_smaller;
        }
        
        else {
            return FALSE;
        }
    }

    else {
        return FALSE;
    }
}

int get_digit(bignum_t *b, int index) {
    if (b->digits_amt > index) {
        return get_index_info(b->digits, index);
    }

    // 'Preencher' grande numero com zeros a esquerda
    return 0;
}

int is_big_number_negative(bignum_t *b) {
    return b->is_negative;
}

int destroy_big_number(bignum_t **b) {
    if (*b) {
        destroy(&(*b)->digits);

        free(*b);

        *b = NULL;

        return SUCCESS;
    }

    return ERROR;
}