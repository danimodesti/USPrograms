/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * Exercicio 09 - Grandes Numeros - aplicacao
 */

#include <stdio.h>
#include <stdlib.h>
#include "big_numbers.h"
#include "constants.h"
#include "doubly_linked_list.h"
#include "string_utils.h"

enum Option {
    SUM_COMMAND = 2, 
    BIG_COMMAND = 3,
    SML_COMMAND = 4,
    EQL_COMMAND = 5
} option_t;

int get_command_option(char *command);

int main() {
    int operation_amt;
    scanf("%d ", &operation_amt);

    for (int i = 0; i < operation_amt; i++) {
        // Leitura de dados da aplicacao
        char *command = read_word();
        int option = get_command_option(command);

        char *first = read_word();
        bignum_t *first_number = create_big_number(first);
        free(first);

        char *second = read_word();
        bignum_t *second_number = create_big_number(second);
        free(second);

        // Verificacao de casos
        if (option == SUM_COMMAND) {
            bignum_t *sum = big_number_sum(first_number, second_number);
            print_big_number(sum);
            destroy_big_number(&sum);
        }

        else if (option == BIG_COMMAND) {
            printf("%d\n", is_first_bigger(first_number, second_number));
        }

        else if (option == SML_COMMAND) {
            printf("%d\n", is_first_smaller(first_number, second_number));
        }

        else if (option == EQL_COMMAND) {
            printf("%d\n", are_numbers_equal(first_number, second_number));
        }

        // Outros comandos sao invalidos.
        else {
            printf("Comando invalido\n");
        }

        free(command);
        destroy_big_number(&first_number);
        destroy_big_number(&second_number);
    }

    return EXIT_SUCCESS;
}

int get_command_option(char *command) {
    if (content_comparison("SUM", command)) {
        return SUM_COMMAND; 
    }

    if (content_comparison("BIG", command)) {
        return BIG_COMMAND; 
    }

    if (content_comparison("SML", command)) {
        return SML_COMMAND; 
    }

    if (content_comparison("EQL", command)) {
        return EQL_COMMAND; 
    }

    return ERROR;
}