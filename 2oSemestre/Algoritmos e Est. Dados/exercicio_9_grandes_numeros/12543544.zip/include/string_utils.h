/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * Exercicio 09 - Grandes Numeros 
 * TAD string utils - cabecalho [visao do usuario]
 */

#ifndef STRING_UTILS_H
#define STRING_UTILS_H

// Recebe uma string e retorna seu tamanho, sem considerar o '\0' (char terminador)
int string_size(char *string);

// Compara se o conteudo de duas strings e igual, retornando TRUE se sim e FALSE se nao.
int content_comparison(char *string_1, char *string_2);

// Le string ate chegar em espaco, '\r' ou '\n, retornando a.
char *read_word();

#endif