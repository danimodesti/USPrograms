/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * Exercicio 09 - Grandes Numeros 
 * TAD big numbers - cabecalho [visao do usuario]
 */

#ifndef BIG_NUMBERS_H
#define BIG_NUMBERS_H

typedef struct BigNumber bignum_t;

// Cria uma estrutura de grande numero, retornando NULL se a alocacao deu errado.
bignum_t *create_big_number(char *str);

// Somar dois numeros grandes passados por parametro. Nao eh necessario
// criar o grande numero que represente a soma, pois aqui eh feita sua alocacao e 
// seus tratamentos completos.
bignum_t *big_number_sum(bignum_t *first, bignum_t *second);

// Exibe o grande numero.
void print_big_number(bignum_t *b);

// Retorna quantidade de digitos do grande numero
int get_digits_amt(bignum_t *b);

// Retorna um digito de um indice especifico do grande numero
int get_digit(bignum_t *b, int index);

// Desaloca a estrutura do grande numero, retornando SUCCESS se deu certo
// e ERROR se nao pode desalocar.
int destroy_big_number(bignum_t **b);

// Testa se dois grandes numeros sao iguais, retornando FALSE se nao e TRUE se sim.
int are_numbers_equal(bignum_t *first, bignum_t *second);

// Testa se o primeiro grande numero eh maior que o segundo.
int is_first_bigger(bignum_t *first, bignum_t *second);

// Testa se o modulo do primeiro grande numero eh maior que o do segundo.
int is_first_abs_bigger(bignum_t *first, bignum_t *second);

// Testa se o modulo do primeiro grande numero eh menor que o do segundo.
int is_first_abs_smaller(bignum_t *first, bignum_t *second);

// Testa se o primeiro grande numero eh menor que o segundo.
int is_first_smaller(bignum_t *first, bignum_t *second);

// Configurar quantidade de digitos de um grande numero a partir de um valor passado por
// parametro.
void set_digits_amt(bignum_t *b, int value);

// Retorna TRUE se o grande numero eh negativo e FALSE se nao for.
int is_big_number_negative(bignum_t *b);

#endif