/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * Exercicio 09 - Grandes Numeros 
 * TAD doubly linked list - cabecalho [visao do usuario]
 */

#ifndef DOUBLY_LINKED_LIST_H
#define DOUBLY_LINKED_LIST_H

typedef int elem;
typedef struct list list_t;

// Cria estrutura de lista duplamente ligada. Retorna NULL se a alocacao nao deu certo.
// Se deu, retorna a lista, com tamanho zero.
list_t *create();

// Destroi estrutura de lista duplamente ligada. Retorna ERROR se desalocacao nao deu certo, 
// e SUCCESS se deu.
int destroy(list_t **l);

// Insere elementos nao repetidos na lista, e de forma ordenada (maiores vao para o fim
// da lista). Retorna ERROR se insercao nao foi possivel, e SUCCESS se foi possivel.
int push(list_t *l, int x);

// Permite inserir um novo elemento em qualquer indice valido da lista. Retorna ERROR se 
// insercao nao foi possivel, e SUCCESS se foi.
int push_to_index(list_t *l, int index, int x);

// Remove elemento da lista por valor.
int pop(list_t *l, int x);

// Exibe toda a informacao contida na lista.
void print(list_t *l);

// Exibe toda a informacao contida na lista, de forma reversa (comecando do fim e 
// indo ate o comeco).
void reverse_print(list_t *l);

// Retorna tamanho atual da lista.
int size(list_t *l);

// Recupera um dado guardado em um determinado no da lista.
int get_index_info(list_t *l, int index);

// Remove elemento a partir de um dado indice, retornando por referencia.
int pop_by_index(list_t *l, int index, int *element);

#endif