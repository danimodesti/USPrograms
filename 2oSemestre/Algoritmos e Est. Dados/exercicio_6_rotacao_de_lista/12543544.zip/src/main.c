/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * Exercicio 06 - Rotacao de lista - aplicacao
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include "linked_list.h"

int main() {
    int case_amt;
    scanf("%d", &case_amt);

    for (int i = 0; i < case_amt; i++) {
        list_t *l = create();

        if (!l) {
            return EXIT_FAILURE;
        }

        int list_element_amt;
        scanf("%d", &list_element_amt);

        int list_rotation_amt;
        scanf("%d", &list_rotation_amt);

        // Adicionar elementos a lista ligada
        for (int i = 0; i < list_element_amt; i++) {
            int new_element;
            scanf("%d", &new_element);
            push(l, new_element);
        }

        for (int i = 0; i < list_rotation_amt; i++) {
            rotate_list(l);
        }
        print_list(l);
        destroy(&l);
    }

    return EXIT_SUCCESS;
}