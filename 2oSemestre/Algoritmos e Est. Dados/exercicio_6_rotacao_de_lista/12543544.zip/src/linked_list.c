/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * Exercicio 06 - Rotacao de lista 
 * TAD list - implementacao
 */

#include <stdio.h>
#include <stdlib.h>
#include "linked_list.h"

typedef struct node node_t;

struct node {
    int data;
    node_t *next;
};

struct list {
    node_t *head, *end;
    int size;
};

list_t *create() {
    list_t *l = (list_t *) malloc(sizeof(list_t));

    if (!l) {
        return NULL;
    }

    l->head = NULL;
    l->end = NULL;
    l->size = 0;

    return l;
}

int destroy(list_t **l) {
    if (*l) {
        node_t *p = (*l)->head;

        while (p) {
            (*l)->head = p->next;

            free(p);
            p = (*l)->head;
        }

        free(*l);

        *l = NULL;

        return SUCCESS;
    }

    return ERROR;
}

int push(list_t *l, int x) {
    if (!l) {
        return ERROR;
    }

    // Vamos inserir novo no para receber elemento x
    node_t *p = (node_t *) malloc(sizeof(node_t));

    p->data = x;
    p->next = NULL;

    if (!l->head) {
        l->head = p;
    } 
    else { 
        l->end->next = p;
    }

    l->end = p;
    l->size++;

    return SUCCESS;
}

int size(list_t *l) {
    if (!l) {
        return ERROR;
    }

    return l->size;
}

void print_list(list_t *l) {
    node_t *p = l->head;

    while (p) {
        printf("%d ", p->data);
        p = p->next;
    }
    printf("\n");
}

// Retornar valor retirado por referencia
int pop_by_value(list_t *l, int *x) {
    if (!l) {
        return ERROR;
    }

    node_t *prev = NULL;
    node_t *p = l->head;

    // Encontrar o elemento que desejamos remover
    while (p) {
        // Elemento encontrado:
        if (p->data == *x) {
            // 1o caso: remover elemento do inicio, como uma fila
            if (!prev) {
                l->head = p->next;  // Mudar o inicio
            }

            // 2o caso: remover elemento do fim, como uma pilha
            else if (p == l->end) {
                l->end = prev;
                l->end->next = NULL;
            }

            // 3o caso: remover elemento do meio, desfazendo o no atual
            else {
                prev->next = p->next;
            }

            free(p); // Remover elemento atual da lista
            l->size--;

            return SUCCESS;
        }

        else {
            prev = p;
            p = p->next;
        }
    }

    return ERROR;
}

// Retornar elemento retirado por referencia, por meio de *element
int pop_by_index(list_t *l, int index, int *element) {
    if (!l) {
        return ERROR;
    }

    if (index > size(l) || index < 0) {
        return ERROR;
    }

    node_t *prev = NULL;
    node_t *p = l->head;
    
    // Encontrar o elemento que desejamos remover
    for (int i = 0; i < index; i++) {
        prev = p;
        p = p->next;
    }

    // Retornar o elemento por referencia
    *element = p->data;

    // 1. Se for do inicio, index == 0 e vamos retirar o l->head e modifica lo
    // para o elemento a seguir

    if (!prev) {
        l->head = p->next;
    }

    // 2. Se for do fim, index == list_size e vamos retirar o l->end e modifica lo
    // para o elemento anterior

    else if (p == l->end) {
        l->end = prev;
        l->end->next = NULL;
    }

    // 3. Se for do meio, 0 < index < list_size e vamos retirar um no qualquer
    // da lista, modificando o next do prev para tal

    else {
        prev->next = p->next;
    }

    free(p); // Remover elemento atual da lista
    l->size--;

    return SUCCESS;
}

int push_to_index(list_t *l, int index, int x) {
    if (!l) {
        return ERROR;
    }

    // Receba indice valido
    if (index < 0) {
        return ERROR;
    }

    // Vamos inserir novo no para receber elemento x
    node_t *p = (node_t *) malloc(sizeof(node_t));

    p->data = x;
    p->next = NULL;

    // Se nao tiver nada na lista, sera o primeiro indice de qualquer modo
    if (!l->head) {
        l->head = p;
        l->end = p;
    } 
    else { 
        // Adicionar ao inicio da lista
        if (index == 0) {
            p->next = l->head;
            l->head = p;
        }

        // Adicionar ao final da lista
        else if (index > size(l) - 1) {
            l->end->next = p;
            l->end = p;
        }

        // Adicionar ao meio da lista
        else {
            node_t *prev = NULL;
            node_t *n = l->head;
            // Percorrer a lista ate chegar no indice desejado
            for (int i = 0; i < index; i++) {
                prev = n;
                n = n->next;
            }

            prev->next = p;
            p->next = n;
        }
    }

    l->size++;

    return SUCCESS;
}

void rotate_list(list_t *l) {
    // Lista ja esta rotacionada
    if (l->size <= 1) {
        return;
    }
    
    // Procurar o elemento por indice, ja que sempre
    // queremos dar pop no final
    int element_to_pop;
    pop_by_index(l, size(l) - 1, &element_to_pop);

    // Vamos adicionar o elemento que retiramos ao inicio da lista
    push_to_index(l, 0, element_to_pop);
}

void reverse_aux(node_t *p, node_t *q, list_t *l) {
  // Caso base: percorri a lista e cheguei ao final dela
  if (!q) {             
    l->head->next = NULL;  // O inicio eh o novo fim

    // O anterior a ele eh o novo inicio da lista
    l->head = p;  // Nova cabeca/head da lista

    return;  // Voltar na recursao
  }

  // Primeiro, percorra a lista ate o final
  reverse_aux(p->next, q->next, l);

  // Depois que voltar da recursao:
  // O p precisa ser o proximo do q
  q->next = p;
}

void revert_list(list_t *l) {
  // Lista ja esta reversa
  if (l->size <= 1) {
    return;
  }

  node_t *p = l->head;
  node_t *q = l->head->next;

  // Chame f. auxiliar recursiva
  reverse_aux(p, q, l);
}
