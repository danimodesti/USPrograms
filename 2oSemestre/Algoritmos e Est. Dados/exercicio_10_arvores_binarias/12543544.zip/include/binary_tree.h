/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * Exercicio 10 - Soma de Nos Filhos
 * TAD tree - cabecalho [visao do usuario]
 */

#ifndef BINARY_TREE_H
#define BINARY_TREE_H

// Nos da arvores
typedef struct node node_t;

// Arvore em si
typedef struct tree {
    node_t *root;
} tree_t;

/* |create_tree| 
 * Aloca arvore vazia (root = NULL) e a retorna.
 * @return (tree_t *): ponteiro para arvore alocada.
 */
tree_t *create_tree();

/* |destroy_tree| 
 * Desaloca recursivamente uma arvore a partir de um no root.
 * @param root (node_t *): ponteiro para no a partir do qual checar (root da subarvore checada).
 */
void destroy_tree_root(node_t *root);

/* |print_tree| 
 * Imprime recursivamente uma arvore a partir de um no root.
 * @param root (node_t *): ponteiro para no a partir do qual imprimir (root da subarvore impressa).
 */
void print_tree(node_t *root);

/* |search_tree| 
 * Busca um elemento a partir de um no root.
 * Retorna o no encontrado e nulo caso contrario.
 * @param root (node_t *): ponteiro para no a partir do qual buscar.
 * @param id_to_find (int): elemento buscado.
 * @return (node_t *): ponteiro para no encontrado. Nulo se nao encontrado. 
 */
node_t *search_tree(node_t *root, int id_to_find);

/* |search_parent| 
 * Busca o pai de um elemento a partir de um no root.
 * @param root (node_t *): ponteiro para no a partir do qual buscar.
 * @param child_id (int): id do elemento cujo pai é buscado.
 * @return (node_t *): ponteiro para no pai encontrado. Nulo se nao encontrado. 
 */
node_t *search_parent(node_t *root, int child_id);

/* |push_left_child| 
 * Insere o filho esquerdo a partir do valor passado de um pai.
 * Se o pai especificado for '-1', insere na root.
 * @param tree (tree_t *): ponteiro para arvore na qual inserir.
 * @param child_id (int): id do no filho.
 * @param value_to_push (int): elemento cujo pai eh buscado para ter seu irmao esquerdo.
 * @param parent_value (int): valor do pai.
 * @return (int): inteiro booleano que indica se a insercao foi realizada com sucesso. 
 */
int push_left_child(tree_t *tree, int child_id, int value_to_push, int parent_value);

/* |push_right_child| 
 * Insere o filho direito a partir do valor passado de um pai.
 * Se o pai especificado for '-1', insere na root.
 * @param tree (tree_t *): ponteiro para arvore na qual inserir.
 * @param child_id (int): id do no filho.
 * @param value_to_push (int): elemento cujo pai eh buscado para ter seu irmao direito.
 * @param parent_value (int): valor do pai.
 * @return (int): inteiro booleano que indica se a insercao foi realizada com sucesso. 
 */
int push_right_child(tree_t *tree, int child_id, int value_to_push, int parent_value);

// Funcao recursiva para colocar nos nos lugares corretos
void put_nodes_in_correct_place(tree_t *tree, int **node_info_list, int curr_id);

// Verifica se o no atual tem seu valor correspondente ao valor de seus nos filhos
void is_curr_node_the_sum_of_its_childs(node_t *root, int *flag);

#endif