/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * Exercicio 10 - Soma de Nos Filhos - aplicacao
 */

#include <stdio.h>
#include <stdlib.h>
#include "binary_tree.h"
#include "constants.h"

int main() {
    tree_t *tree = create_tree();

    if (!tree) {
        return EXIT_FAILURE;
    }

    // Tratando entrada
    int node_amt;
    scanf("%d", &node_amt);

    // Guardar entrada para ter acesso a todos os dados e montar arvore corretamente.
    int **node_info_list = (int **) malloc(node_amt * sizeof(int *));

    for (int i = 0; i < node_amt; i++) {
        // Cada linha tem 4 dados referentes ao no.
        int *curr_node_info = (int *) malloc(4 * sizeof(int));

        // Guardar valor no vetor de valores
        scanf("%d", &curr_node_info[0]);
        scanf("%d", &curr_node_info[1]);
        scanf("%d", &curr_node_info[2]);
        scanf("%d", &curr_node_info[3]);
        
        node_info_list[i] = curr_node_info;
    }

    // Temos todos os dados da entrada armazenados. Agora, organiza los na estrutura
    // de arvore.
    // Definindo a raiz: 
    push_left_child(tree, 0, node_info_list[0][1], -1);

    // Agora, preenchendo arvores com os demais nos.
    put_nodes_in_correct_place(tree, node_info_list, 0);

    // Liberar vetor com a entrada
    for (int i = 0; i < node_amt; i++) {
        free(node_info_list[i]);
    }

    free(node_info_list);

    // A condicao de soma eh atendida?
    int are_all_nodes_sum_of_its_childs = TRUE;
    is_curr_node_the_sum_of_its_childs(tree->root, &are_all_nodes_sum_of_its_childs);

    if (!are_all_nodes_sum_of_its_childs) {
        printf("FALSO\n");
    }

    else {
        printf("VERDADEIRO\n");
    }

    // --- Liberar memoria restante ---
    destroy_tree_root(tree->root);
    free(tree);

    return EXIT_SUCCESS;
}