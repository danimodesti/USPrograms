/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * Exercicio 10 - Soma de Nos Filhos
 * TAD tree - implementacao
 */

#include <stdio.h>
#include <stdlib.h>
#include "binary_tree.h"
#include "constants.h"

struct node {
	int id;
	int data;
	node_t *left_child, *right_child;
};

// Funcao para criar uma arvore. Criamos um ponteiro para o tipo de dado arvore,
// alocando-o.
tree_t *create_tree() {
	tree_t *tree = (tree_t *) malloc(sizeof(tree_t));

	// Configurar o no da raiz para NULL - arvore vazia
	tree->root = NULL;

	// Retorne a arvore.
	return tree;
}

// Destruir a arvore. Precisamos chegar ate uma folha e, chegando nela,
// a removemos (free) e voltamos para o anterior.
// Para navegar por entre a arvore, toda vez que descemos para um no mais abaixo, 
// usamos recursao. Para voltar, voltamos da recursao. 
void destroy_tree_root(node_t *root) {
	if (root) {
		// Destruir filho esquerdo
		destroy_tree_root(root->left_child);

		// Destruir filho direito
		destroy_tree_root(root->right_child);
		
		// Ao chegar aqui, nao ha mais filhos esquerdos ou direitos validos.
		// Podemos liberar a raiz, finalmente.
		free(root);
	}
}

// Imprimiremos os dados da arvore da seguinte forma:
// temos o no 5(3, 6) -> notacao com no(filho_esq, filho_dir)

// se um dos filhos do 5 tem filhos, abrimos mais um parenteses.
// ex.: 5(3, 6(2, 1))  ...
// se for ponteiro NULL, podemos escrever: 5(3, 6(2, x)) -> no 6 tem apenas
// filho esquerdo.
void print_tree(node_t *root) {
	if (root) {
		printf("%d (", root->data);
		// Chamada recursiva
		print_tree(root->left_child);

		// Na volta da recursao acima,
		printf(",");
		print_tree(root->right_child);
		printf(")");
	}
	
	// Raiz nula
	else {
		printf("x");
	}
}


// Fazer busca na arvore -> tenho, no caso, um id, passado como parametro,
// a funcao retorna o ponteiro para o no que contem esse id.
node_t *search_tree(node_t *root, int id_to_find) {
	if (!root) {
		return NULL; // Arvore vazia.
	}

	// Se o elemento estiver na raiz,
	if (root->id == id_to_find) {
		return root;
	}

	// Senao, o id pode estar na subarvore da esquerda ou na subarvore da direita.
	// Fazer busca novamente para subarvore da esquerda e para a subarvore da 
	// direita.

	// Ponteiro auxiliar que recebe resultado da busca para a raiz do lado
	// esquerdo e o id procurado
	node_t *aux = search_tree(root->left_child, id_to_find);
	
	// O id nao esta no lado esquerdo
	if (!aux) {
		aux = search_tree(root->right_child, id_to_find);
	}

	// Pode ser um ponteiro valido ou nulo (esta opcao significa que id nao
	// esta nem ao lado esquerdo nem ao direito)
	return aux;
}

// Busca pelo pai, com seu id passado como parametro. 
// Passamos o id e a funcao retorna o ponteiro para o pai cujo filho tenha esse id.
node_t *search_parent(node_t *root, int child_id) {
	// Logica similar a de busca, mas trabalhar com ponteiros 'indiretos'
	if (!root) {
		return NULL; // Arvore vazia
	}

	if (root->left_child && root->left_child->id == child_id) {
		return root; // acesso 'indireto' ao pai -> olhar id do filho para acessar
					// pai.
	}

	if (root->right_child && root->right_child->id == child_id) {
		return root;
	}

	// Busca recursiva no lado esquerdo e, se nao encontrar, fazer o mesmo para o 
	// lado direito.
	node_t *curr = search_parent(root->left_child, child_id);
	
	if (!curr) {
		curr = search_parent(root->right_child, child_id);
	}

	return curr;
}

// Inserir a esquerda. Passamos o elem x que desejamos inserir e o elemento
// pai do x, que deve existir na arvore.
// O elemento x sera inserido a esquerda do pai.
// Se pai == -1 => inserir na raiz
// caso contrario, insere do lado esquerdo de pai
int push_left_child(tree_t *tree, int child_id, int value_to_push, int parent_id) {
	// Alocar o no
	node_t *new_node = (node_t *) malloc(sizeof(node_t));

	new_node->id = child_id;
	new_node->data = value_to_push;

	// Setar filhos inexistentes
	new_node->left_child = NULL;
	new_node->right_child = NULL;

	// Inserir na raiz
	if (parent_id == -1) {
		// Para inserir na raiz, antes verificar se a raiz da arvore ainda nao
		// existe.
		if (!tree->root) {
			tree->root = new_node;
		}

		// Arvore ja tem raiz	
		else {
			free(new_node);
			return FALSE; // Nao consegui inserir o elemento
		}
	}

	// Se pai != -1, inserir ao lado esquerdo do pai que passei como parametro.
	else {
		// Busca pelo pai para inserir o elemento ao seu lado esquerdo.
		node_t *aux = search_tree(tree->root, parent_id);
		// Se encontrei o pai e ele existe, alem do pai nao ter filho esquerdo:
		if (aux && !aux->left_child) {
			aux->left_child = new_node;
		}
		
		// Nao consigo fazer insercao
		else {
			free(new_node);
			return FALSE;
		}
	}

	// Insercao com sucesso!
	return TRUE;
}

// O pai deve existir. Inserir o filho ao lado direito do pai.
int push_right_child(tree_t *tree, int child_id, int value_to_push, int parent_id) {
	// Alocar o no
	node_t *new_node = (node_t *) malloc(sizeof(node_t));

	new_node->id = child_id;
	new_node->data = value_to_push;

	// Setar filhos inexistentes
	new_node->left_child = NULL;
	new_node->right_child = NULL;

	// Inserir na raiz
	if (parent_id == -1) {
		if (!tree->root) {
			tree->root = new_node;
		}

		else {
			free(new_node);

			return FALSE; // Nao consegui inserir o elemento
		}
	}

	// Se pai != -1, inserir ao lado direito do pai que passei como parametro.
	else {
		// Busca pelo pai para inserir o elemento ao seu lado direito.
		node_t *aux = search_tree(tree->root, parent_id);
		// Se encontrei o pai e ele existe, alem do pai nao ter filho direito:
		if (aux && !aux->right_child) {
			aux->right_child = new_node;
		}
		
		// Nao consigo fazer insercao
		else {
			free(new_node);

			return FALSE;
		}
	}

	// Insercao com sucesso!
	return TRUE;
}

void put_nodes_in_correct_place(tree_t *tree, int **node_info_list, int curr_id) {
	// Se no tiver filhos,
	if (node_info_list[curr_id][2] != -1) {
		push_left_child(tree, node_info_list[curr_id][2], node_info_list[node_info_list[curr_id][2]][1], node_info_list[curr_id][0]);
		
		// Passo recursivo
		put_nodes_in_correct_place(tree, node_info_list, node_info_list[curr_id][2]);
	}

	if (node_info_list[curr_id][3] != -1) {
		push_right_child(tree, node_info_list[curr_id][3], node_info_list[node_info_list[curr_id][3]][1], node_info_list[curr_id][0]);
		
		// Passo recursivo
		put_nodes_in_correct_place(tree, node_info_list, node_info_list[curr_id][3]);
	}
}

void is_curr_node_the_sum_of_its_childs(node_t *root, int *flag) {
	if (!root) {
		return; // Arvore vazia
	}

	if (!root->data || !root->left_child || !root->right_child) {
		return;
	}

	// Feriu a condicao
	if (root->data != root->left_child->data + root->right_child->data) {
		*flag = FALSE;

		return;
	}

	is_curr_node_the_sum_of_its_childs(root->left_child, flag);

	is_curr_node_the_sum_of_its_childs(root->right_child, flag);
}