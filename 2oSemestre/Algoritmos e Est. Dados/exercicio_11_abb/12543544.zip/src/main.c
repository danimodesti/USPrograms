/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * Exercicio 11 - Impressao de Arvores Binarias de Busca - aplicacao
 */

#include <stdio.h>
#include <stdlib.h>
#include "binary_search_tree.h"
#include "constants.h"
#include "string_utils.h"

typedef enum Commands {
    PRINT_DATA,
    INSERT_DATA
} command_t;

typedef enum VisitationMode {
    PRE_ORDER,
    IN_ORDER,
    POS_ORDER
} visitation_t;

int get_command_option(char *command);
int get_visitation_mode_option(char *visitation_mode);

int main() {
    tree_t *tree = create_tree();

    if (!tree) {
        return EXIT_FAILURE;
    }

    char curr_char;
    while ((curr_char = getchar()) != EOF) {
        ungetc(curr_char, stdin);

        char *command = read_until(' ');
        int option = get_command_option(command);
        free(command);

        if (option == PRINT_DATA) {
            char *visitation_mode = read_line();
            int visit = get_visitation_mode_option(visitation_mode);
            free(visitation_mode);

            if (is_tree_empty(tree)) {
                printf("VAZIA\n");
            }

            else {
                if (visit == PRE_ORDER) {
                    pre_order_visit(tree->root);
                    printf("\n");
                }

                else if (visit == IN_ORDER) {
                    in_order_visit(tree->root);
                    printf("\n");
                }

                else if (visit == POS_ORDER) {
                    pos_order_visit(tree->root);
                    printf("\n");
                }

                else {
                    printf("Percurso invalido! =S\n");
                }
            }
        }

        else if (option == INSERT_DATA) {
            int key_to_insert;
            scanf("%d", &key_to_insert);
            push(&(tree->root), key_to_insert);
        }

        else {
            printf("Comando invalido! =(\n");
        }
    }

    // --- Liberar memoria ---
    destroy_tree_root(tree->root);
    free(tree);

    return EXIT_SUCCESS;
}

int get_command_option(char *command) {
    if (content_comparison("impressao", command)) {
        return PRINT_DATA; 
    }

    if (content_comparison("insercao", command)) {
        return INSERT_DATA; 
    }

    return ERROR;
}

int get_visitation_mode_option(char *visitation_mode) {
    if (content_comparison("pre-ordem", visitation_mode)) {
        return PRE_ORDER; 
    }

    if (content_comparison("em-ordem", visitation_mode)) {
        return IN_ORDER; 
    }

    if (content_comparison("pos-ordem", visitation_mode)) {
        return POS_ORDER; 
    }

    return ERROR;
}