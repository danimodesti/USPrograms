/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * Exercicio 11 - Impressao de Arvores Binarias de Busca
 * TAD binary search tree - implementacao
 */

#include <stdio.h>
#include <stdlib.h>
#include "binary_search_tree.h"
#include "constants.h"

struct node {
	int data;
	node_t *left_child, *right_child;
};

// Funcao para criar uma arvore. Criamos um ponteiro para o tipo de dado arvore,
// alocando-o.
tree_t *create_tree() {
	tree_t *tree = (tree_t *) malloc(sizeof(tree_t));

	// Configurar o no da raiz para NULL - arvore vazia
	tree->root = NULL;

	// Retorne a arvore.
	return tree;
}

int is_tree_empty(tree_t *tree) {
	// A arvore existe/eh valida?	
	if (!tree) {
        return ERROR;
    }

	if (!tree->root) {
		return TRUE; // Vazia
	}

	return FALSE; // Nao vazia
}

// Destruir a arvore. Precisamos chegar ate uma folha e, chegando nela,
// a removemos (free) e voltamos para o anterior.
// Para navegar por entre a arvore, toda vez que descemos para um no mais abaixo, 
// usamos recursao. Para voltar, voltamos da recursao. 
void destroy_tree_root(node_t *root) {
	if (root) {
		// Destruir filho esquerdo
		destroy_tree_root(root->left_child);

		// Destruir filho direito
		destroy_tree_root(root->right_child);
		
		// Ao chegar aqui, nao ha mais filhos esquerdos ou direitos validos.
		// Podemos liberar a raiz, finalmente.
		free(root);
	}
}

// Imprimiremos os dados da arvore da seguinte forma:
// temos o no 5(3, 6) -> notacao com no(filho_esq, filho_dir)

// se um dos filhos do 5 tem filhos, abrimos mais um parenteses.
// ex.: 5(3, 6(2, 1))  ...
// se for ponteiro NULL, podemos escrever: 5(3, 6(2, null)) -> no 6 tem apenas
// filho esquerdo.
void print_tree(node_t *root) {
	if (root) {
		printf("valor %d(", root->data);
		// Chamada recursiva
		print_tree(root->left_child);

		// Na volta da recursao acima,
		printf(",");
		print_tree(root->right_child);
		printf(")");
	}
	
	// Raiz nula
	else {
		printf("null");
	}
}

// Altura de uma arvore
int tree_height(node_t *root) {
	// Arvore vazia, sem altura
	if (!root) {
		return 0;
	}

	// Se raiz existe (o que ja me da altura 1), encontramos a altura da subarvore
	// da esquerda + 1.
	// Calcular altura subarvore da direita + 1
	int left_child_height = 1 + tree_height(root->left_child);
	int right_child_height = 1 + tree_height(root->right_child);

	// Achar o maximo entre eles para a altura da arvore.
	if (left_child_height > right_child_height) {
		return left_child_height;
	}

	return right_child_height;
}

node_t *search_tree(node_t *root, int value_to_find) {
	// 1o caso -> arvore vazia (ponteiro da raiz da arvore eh nulo)
	if (!root) {
		return NULL; // Nao encontrou a chave
	}

	// 2o caso -> chave buscada == no
	if (root->data == value_to_find) {
		return root; // retorna ponteiro para o no no qual encontramos x
	}

	// 3o caso -> chave < elemento da raiz 'atual'
	// Valor pode estar na subarvore esquerda
	if (value_to_find < root->data) {
		return search_tree(root->left_child, value_to_find);
	}

	// 4o caso -> chave > elemento da raiz 'atual'
	// Valor pode estar na subarvore direita
	else {
		return search_tree(root->right_child, value_to_find);
	}
}

int push(node_t **root, int value_to_push) {
	// 1o caso -> raiz nula
	if (!(*root)) {
		*root = (node_t *) malloc(sizeof(node_t));

		(*root)->data = value_to_push;
		(*root)->left_child = NULL;
		(*root)->right_child = NULL;

		return SUCCESS;
	}

	// 2o caso -> elemento ja na arvore. Finalize insercao sem alterar nada.
	if (value_to_push == (*root)->data) {
		
		// Nao faca nada e nao insira
		return FALSE;
	}

	// 3o caso
	if (value_to_push < (*root)->data) {
		// Para acessar campo, traduza o ponteiro de ponteiro. Porem, 
		// passe a referencia pois eh o que a funcao recebe (& -> para indicar o
		// endereco do ponteiro desejado/acessado)
		return push(&(*root)->left_child, value_to_push);
	}

	// 4o caso
	else {
		return push(&(*root)->right_child, value_to_push);
	}
}

// Funcoes de percurso em arvore ----------------------------------------------
	// mesma coisa que em uma AB (arvore binaria)

void pre_order_visit(node_t *root) {
	// Somente enquanto arvore nao for vazia, pois, se for, finaliza
	if (root) {
		// Visitar raiz, imprimindo o elemento
		printf("%d ", root->data);

		// Percorrer subarvore da esquerda em processo recursivo
		pre_order_visit(root->left_child);

		// Percorrer subarvore da direita em processo recursivo
		pre_order_visit(root->right_child);
	}
}

void in_order_visit(node_t *root) {
	// Somente enquanto arvore nao for vazia, pois se for, finaliza
	if (root) {
		// Percorrer subarvore da esquerda em processo recursivo
		in_order_visit(root->left_child);

		// Visitar raiz, imprimindo o elemento
		printf("%d ", root->data);

		// Percorrer subarvore da direita em processo recursivo
		in_order_visit(root->right_child);
	}
}

void pos_order_visit(node_t *root) {
	// Somente enquanto arvore nao for vazia, pois se for, finaliza
	if (root) {
		// Percorrer subarvore da esquerda em processo recursivo
		pos_order_visit(root->left_child);

		// Percorrer subarvore da direita em processo recursivo
		pos_order_visit(root->right_child);

		// Visitar raiz, imprimindo o elemento
		printf("%d ", root->data);
	}
}