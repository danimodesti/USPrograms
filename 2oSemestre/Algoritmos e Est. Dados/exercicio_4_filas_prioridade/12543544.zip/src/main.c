/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * Exercicio 04 - Filas de prioridade - aplicacao
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include "queue.h"
#include "person.h"

#define REMOVE_COMMAND 2
#define ADD_COMMAND 3

char *read_command();
int content_comparison(char *string_1, char *string_2);
int string_size(char *string);
int check_command_status(char *command);

int main() {
    int action_amt;
    scanf("%d", &action_amt);

    queue_t *q = create(); 
    
    for (int i = 0; i < action_amt; i++) {
        char *command = read_command();
        int action = check_command_status(command);
        free(command);

        if (action == REMOVE_COMMAND) {
            if (size(q) == 0) {
                printf("FILA VAZIA\n");
            }
            else { 
                person_t *p;
                pop(q, &p);
                print_person_info(p);
                destroy_person(&p);
            }
        }

        else if (action == ADD_COMMAND) {
            person_t *p = create_person();
            read_person_info(p);

            if (size(q) == 100) {
                printf("FILA CHEIA\n");
            }
            else {
                push(q, p);
            }
        }
    }
    destroy(&q);

    return EXIT_SUCCESS;
}

char *read_command() {
    int curr_char;
    int command_size = 0;
    char *command = NULL;

    do {
        curr_char = getchar();
    } while (curr_char == '\r' || curr_char == '\n' || curr_char == ' ');
    if (curr_char != EOF) {
        ungetc(curr_char, stdin);
    }

    do {
        curr_char = getchar();
        command_size++;

        command = (char *) realloc(command, command_size * sizeof(char));

        if (curr_char != ' ' && curr_char != '\r' && curr_char != '\n' && curr_char != EOF) {
            command[command_size - 1] = curr_char;
        }
        else {
            command[command_size - 1] = '\0';
        }

    } while (curr_char != ' ' && curr_char != '\r' && curr_char != '\n' && curr_char != EOF);

    if (!command) {
        return NULL;
    } 

    return command;
}

int content_comparison(char *string_1, char *string_2) {
    int str_1_length, str_2_length;
    str_1_length = string_size(string_1);
    str_2_length = string_size(string_2);

    if (str_1_length != str_2_length) {
        return FALSE;
    }

    int i = 0;
    while (string_1[i] != '\0') {
        if (string_1[i] != string_2[i]) {
            return FALSE;
        }
        i++;
    }

    return TRUE;
}

int check_command_status(char *command) {
    if (content_comparison("SAI", command)) {
        return REMOVE_COMMAND; 
    }

    if (content_comparison("ENTRA", command)) {
        return ADD_COMMAND; 
    }

    return ERROR;
}

int string_size(char *string) {
    int length = 0;
    while (string[length] != '\0') {
        length++;
    }

    return length;
}