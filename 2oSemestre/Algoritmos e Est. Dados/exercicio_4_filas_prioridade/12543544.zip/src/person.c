/*
 * Nome: Danielle Modesti
 * Node USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * Exercicio 04 - Filas de prioridade 
 * TAD person - implementacao
 */

#include <stdio.h>
#include <stdlib.h>
#include "person.h"

#define OLD 60

struct person {
    char *name;
    int age;
    int health_issue;
};

person_t *create_person() {
    person_t *p = (person_t *) malloc(sizeof(person_t));  
  
    if(!p) {
        return NULL;
    }

    // Inicializando campos
    p->name = NULL;
    p->age = ERROR;
    p->health_issue = ERROR;

    return p;
}

int destroy_person(person_t **p) {
    if (*p) {               
        free((*p)->name);         
        (*p)->name = NULL;

        free(*p);
        *p = NULL;

        return TRUE;
    }

    return FALSE;
}

int read_person_name(person_t *p) {
    if (!p) {
        return FALSE;
    }
    
    int curr_char;
    int name_size = 0;

    do {
        curr_char = getchar();
        name_size++;

        p->name = (char *) realloc(p->name, name_size * sizeof(char));

        if (curr_char != ' ') {
            p->name[name_size - 1] = curr_char;
        }
        else {
            p->name[name_size - 1] = '\0';
        }

    } while (curr_char != ' ');

    if (!p->name) {
        return ERROR;
    } 

    return TRUE;
}

int read_person_info(person_t *p) {
    read_person_name(p);

    scanf("%d", &p->age);
    if (p->age == ERROR) {
        return ERROR;
    }

    scanf("%d", &p->health_issue);
    if (p->health_issue == ERROR) {
        return ERROR;
    }

    return TRUE;
}

void print_person_info(person_t *p) {
    printf("%s ", p->name);
    printf("%d ", p->age);
    printf("%d\n", p->health_issue);
}

int is_old(person_t *p) {
    return p->age >= OLD;
}

int is_healthy(person_t *p) {
    return !p->health_issue;
}

int get_priority(person_t *p) {
    if (!p) {
        return ERROR;
    }

    int priority = 4;

    if (is_old(p) && is_healthy(p)) {
        priority = 3;
    }

    else if (!is_old(p) && !is_healthy(p)) {
        priority = 2;
    }

    else if (is_old(p) && !is_healthy(p)) {
        priority = 1;
    }

    return priority;
}