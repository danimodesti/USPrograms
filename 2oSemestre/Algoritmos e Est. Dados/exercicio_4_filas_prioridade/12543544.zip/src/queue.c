/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * Exercicio 04 - Filas de prioridade 
 * TAD queue - implementacao
 */


#include <stdio.h>
#include <stdlib.h>
#include "queue.h"
#include "person.h"

typedef struct node node_t;

struct node {
    person_t *data;
    node_t *next;
};

struct queue {
    node_t *head, *end;
    int size;
};

queue_t *create() {
    queue_t *q = (queue_t *) malloc(sizeof(queue_t));

    if (!q) {
        return NULL;
    }

    q->head = NULL;
    q->end = NULL;
    q->size = 0;

    return q;
}

int destroy(queue_t **q) {
    if (*q) {
        node_t *p = (*q)->head;

        while (p) {
            (*q)->head = p->next;

            if (p->data) {
                destroy_person(&p->data);
            }

            free(p);
            p = (*q)->head;
        }

        free(*q);

        *q = NULL;

        return TRUE;
    }

    return FALSE;
}

int push(queue_t *q, person_t *person) {
    int priority = get_priority(person);

    if (!q) {
        return ERROR;
    }

    node_t *p = (node_t *) malloc(sizeof(node_t));

    p->data = person;
    p->next = NULL;

    if (!q->head) {
        q->head = p;
        q->end = p;
    } 
    else { // Fazer a prioridade
        if (priority == 4) {
            q->end->next = p; // Se for pessoa nao idosa e sem agravante
            q->end = p;
        }

        else {
            node_t *n = q->head;
            node_t *prev = NULL;

            // A posicao da nova pessoa sera logo apos todas as pessoas com
            // prioridade mais urgente e as com prioridade igual que estao na frente
            while (get_priority(n->data) <= get_priority(person)) {
                prev = n;
                n = n->next;
            }
        
            if (!prev) {
                p->next = q->head;
                q->head = p;
            }

            else {
                prev->next = p;
                p->next = n;
            }
        }
    }

    q->size++;

    return TRUE;
}

int size(queue_t *q) {
    if (!q) {
        return ERROR;
    }

    return q->size;
}

int print_queue(queue_t *q) {
    if (!q) {
        return ERROR;
    }

    node_t *p = q->head;

    while (p) {
        print_person_info(p->data);
        printf("\n");
        p = p->next;
    }

    return TRUE;
}

int pop(queue_t *q, person_t **person) {
    if (!q) {
        return ERROR;
    }

    *person = q->head->data;
    node_t *p = q->head;
    q->head = p->next;  // Mudar o inicio
    free(p);            // Remover elemento atual da lista

    q->size--;

    return TRUE;
}