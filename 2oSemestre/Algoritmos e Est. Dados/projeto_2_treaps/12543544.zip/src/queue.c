/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * Projeto 2 — Arvores Treaps
 * TAD queue - implementacao
 */


#include <stdio.h>
#include <stdlib.h>
#include "queue.h"

typedef struct queue_node queue_node_t;

struct queue_node {
    treap_node_t *data;
    queue_node_t *next;
};

struct queue {
    queue_node_t *head, *end;
    int size;
};

queue_t *queue_create() {
    queue_t *q = (queue_t *) malloc(sizeof(queue_t));

    if (!q) {
        return NULL;
    }

    q->head = NULL;
    q->end = NULL;
    q->size = 0;

    return q;
}

int queue_destroy(queue_t **q) {
    if (*q) {
        queue_node_t *p = (*q)->head;

        while (p) {
            (*q)->head = p->next;

            free(p);
            p = (*q)->head;
        }

        free(*q);

        *q = NULL;

        return TRUE;
    }

    return FALSE;
}

int queue_push(queue_t *q, treap_node_t *node_to_push) {
    if (!q) {
        return ERROR;
    }

    queue_node_t *new_node = (queue_node_t *) malloc(sizeof(queue_node_t));

    new_node->data = node_to_push;
    new_node->next = NULL;

    if (!q->head) {
        q->head = new_node;
        q->end = new_node;
    } 

    else { 
        q->end->next = new_node; 
        q->end = new_node;
    }

    q->size++;

    return TRUE;
}

int queue_size(queue_t *q) {
    if (!q) {
        return ERROR;
    }

    return q->size;
}

int is_queue_empty(queue_t *q) {
    if (q->size == 0) {
        return TRUE;
    }

    return FALSE;
}

treap_node_t *queue_pop(queue_t *q) {
    if (!q) {
        return NULL;
    }

    queue_node_t *p = q->head;
    treap_node_t *node_to_pop = p->data;

    q->head = p->next;  // Mudar o inicio
    free(p);            // Remover elemento atual da lista

    q->size--;

    return node_to_pop;
}