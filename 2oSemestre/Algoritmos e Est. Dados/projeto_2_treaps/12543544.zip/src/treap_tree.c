/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * Projeto 2 — Arvores Treaps
 * TAD treap tree - implementacao
 */

#include <stdio.h>
#include <stdlib.h>
#include "constants.h"
#include "queue.h"
#include "treap_tree.h"

struct node {
	int key;
	int priority;
	node_t *left_child, *right_child;
};

// Funcao para criar uma arvore. Criamos um ponteiro para o tipo de dado arvore,
// alocando-o.
tree_t *create_tree() {
	tree_t *tree = (tree_t *) malloc(sizeof(tree_t));

	// Configurar o no da raiz para NULL - arvore vazia
	tree->root = NULL;

	// Retorne a arvore.
	return tree;
}

int is_tree_empty(tree_t *tree) {
	// A arvore existe/eh valida?	
	if (!tree) {
        return ERROR;
    }

	if (!tree->root) {
		return TRUE; // Vazia
	}

	return FALSE; // Nao vazia
}

// Destruir a arvore. Precisamos chegar ate uma folha e, chegando nela,
// a removemos (free) e voltamos para o anterior.
// Para navegar por entre a arvore, toda vez que descemos para um no mais abaixo, 
// usamos recursao. Para voltar, voltamos da recursao. 
void destroy_tree_root(node_t *root) {
	if (root) {
		// Destruir filho esquerdo
		destroy_tree_root(root->left_child);

		// Destruir filho direito
		destroy_tree_root(root->right_child);
		
		// Ao chegar aqui, nao ha mais filhos esquerdos ou direitos validos.
		// Podemos liberar a raiz, finalmente.
		free(root);
	}
}

// Imprimiremos os dados da arvore da seguinte forma:
// temos o no 5(3, 6) -> notacao com no(filho_esq, filho_dir)

// se um dos filhos do 5 tem filhos, abrimos mais um parenteses.
// ex.: 5(3, 6(2, 1))  ...
// se for ponteiro NULL, podemos escrever: 5(3, 6(2, null)) -> no 6 tem apenas
// filho esquerdo.
void print_tree(node_t *root) {
	if (root) {
		printf("valor %d, prioridade %d(", root->key, root->priority);
		// Chamada recursiva
		print_tree(root->left_child);

		// Na volta da recursao acima,
		printf(",");
		print_tree(root->right_child);
		printf(")");
	}
	
	// Raiz nula
	else {
		printf("null");
	}
}

// Altura de uma arvore
int tree_height(node_t *root) {
	// Arvore vazia, sem altura
	if (!root) {
		return 0;
	}

	// Se raiz existe (o que ja me da altura 1), encontramos a altura da subarvore
	// da esquerda + 1.
	// Calcular altura subarvore da direita + 1
	int left_child_height = 1 + tree_height(root->left_child);
	int right_child_height = 1 + tree_height(root->right_child);

	// Achar o maximo entre eles para a altura da arvore.
	if (left_child_height > right_child_height) {
		return left_child_height;
	}

	return right_child_height;
}

int search_tree(node_t *root, int value_to_find) {
	// 1o caso -> arvore vazia (ponteiro da raiz da arvore eh nulo)
	if (!root) {
		return FALSE; // Nao encontrou a chave
	}

	// 2o caso -> chave buscada == no
	if (root->key == value_to_find) {
		return TRUE; // retorna ponteiro para o no no qual encontramos x
	}

	// 3o caso -> chave < elemento da raiz 'atual'
	// Valor pode estar na subarvore esquerda
	if (value_to_find < root->key) {
		return search_tree(root->left_child, value_to_find);
	}

	// 4o caso -> chave > elemento da raiz 'atual'
	// Valor pode estar na subarvore direita
	else {
		return search_tree(root->right_child, value_to_find);
	}
}

node_t *create_new_node(node_t *root, int key_to_push, int key_priority) {
	root = (node_t *) malloc(sizeof(node_t));

	root->key = key_to_push;
	root->priority = key_priority;
	root->left_child = NULL;
	root->right_child = NULL;

	return root;
}

// Funcoes para rotacionar nos e balancear arvore [manter MaxHeap]
// no desbalanceado = raiz relativa
node_t *left_rotation(node_t *unbalanced) {
	node_t *aux = unbalanced->right_child;

	unbalanced->right_child = aux->left_child;

	aux->left_child = unbalanced;

	unbalanced = aux;

	return unbalanced;
}

node_t *right_rotation(node_t *unbalanced) {
	node_t *aux = unbalanced->left_child;

	unbalanced->left_child = aux->right_child;

	aux->right_child = unbalanced;

	unbalanced = aux;

	return unbalanced;
}

node_t *push(node_t *root, int key_to_push, int key_priority) {
	// Ordenar por logica de ABB
	// 1o caso -> raiz nula
	// crie novo no e o retorne
	if (!root) {
		return create_new_node(root, key_to_push, key_priority);
	}

	// 2o caso -> elemento ja na arvore. Finalize insercao sem alterar nada.
	if (key_to_push == root->key) {
		// Nao faca nada e nao insira
		printf("Elemento ja existente\n");
	}

	// 3o caso
	// chave eh menor que raiz
	else if (key_to_push < root->key) {
		// Para acessar campo, traduza o ponteiro de ponteiro. Porem, 
		// passe a referencia pois eh o que a funcao recebe (& -> para indicar o
		// endereco do ponteiro desejado/acessado)

		// Insira na subarvore da esquerda
		root->left_child = push(root->left_child, key_to_push, key_priority);

		// Conserte prioridade Heap
		if (root->left_child->priority > root->priority) {
			root = right_rotation(root);
		}
	}

	// 4o caso
	// chave eh maior que raiz
	else {
		// Insira na subarvore da direita
		root->right_child = push(root->right_child, key_to_push, key_priority);

		// Conserte prioridade Heap
		if (root->right_child->priority > root->priority) {
			root = left_rotation(root);
		}
	}

	// Retorne raiz talvez alterada
	return root;
}

int pop(node_t **root, int key_to_pop) {
	// 1o caso
		// Tratamos quando nao ha elementos ou chave nao existe.
	if (!(*root)) {
		printf("Chave nao localizada\n");

		return FALSE;
	}

	// Para os proximos casos, buscar o elemento na arvore, descendo niveis.
	if (key_to_pop < (*root)->key) {
		return pop(&(*root)->left_child, key_to_pop);
	}

	if (key_to_pop > (*root)->key) {
		return pop(&(*root)->right_child, key_to_pop);
	}

	// Encontrei o elemento (no atual == valor buscado para remover).
	// Vamos tratar a remocao.
	
	// Tratar 2o caso - remocao de folha
		// Um no eh folha quando ponteiros de seus filhos apontam para nulo
	if (!(*root)->left_child && !(*root)->right_child) {
		// Desaloque no
		free(*root);

		*root = NULL;
	}

	// Lado esquerdo eh valido, ou lado direito eh valido, ou ambos sao validos
		// Caso 3 - semi-folha
	else if (!(*root)->left_child) {
		// Armazenar o dado a ser removido num no auxiliar
			// Igualar ponteiros
			// Assim nao perdemos referencia do no alocado a ser removido
		node_t *aux = *root;
		
		// Fazer raiz ser o unico filho valido
		*root = (*root)->right_child;
		free(aux);
	}

	else if (!(*root)->right_child) {
		// No so tem filho da esquerda nesse ponto
		// Caso 3 - semi-folha
		node_t *aux = *root;
		
		*root = (*root)->left_child;
		free(aux);
	}

	// 4o caso -> no tem 2 filhos
	else {
		// Nova raiz relativa
		*root = left_rotation(*root);
		pop(root, key_to_pop);
	}

	// Remocao bem sucedida
	return SUCCESS;
}

// Funcoes de percurso em arvore ----------------------------------------------
	// mesma coisa que em uma AB (arvore binaria)

void pre_order_visit(node_t *root) {
	// Somente enquanto arvore nao for vazia, pois, se for, finaliza
	if (root) {
		// Visitar raiz, imprimindo o elemento
		printf("(%d, %d) ", root->key, root->priority);

		// Percorrer subarvore da esquerda em processo recursivo
		pre_order_visit(root->left_child);

		// Percorrer subarvore da direita em processo recursivo
		pre_order_visit(root->right_child);
	}
}

void in_order_visit(node_t *root) {
	// Somente enquanto arvore nao for vazia, pois se for, finaliza
	if (root) {
		// Percorrer subarvore da esquerda em processo recursivo
		in_order_visit(root->left_child);

		// Visitar raiz, imprimindo o elemento
		printf("(%d, %d) ", root->key, root->priority);

		// Percorrer subarvore da direita em processo recursivo
		in_order_visit(root->right_child);
	}
}

void post_order_visit(node_t *root) {
	// Somente enquanto arvore nao for vazia, pois se for, finaliza
	if (root) {
		// Percorrer subarvore da esquerda em processo recursivo
		post_order_visit(root->left_child);

		// Percorrer subarvore da direita em processo recursivo
		post_order_visit(root->right_child);

		// Visitar raiz, imprimindo o elemento
		printf("(%d, %d) ", root->key, root->priority);
	}
}

void by_large_visit(node_t *root) {
	queue_t *tree_nodes = queue_create();
	queue_push(tree_nodes, root);
	node_t *curr_node;

	while (!is_queue_empty(tree_nodes)) {
		curr_node = queue_pop(tree_nodes);
		
		printf("(%d, %d) ", curr_node->key, curr_node->priority);

		if (curr_node->left_child) {
			queue_push(tree_nodes, curr_node->left_child);
		}

		if (curr_node->right_child) {
			queue_push(tree_nodes, curr_node->right_child);
		}
	}

	if (tree_nodes) {
		queue_destroy(&tree_nodes);
	}
}