/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I — 2° semestre de 2021
 * Projeto 2 — Arvores Treaps — aplicacao
 */

#include <stdio.h>
#include <stdlib.h>
#include "constants.h"
#include "string_utils.h"
#include "treap_tree.h"

typedef enum Commands {
    INSERT_VALUE,
    SEARCH_VALUE, 
    REMOVE_VALUE,
    PRINT_TREE
} command_t;

typedef enum VisitationMode {
    PRE_ORDER,
    IN_ORDER,
    POST_ORDER,
    LARGE_PRINT
} visitation_t;

int get_command_option(char *command);
int get_visitation_mode_option(char *visitation_mode);

int main() {
    tree_t *tree = create_tree();

    if (!tree) {
        return EXIT_FAILURE;
    }

    int operation_amt;
    scanf("%d ", &operation_amt);

    for (int i = 0; i < operation_amt; i++) {
        char *command = read_until(' ');
        int option = get_command_option(command);
        free(command);

        if (option == INSERT_VALUE) {
            int key_to_insert, new_element_priority;
            scanf("%d %d", &key_to_insert, &new_element_priority);

            // Aqui, alteramos campo de raiz do registro da arvore!
            tree->root = push(tree->root, key_to_insert, new_element_priority);
        }

        else if (option == SEARCH_VALUE) {
            int key_to_search;
            scanf("%d", &key_to_search);
            printf("%d\n", search_tree(tree->root, key_to_search));
        }

        else if (option == REMOVE_VALUE) {
            int key_to_remove;
            scanf("%d", &key_to_remove);
            pop(&(tree->root), key_to_remove);
        }

        else if (option == PRINT_TREE) {
            char *visitation_mode = read_line();
            int visit = get_visitation_mode_option(visitation_mode);
            free(visitation_mode);

            if (visit == PRE_ORDER) {
                pre_order_visit(tree->root);
                printf("\n");
            }

            else if (visit == IN_ORDER) {
                in_order_visit(tree->root);
                printf("\n");
            }

            else if (visit == POST_ORDER) {
                post_order_visit(tree->root);
                printf("\n");
            }

            else if (visit == LARGE_PRINT) {
                by_large_visit(tree->root);
                printf("\n");
            }

            else {
                printf("Percurso invalido! =S\n");
            }
        }

        else {
            printf("Comando invalido! =(\n");
        }
    }

    // --- Liberar memoria ---
    destroy_tree_root(tree->root);
    free(tree);

    return EXIT_SUCCESS;
}

int get_command_option(char *command) {
    if (content_comparison("insercao", command)) {
        return INSERT_VALUE; 
    }

    if (content_comparison("buscar", command)) {
        return SEARCH_VALUE; 
    }

    if (content_comparison("remocao", command)) {
        return REMOVE_VALUE; 
    }

    if (content_comparison("impressao", command)) {
        return PRINT_TREE; 
    }

    return ERROR;
}

int get_visitation_mode_option(char *visitation_mode) {
    if (content_comparison("preordem", visitation_mode)) {
        return PRE_ORDER; 
    }

    if (content_comparison("ordem", visitation_mode)) {
        return IN_ORDER; 
    }

    if (content_comparison("posordem", visitation_mode)) {
        return POST_ORDER; 
    }

    if (content_comparison("largura", visitation_mode)) {
        return LARGE_PRINT; 
    }

    return ERROR;
}