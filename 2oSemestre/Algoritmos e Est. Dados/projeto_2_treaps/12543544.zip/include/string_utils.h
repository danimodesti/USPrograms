/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * Exercicio 11 - Impressao de Arvores Binarias de Busca
 * TAD string utils - cabecalho [visao do usuario]
 */

#ifndef STRING_UTILS_H
#define STRING_UTILS_H

// Recebe uma string e retorna seu tamanho, sem considerar o '\0' (char terminador)
int string_length(char *string);

// Compara se o conteudo de duas strings e igual, retornando TRUE se sim e FALSE se nao.
int content_comparison(char *string_1, char *string_2);

// Le string ate chegar num terminator, como ' ', '\r' ou '\n, retornando a.
char *read_until(char terminator);

// Le ate o fim da linha ('\r' ou '\n), retornando string.
char *read_line();

/*
 * Compara duas strings e retorna TRUE caso a string 2 venha antes da 1 na ASCII,
 * ou FALSE caso as strings sejam as mesmas ou a string 1 venha antes da 2 na ASCII (significa
 * que nao ha prioridade da string 2 em relacao a 1).
 */
int string_compare(char *string_1, char *string_2);

// Copia o conteudo da memoria de uma variavel para outra. Eh importante que se tenha
// espaco o suficiente alocado para tal.
void *memory_copy(void *dest, void *src, size_t n_bytes);

#endif