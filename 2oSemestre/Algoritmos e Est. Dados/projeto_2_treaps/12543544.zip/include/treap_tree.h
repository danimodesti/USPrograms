/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * Projeto 2 — Arvores Treaps
 * TAD treap tree - cabecalho [visao do usuario]
 */

#ifndef TREAP_TREE_H
#define TREAP_TREE_H

// Nos da arvores
typedef struct node node_t;

// Arvore em si
typedef struct tree {
    node_t *root;
} tree_t;

/* |create_tree| 
 * Aloca arvore vazia (root = NULL) e a retorna.
 * @return (tree_t *): ponteiro para arvore alocada.
 */
tree_t *create_tree();

/* |is_tree_empty| 
 * Checa se a arvore esta vazia.
 * @param tree (tree_t *): ponteiro para arvore checada.
 * @return (int): inteiro booleano que indica se a arvore esta vazia.
 */
int is_tree_empty(tree_t *tree);

/* |destroy_tree| 
 * Desaloca recursivamente uma arvore a partir de um no root.
 * @param root (node_t *): ponteiro para no a partir do qual checar (root da subarvore checada).
 */
void destroy_tree_root(node_t *root);

/* |print_tree| 
 * Imprime recursivamente uma arvore a partir de um no root.
 * @param root (node_t *): ponteiro para no a partir do qual imprimir (root da subarvore impressa).
 */
void print_tree(node_t *root);

/* |tree_height| 
 * Conta a altura do no passado (comprimento do maior caminho ate no folha + 1).
 * @param root (node_t *): ponteiro para no cuja altura sera checada.
 * @return (int): altura do no passado. 
 */
int tree_height(node_t *root);

/* |search_tree| 
 * Busca um elemento a partir de um no root.
 * Retorna se busca foi bem sucedida (1 - TRUE) ou nao (0 - FALSE).
 * @param root (node_t *): ponteiro para no a partir do qual buscar.
 * @param value_to_find (int): elemento buscado.
 * @return (int): Codigo de status da busca. 
 */
int search_tree(node_t *root, int value_to_find);

/* |push| 
 * Insere elemento na posicao correta da arvore, obedecendo ordem ABB + Heap.
 * @param root (node_t *): ponteiro para raiz.
 * @param value_to_push (int): elemento a inserir.
 * @return (node_t *): ponteiro para no inserido. Se nao inserir retorna nulo. 
 */
node_t *push(node_t *root, int key_to_push, int key_priority);

/* |pop| 
 * Remove elemento da arvore.
 * @param root (node_t *): ponteiro para raiz.
 * @param key_to_pop (int): elemento a remover.
 * @return (int): codigo de sucesso na remocao (2) ou de nao alteracao na arvore (0). 
 */
int pop(node_t **root, int key_to_pop);

/* |pre_order_visit| 
 * Percorre arvore na seguinte ordem: no-raiz, filho esquerdo, filho direito.
 * @param root (node_t *): ponteiro para o no raiz da arvore.
 */
void pre_order_visit(node_t *root);

/* |in_order_visit| 
 * Percorre arvore na seguinte ordem: filho esquerdo, no-raiz, filho direito.
 * @param root (node_t *): ponteiro para o no raiz da arvore.
 */
void in_order_visit(node_t *root);

/* |pos_order_visit| 
 * Percorre arvore na seguinte ordem: filho esquerdo, filho direito, no-raiz.
 * @param root (node_t *): ponteiro para o no raiz da arvore.
 */
void post_order_visit(node_t *root);

/* |by_large_visit| 
 * Percorre arvore na ordem dos niveis, e da esquerda para a direita nestes.
 * @param root (node_t *): ponteiro para o no raiz da arvore.
 */
void by_large_visit(node_t *root);

#endif