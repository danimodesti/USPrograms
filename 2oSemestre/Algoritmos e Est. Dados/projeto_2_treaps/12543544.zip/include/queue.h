/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * Projeto 2 — Arvores Treaps
 * TAD queue - cabecalho [visao do usuario]
 */

#ifndef QUEUE_H
#define QUEUE_H

#include "constants.h"

typedef struct node treap_node_t;
typedef struct queue queue_t;  

/* 
 * Cria uma estrutura de fila, retornando-a.
 * Atribui NULL ao conteudo da fila (inicio, fim), ainda nao definido. Tambem
 * atribui tamanho zero a fila.
 * Retorna NULL se nao foi possivel criar a estrutura fila.
*/
queue_t *queue_create();

/*
 * Libera memoria dinamicamente alocada para a estrutura fila e seu conteudo 
 * interno. Se isso ja ocorreu, retorna FALSE. 
 * Se for bem sucedido, atribui NULL ao conteudo da estrutura e a ela propria.
 * Retorna TRUE.
 */
int queue_destroy(queue_t **q);

/*
 * Adiciona elementos na fila, na logica FIFO.
 * Se a fila nao existir, retorna ERROR. Se bem sucedida, retorna TRUE.
 *
 */
int queue_push(queue_t *q, treap_node_t *node_to_push);

/*
 * Remove o primeiro elemento da fila.
 * Se a fila nao existe, retorna NULL. Se  bem sucedida, retorna o no guardado na fila.
 */
treap_node_t *queue_pop(queue_t *q);

/*
 * Retorna o tamanho da fila. Se esta nao existe, retorna ERROR.
 */
int queue_size(queue_t *q);

int is_queue_empty(queue_t *q);

#endif