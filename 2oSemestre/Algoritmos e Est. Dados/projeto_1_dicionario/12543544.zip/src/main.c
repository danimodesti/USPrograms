/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I — 2° semestre de 2021
 * Projeto 1 — Dicionario — aplicacao
 */

#include <stdio.h>
#include <stdlib.h>
#include "skip_list.h"
#include "string_utils.h"
#include "words.h"

typedef enum Option {
    INSERT_COMMAND = 2,
    ALTERATION_COMMAND = 3,
    REMOVE_COMMAND = 4,
    SEARCH_COMMAND = 5,
    PRINT_INFO = 6
} option_t;

int get_command_option(unsigned char *command);

int main() {
    // Skip List com 100 niveis e fracao de nos de 0,5
    skip_list_t *sk = create(100, 0.5);
    if (!sk) {
        return EXIT_FAILURE;
    }

    char curr_char;
    while ((curr_char = getchar()) != EOF) {
        ungetc(curr_char, stdin);

        unsigned char *command = read_until(' ');
        int option = get_command_option(command);
        free(command);

        if (option == INSERT_COMMAND) {
            // Ler palavra ou verbete
            word_t *w = create_word();
            read_word_info(w);

            // Verificacao — palavra ja existe no dicionario?
            unsigned char *word_check = allocate_word(w);

            unsigned char *word_definition;
            if (is_word_in_list(sk, word_check, &word_definition)) {
                printf("OPERACAO INVALIDA\n");
                destroy_word(&w);
            }

            else {
                // Adicionar ao dicionario
                push(sk, w);
            }

            free(word_check);
        }

        else if (option == ALTERATION_COMMAND) {
            unsigned char *word_to_update = read_until(' ');
            unsigned char *new_word_definition = read_line();
            word_t *w = get_word_in_list(sk, word_to_update);

            if (!w) {
                printf("OPERACAO INVALIDA\n");
            }

            else {
                set_word_definition(w, new_word_definition);
            }

            free(word_to_update);
            free(new_word_definition);
        }

        else if (option == REMOVE_COMMAND) {
            unsigned char *word_to_remove = read_until(' ');

            unsigned char *word_definition;
            if (!is_word_in_list(sk, word_to_remove, &word_definition)) {
                printf("OPERACAO INVALIDA\n");
            }

            else {
                pop(sk, word_to_remove);
            }

            free(word_to_remove);
        }

        else if (option == SEARCH_COMMAND) {
            unsigned char *word_to_search = read_until(' ');
            unsigned char *word_definition;
            if (is_word_in_list(sk, word_to_search, &word_definition)) {
                printf("%s %s\n", word_to_search, word_definition);
            }

            else {
                printf("OPERACAO INVALIDA\n"); 
            }

            free(word_to_search);
        }

        else if (option == PRINT_INFO) {
            char first_char_to_print = getchar();
            print_skip_list_by_char(sk, first_char_to_print);
        }
    }

    destroy(&sk);

    return EXIT_SUCCESS;
}

int get_command_option(unsigned char *command) {
    if (content_comparison((unsigned char *)"insercao", command)) {
        return INSERT_COMMAND; 
    }

    if (content_comparison((unsigned char *)"alteracao", command)) {
        return ALTERATION_COMMAND; 
    }

    if (content_comparison((unsigned char *)"remocao", command)) {
        return REMOVE_COMMAND; 
    }

    if (content_comparison((unsigned char *)"busca", command)) {
        return SEARCH_COMMAND; 
    }

    if (content_comparison((unsigned char *)"impressao", command)) {
        return PRINT_INFO; 
    }

    return ERROR;
}