/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I — 2° semestre de 2021
 * Projeto 1 — Dicionario
 * TAD skip list — implementacao
 */

#include <stdio.h>
#include <stdlib.h>
#include "constants.h"
#include "skip_list.h"
#include "string_utils.h"

// Estruturacao dos nos da Skip List
    // cada no tem um valor, que eh unico -> key
    // cada no tambem guarda um ponteiro duplo (ponteiro para ponteiro). Este
    // sera usado para criar um vetor de ponteiros, criando-se um vetor com os 
    // niveis da Skip List.
typedef struct Node node_t;
struct Node {
	word_t *key; 
	node_t **next; 
};

// Cabecalho da Skip List
struct SkipList {
	// Nivel maximo (quantos niveis eu posso ter na estrutura da Skip List)
	int max_level_amt;

	// Fracao dos nos - valor usado no sorteio para definir quantos niveis um 
    // novo no vai ter
    // P representa a probabilidade de gerar novo nível para o nó
	float new_level_prob;

	// Nivel atual do no (quantos niveis eu tenho atualmente)
	int curr_level_amt;

	// Ponteiro para a struct no que define o inicio da skiplist
	// (o no cabecalho)
	// 'start' define o primeiro no
	node_t *start;
};

// Receber o valor da chave para criar um novo no para a Skip List. 
// Receber tambem quantos niveis temos.
// Primeiro nivel, 0, tem todos os valores guardados na Skip List.
node_t *new_node(word_t *key, int curr_level_amt) {
	// Alocacao do novo no
	node_t *new = (node_t *) malloc(sizeof(node_t));
    if (!new) {
        return NULL;
    }

	// Se deu certo a alocacao, copiar o valor da chave para dentro do no
    new->key = key;

	// Criar vetor de niveis. Se tivermos, por exemplo, 5 niveis, faremos 
    // (5 + 1), pois todos os nos devem ter o nivel zero. 
    // Entao, a qtd de niveis que eu tenho sera o numero de niveis, por exemplo,
    // nivel = 5, mais o nivel zero (por isso somar mais um).

    new->next = (node_t **) malloc((curr_level_amt + 1) * sizeof(node_t *));
    if (!new->next) {
        return NULL;
    }

    // Para o nosso vetor de niveis da Skip List:
    // Cria um novo no apontando para NULL
    // Preencher cada nivel apontando pro NULL (a seguir, vem fim da lista. O novo
    // no representa o ultimo no).
    for (int i = 0; i < (curr_level_amt + 1); i++) {
        new->next[i] = NULL;
    }

    // Retornar novo no
	return new; 
}

skip_list_t *create(int max_level_amt, float new_level_prob) {
	// Alocacao do ponteiro Skip List
	skip_list_t *sk = (skip_list_t *) malloc(sizeof(skip_list_t));

    if (!sk) {
        return NULL;
    }

	// Se alocacao deu certo, setamos as informacoes da skip list.
    sk->max_level_amt = max_level_amt;
    sk->new_level_prob = new_level_prob;
    sk->curr_level_amt = 0; 

    // Cria o cabecalho com no sentinela para facilitar insercoes
    // e remocoes
    // a SkipList armazena apenas valores nao negativos

    // Criando um novo no - funcao auxiliar new_node para fazer isso
	// Para o no sentinela: strings vazias, apenas com char terminador.
	word_t *sentinel_node = create_word();
	set_word_content(sentinel_node, (unsigned char *)"");
	set_word_definition(sentinel_node, (unsigned char *)"");

    sk->start = new_node(sentinel_node, max_level_amt);

    if (!sk->start) {
        return NULL;
    }

    // So temos o menor valor possivel para a Skip List, inicialmente, que eh
    // essa string vazia.

    // Retornar Skip List
	return sk; 
}

void destroy(skip_list_t **sk) {
    // Processo so se realiza com a Skip List sendo valida.
    if (*sk) {
        node_t *p, *curr;

        // No atual: entra no cabecalho da Skip List (sk), no campo inicio (lista 
        // apontando para no com valor sentinela)
        // acessar campo prox para entrar no primeiro valor acessivel da Skip List,
        // que nao seja o no sentinela.
        curr = (*sk)->start->next[0];

        // Se tivermos so o sentinela, no nosso exemplo, o atual ja eh NULL, pois acabou
        // a lista.

        // Se isso nao ocorrer,
        while (curr) {
            // Se tiver mais elementos, copiar esse no atual para um no auxiliar p
            p = curr;

            // O atual vai para o campo de proximo
            // Acessar nivel 0 pois todos os elementos tem nivel 0
            curr = curr->next[0];

            // Liberar array de niveis correspondentes a este no (niveis aos quais
            // ele pertence).
            free(p->next);

            // Liberar no

			if (p->key) {
				destroy_word(&p->key);
			}

            free(p);
        }

        // Liberar array de niveis da Skip List
        free((*sk)->start->next);

        // Liberar inicio (no sentinela)
		if ((*sk)->start->key) {
			destroy_word(&(*sk)->start->key);
		}

        free((*sk)->start);

        // Liberar cabecalho da Skip List
        free(*sk);

        *sk = NULL;
    }
}

// Criterio de ordenacao para as palavras do dicionario
int comparator(unsigned char *string_1, unsigned char *string_2, int equality_flag) {
	if (!string_1 || !string_2) {
		return FALSE;
	}

	if (!equality_flag) {
		if (string_compare(string_1, string_2) < 0) {
			return TRUE;
		}
	}

	else {
		if (string_compare(string_1, string_2) == 0) {
			return TRUE;
		}
	}

	return FALSE;
}

// Funcao para checagem de palavra existente -> passar Skip List e a chave (valor) que estou buscando.
int is_word_in_list(skip_list_t *sk, unsigned char *key, unsigned char **word_definition) {
	word_t *word = get_word_in_list(sk, key);

	if (word) {
		*word_definition = get_word_definition(word);
	}

	else {
		*word_definition = NULL;
	}

	if (*word_definition) {
		return TRUE;
	}

	// Nao achou elemento ou sk nao eh valida.
	return FALSE;
}

word_t *get_word_in_list(skip_list_t *sk, unsigned char *key) {
	if (sk) {
		// Receber inicio da Skip List, que eh array de no sentinela (string vazia).
		// No atual comeca no primeiro elemento da lista
		node_t *curr = sk->start;

		// Partindo do maior nivel, va para o proximo no,
		// enquanto a chave for maior do que a do proximo no.
		// Caso contrario, desca um nivel e continue a busca.
		unsigned char *curr_word;
		for (int i = sk->curr_level_amt; i >= 0; i--) {

			curr_word = NULL;
			if (curr && curr->next[i] && curr->next[i]->key) {
				curr_word = allocate_word(curr->next[i]->key);
			}
			
			int equality_flag = FALSE;
			while (curr->next[i] && curr_word && comparator(curr_word, key, equality_flag)) {
				// Se nao obedecer as condicoes do while, nao executa o que esta a 
				// seguir:
				curr = curr->next[i];
				free(curr_word);
				curr_word = NULL;

				if (curr && curr->next[i] && curr->next[i]->key) {
					curr_word = allocate_word(curr->next[i]->key);
				}

				// Se executar o que esta acima, o no 'atual' (curr) guarda como se fosse
				// um checkpoint de valor, nao tendo que comparar muitos elementos,
				// o que torna a Skip List mais eficiente (O(log n)) que uma 
				// Lista Encadeada normal (O(n)).
			}

			if (curr_word) {
				free(curr_word);
			}
		}

		// Acesse o nivel 0 do proximo no, que e onde a chave procurada deve estar.
		// O elemento buscado deve ser o proximo do atual no nivel zero, pois
		// este contem todos os elementos da lista, ordenados.
		curr = curr->next[0];

		// Confirmar se achou o elemento e se ele existe (!= NULL)
		int equality_flag = TRUE;

		curr_word = NULL;
		if (curr) {
			curr_word = allocate_word(curr->key);
		}

		if (curr && comparator(curr_word, key, equality_flag)) {
			free(curr_word);

			// Achou	
			return curr->key;
		}

		if (curr_word) {
			free(curr_word);
		}
	}

	// Nao achou palavra ou sk nao eh valida.
	return NULL;
}

// Sorteio para decidir quantos niveis um novo no inserido na Skip List
// tera.
int draw_level(skip_list_t *sk) {
	// Sorteio aleatorio
	float drawn_level_amt = (float)rand() / RAND_MAX;
	int new_node_level_amt = 0;
	
	// Verificar se a quantidade de niveis sorteada eh maior ou menor do que a 
	// fracao de nos (new_level_prob) definida para a Skip List.
	// Se for menor e eu nao tiver atingido o nivel maximo da lista, 
	// conto como mais um no.
	while (drawn_level_amt < sk->new_level_prob && new_node_level_amt < sk->max_level_amt) {
		new_node_level_amt++;
		drawn_level_amt = (float)rand() / RAND_MAX;
	}
	

	return new_node_level_amt;
}

int push(skip_list_t *sk, word_t *key) {
	// Tendo uma Skip List valida,
	if (sk) {
		// O primeiro no recebe o inicio da lista (no sentinela)
		node_t *curr = sk->start;

		// Criar um array de nos (ponteiros) auxiliar apontando para NULL
		node_t **aux;

		// Alocando o array auxiliar
		// max_level_amt + 1: todos os niveis mais o nivel zero
		aux = (node_t **) malloc((sk->max_level_amt + 1) * sizeof(node_t *));

		// Preencher todos os nos do array auxiliar com NULL
		for (int i = 0; i <= sk->max_level_amt; i++) {
			aux[i] = NULL;
		}
		
		// -------------------------------------------------------------------------------
		// Processo de busca - achar o ponto de insercao do elemento chave
		// Partindo do maior nivel, va para o proximo no, enquanto a chave for 
		// maior do que a do proximo no (e o proximo no existir, ou seja, != NULL)
		unsigned char *curr_word;
		for (int i = sk->curr_level_amt; i >= 0; i--) {
			unsigned char *word_to_add = allocate_word(key);

			curr_word = NULL;
			if (curr && curr->next[i] && curr->next[i]->key) {
				curr_word = allocate_word(curr->next[i]->key);
			}
			
			// Nao eh comparacao de igualdade
			int equality_flag = FALSE;
			while (curr->next[i] && curr_word && comparator(curr_word, word_to_add, equality_flag)) {
				curr = curr->next[i];

				free(curr_word);
				curr_word = NULL;
				if (curr && curr->next[i] && curr->next[i]->key) {
					curr_word = allocate_word(curr->next[i]->key);
				}
			}
			// Caso contrario, insira o no no array auxiliar, desca um nivel e 
			// continue a busca.

			// Antes de descer de nivel, porem, copiar o no atual pro auxiliar.

			// Aqui, estamos salvando os nos anteriores para inserir o novo no
			// logo apos os que estao armazenados em aux (e que representam
			// os varios niveis da sk).
			aux[i] = curr;

			free(word_to_add);

			if (curr_word) {
				free(curr_word);
			}
		}

		// Acesse o nivel 0 do proximo no, que eh onde a chave deve ser inserida.
		curr = curr->next[0];

		// Crie e insira um novo no se a chave nao existir, ou seja, !curr
		// ou curr->key != key (estamos desconsiderando elementos repetidos).

		// Insercao ou no final da lista (curr == NULL) ou 
		// entre aux[0] e curr.
		
		curr_word = NULL;
		if (curr) {
			curr_word = allocate_word(curr->key);
		}

		unsigned char *key_value = allocate_word(key);

		if (!curr || string_compare(curr_word, key_value) != 0) {
			// Sorteia o nivel -> quantos niveis esse novo no vai ter?
			// Calcular. 

			int new_element_level_amt = draw_level(sk);

			// Cria um novo no apontando para NULL
				// Passar valor e quantos niveis o no tem;
				// Alocamos o novo no e alocamos o vetor de niveis.
			node_t *new = new_node(key, new_element_level_amt);

			// Se o processo de alocacao der errado, liberar o array auxiliar
			// e retornar erro na insercao.
			if (!new) {
				free(aux);

				if (curr_word) {
					free(curr_word);
				}

				free(key_value);

				return FALSE;
			}

			// Se consegui alocar meu vetor de nos,

			// Se o nivel sorteado for maior do que o nivel atual da Skip List, 
			// atualizar os novos niveis do array auxiliar.

			// A qtd de niveis que o novo no tem eh maior que a qtd de niveis da
			// minha sk? Se sim, ajusta la, copiando, para nosso exemplo, os
			// niveis do no sentinela para o arr auxiliar, definindo novo numero de niveis
			// da lista.
			if (new_element_level_amt > sk->curr_level_amt) {
				for (int i = sk->curr_level_amt + 1; i <= new_element_level_amt; i++) {
					aux[i] = sk->start;
				}

				// Atualiza o nivel da SkipList
				sk->curr_level_amt = new_element_level_amt;
			}

			// -------------------------------------------------------------------
			// Feito isso, podemos iniciar o processo de insercao. Temos os nos
			// anteriores, o novo no ja alocado e a qtd de niveis que ele tem.
			// Precisamos, agora, realizar a ligacao. Comecando do nivel zero, ate
			// a qtd de niveis que esse novo no tem (nao sao necessariamente todos
			// os niveis da skip list!).
		
			// Insere o no, arrumando os ponteiros 
			for (int i = 0; i <= new_element_level_amt; i++) {
				// O novo no aponta para o proximo do auxiliar
				// Igualar direcao dos ponteiros com o novo valor adicionado
				new->next[i] = aux[i]->next[i];

				// O auxiliar aponta para o novo no. 
				aux[i]->next[i] = new;

				// Feito isso para o nivel zero, subimos ao nivel 1, fazemos o mesmo...
				// isso para todos os niveis do novo no 
			}
		}
	
		// Terminando de arrumar os ponteiros da lista, podemos liberar o 
		// array auxiliar. Tambem liberar caso insercao nao seja necessaria, apos
		// busca.
		free(aux);

		if (curr_word) {
			free(curr_word);
		}

		free(key_value);

		return TRUE;
	}

	// Skip List era invalida
	return FALSE; 
}

int pop(skip_list_t *sk, unsigned char *key) {
	if (sk) {
		// Ponteiro para receber inicio da skip list (primeiro no, sentinela)
		node_t *curr = sk->start;

		// Cria um array de nos auxiliar apontando para NULL
		// (ponteiro para ponteiros)
		node_t **aux;

		// Alocando:
		// numero de niveis + 1 -> todos os nos tem o nivel zero e o max_level_amt
		// diz quantos niveis alem do zero eu tenho
		// (array de ponteiros)
		aux = (node_t **) malloc((sk->max_level_amt + 1) * sizeof(node_t *));

		// Preencher array de ponteiros auxiliar com NULL
		for (int i = 0; i <= sk->max_level_amt; i++) {
			aux[i] = NULL;
		}

		//---------------------------------------------------------------------
		// Qual eh o no anterior ao que eu quero remover? Preciso liga lo com o 
		// elemento posterior ao no que quero remover, e fazer isso para todos os
		// niveis da skip list.

		// Partindo do maior nivel, va para o proximo no, enquanto a chave for 
		// maior que a do próximo no.
		// Caso contrario, insira o no no array auxiliar,
		// desca um nivel e continue a busca.

		unsigned char *curr_word;
		for (int i = sk->curr_level_amt; i >= 0; i--) {
			curr_word = NULL;
			if (curr && curr->next[i] && curr->next[i]->key) {
				curr_word = allocate_word(curr->next[i]->key);
			}

			int equality_flag = FALSE;
			while (curr->next[i] && curr_word && comparator(curr_word, key, equality_flag)) {
				curr = curr->next[i];

				free(curr_word);
				curr_word = NULL;

				if (curr && curr->next[i] && curr->next[i]->key) {
					curr_word = allocate_word(curr->next[i]->key);
				}
			}

			// Guardar o valor do atual no auxiliar
			aux[i] = curr;

			if (curr_word) {
				free(curr_word);
			}
		}

		// Acesse o nivel 0 do proximo no, que eh onde a chave a ser removida 
		// deve estar.
		// Olhamos no nivel 0, pois ha todos os elementos la.

		curr = curr->next[0]; 

		// Achou a chave a ser removida?

		curr_word = allocate_word(curr->key);
		
		int equality_flag = TRUE;
		if (curr && comparator(curr_word, key, equality_flag)) {
			// Comecando no nivel 0, se o array auxiliar aponta para o no a ser 
			// removido, faca ele apontar para o proximo no (remocao de lista 
			// encadeada).

			int i = 0;
			while (i <= sk->curr_level_amt && aux[i]->next[i] == curr) {
				// Se aux[i]->next[i] == curr, conectamos o elemento anterior ao 
				// que esta sendo removido com o proximo do que esta sendo
				// removido.
				
				aux[i]->next[i] = curr->next[i];
				i++;
			}


			// Remova os niveis sem elemento
				// quantos niveis eu tenho que apontem para NULL apos a remocao?
				// ou seja, se so havia aquele elemento removido no nivel.
				// Testar acima do nivel 0, pois nao podemos apaga lo (faz parte
				// do cabecalho da skip list)

				// Reajustamos os niveis para nao verificar elementos a mais
				// sem necessidade todas as vezes.
			while (sk->curr_level_amt > 0 && !sk->start->next[sk->curr_level_amt]) {
				sk->curr_level_amt--;
			}

			// -----------------------------------------------------------------
			// Desalocando memoria

			if (curr_word) {
				free(curr_word);
			}
			
			// Desalocar o vetor de niveis que armazena para onde o campo prox
			// do elemento removido aponta, em cada nivel
			free(curr->next);

			// Desalocar o elemento que foi removido
			destroy_word(&curr->key);
			free(curr);

			// Desalocar array auxiliar com os elementos anteriores ao removido
			free(aux);

			return TRUE; // Sucesso na remocao
		}

		// Se nao achar o elemento, so libere o auxiliar 
		free(aux);

		if (curr_word) {
			free(curr_word);
		}
	}

	// Nao removeu
	return FALSE;
}

void print_skip_list(skip_list_t *sk) {
    if(!sk) {
        return;
	}

	if (is_skip_list_empty(sk)) {
		printf("Skip List vazia\n");

		return;
	}

	printf("\n*****Skip List*****\n");

	// Para todos os niveis,
	for(int i = 0; i <= sk->curr_level_amt; i++) {
		node_t *p = sk->start->next[i];
		printf("Nivel %d: ", i);
		
		// Enquanto houver info no nivel, exiba a.
		while(p) {
			print_word_content(p->key);
			p = p->next[i];
		}

		printf("\n");
	}
}

void print_skip_list_by_char(skip_list_t *sk, char initial_char) {
	if(!sk) {
        return;
	} 

	if (is_skip_list_empty(sk)) {
		printf("Skip List vazia\n");

		return;
	}

	// -------------------------------------------------------------------------
	
	// Receber inicio da Skip List, que eh array de no sentinela (string vazia).
	// No atual comeca no primeiro elemento da lista
	node_t *curr = sk->start;

	// Partindo do maior nivel, va para o proximo no,
	// enquanto a chave for maior do que a do proximo no.
	// Caso contrario, desca um nivel e continue a busca.
	for (int i = sk->curr_level_amt; i >= 0; i--) {
		if (curr->next[i]) {
			unsigned char *word_content = get_word_content(curr->next[i]->key);

			while (curr->next[i] && word_content[0] < initial_char) {
				// Se nao obedecer as condicoes do while, nao executa o que esta a 
				// seguir:
				curr = curr->next[i];

				if (curr->next[i]) {
					word_content = get_word_content(curr->next[i]->key);
				}

				// Se executar o que esta acima, o no 'atual' (curr) guarda como se fosse
				// um checkpoint de valor, nao tendo que comparar muitos elementos,
				// o que torna a Skip List mais eficiente (O(log n)) que uma 
				// Lista Encadeada normal (O(n)).
			}
		}
	}

	// Acesse o nivel 0 do proximo no, que e onde a chave procurada deve estar.
	// O elemento buscado deve ser o proximo do atual no nivel zero, pois
	// este contem todos os elementos da lista, ordenados.
	curr = curr->next[0];

	// Confirmar se achou o elemento e se ele existe (!= NULL)
	if (curr) {
		unsigned char *word_content = get_word_content(curr->key);

		if (word_content[0] == initial_char) {
			while (curr && word_content[0] == initial_char) {
				print_word_all_info(curr->key);
				curr = curr->next[0];
				
				if (curr) {
					word_content = get_word_content(curr->key);
				}
			}
		}

		else {
			printf("NAO HA PALAVRAS INICIADAS POR %c\n", initial_char);
		}
	}
}

int is_skip_list_empty(skip_list_t *sk) {
    if (!sk) {
		return ERROR;
	}

    if (!sk->start->next[0]) {
        return TRUE;
	}

	return FALSE;
}

int size(skip_list_t *sk) {
    if (!sk) {
		return ERROR;
	}

    int size = 0;
    node_t *curr = sk->start->next[0];
    while (curr) {
        curr = curr->next[0];
        size++;
    }

    return size;
}