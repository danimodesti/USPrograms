/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * TAD words - implementacao
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include "words.h"
#include "string_utils.h"

struct Word {
    unsigned char *content;
    unsigned char *definition;
    int content_length;
};

word_t *create_word() {
    word_t *word = (word_t *) malloc(sizeof(word_t));

    if (!word) {
        return NULL;
    }

    word->content = NULL;
    word->definition = NULL;
    word->content_length = 0;

    return word;
}

int read_word_info(word_t *word) {
    // Ler a palavra em si
    word->content = read_until(' ');

    if (!word->content) {
        return ERROR;
    }

    word->content_length = string_length(word->content);

    // Ler a definicao
    word->definition = read_line();

    if (!word->definition) {
        return ERROR;
    }

    return TRUE;
}

int is_the_word_valid(int status) {
    if (status == ERROR) {
        return FALSE;
    }

    else {
        return TRUE;
    }
}

void print_word_content(word_t *word) {
    printf("Palavra: %s\n", word->content);
}

void print_word_all_info(word_t *word) {
    printf("%s %s\n", word->content, word->definition);
}

int destroy_word(word_t **word) {
    if (!(*word)) { 
        return ERROR;
    }

    else {
        if ((*word)->content) {
            free((*word)->content); 
        }

        if ((*word)->definition) {
            free((*word)->definition); 
        }
    }

    free(*word);

    *word = NULL;

    return TRUE;
}

int get_word_length(word_t *word) {
    return word->content_length;
}

unsigned char *get_word_content(word_t *word) {
    return word->content;
}

unsigned char get_first_char(word_t *word) {
    return word->content[0];
}

unsigned char *get_word_definition(word_t *word) {
    return word->definition;
}

void set_word_content(word_t *word, unsigned char *value) {
    int src_len = string_length(value);

    word->content = (unsigned char *) realloc(word->content, (src_len + 1) * sizeof(unsigned char));
    
    // Copiar todos os chars para a string
    memory_copy(word->content, value, src_len + 1);

    word->content_length = string_length(word->content);
}

void set_word_definition(word_t *word, unsigned char *value) {
    int src_len = string_length(value);

    word->definition = (unsigned char *) realloc(word->definition, (src_len + 1) * sizeof(unsigned char));
    
    // Copiar todos os chars para a string
    memory_copy(word->definition, value, src_len + 1);
}

// Precisa alocar memoria, pois se trata de string, nao eh apenas um ponteiro!
unsigned char *allocate_word(word_t *word) {
    int n_bytes = get_word_length(word) + 1;
    unsigned char *content = (unsigned char *) malloc(n_bytes * sizeof(unsigned char));

    memory_copy(content, word->content, n_bytes);

    return content;
}

unsigned char *allocate_word_definition(word_t *word) {
    int n_bytes = string_length(word->definition) + 1;
    unsigned char *definition = (unsigned char *) malloc(n_bytes * sizeof(unsigned char));

    memory_copy(definition, word->definition, n_bytes);

    return definition;
}

int are_words_equal(word_t *word_1, word_t *word_2) {
    if (word_1->content_length != word_2->content_length) {
        return FALSE;
    }

    int i = 0;
    while (word_1->content[i] != '\0') {
        if (word_1->content[i] != word_2->content[i]) {
            return FALSE;
        }

        i++;
    }

    return TRUE;
}