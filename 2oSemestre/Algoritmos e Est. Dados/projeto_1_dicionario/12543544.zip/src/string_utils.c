/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * Projeto 1 — Dicionario
 * TAD string utils - implementacao
 */

#include <stdio.h>
#include <stdlib.h>
#include "constants.h"
#include "string_utils.h"

int string_length(unsigned char *string) {
    int length = 0;
    while (string[length] != '\0') {
        length++;
    }

    return length;
}

int content_comparison(unsigned char *string_1, unsigned char *string_2) {
    int str_1_length, str_2_length;
    str_1_length = string_length(string_1);
    str_2_length = string_length(string_2);

    if (str_1_length != str_2_length) {
        return FALSE;
    }

    int i = 0;
    while (string_1[i] != '\0') {
        if (string_1[i] != string_2[i]) {
            return FALSE;
        }
        i++;
    }

    return TRUE;
}

unsigned char *read_until(char terminator) {
    char curr_char;
    int str_len = 0;
    unsigned char *str = NULL;

    // Consumir chars possivelmente restantes no buffer
    do {
        curr_char = getchar();
    } while (curr_char == '\r' || curr_char == '\n' || curr_char == ' ');

    // Devolver char se valido
    if (curr_char != EOF) {
        ungetc(curr_char, stdin);
    }

    str = (unsigned char *) malloc(BUFFER_SIZE * sizeof(unsigned char));

    do {
        curr_char = getchar();
        str_len++;

        if (curr_char != terminator && curr_char != '\r' && curr_char != '\n' && curr_char != EOF) {
            // Teste do buffer
            if (str_len % BUFFER_SIZE == 0) {
                str = (unsigned char *) realloc(str, ((str_len / BUFFER_SIZE+1) * BUFFER_SIZE) * sizeof(unsigned char));
            }

            str[str_len - 1] = curr_char;
        }

        else {
            str[str_len - 1] = '\0';
        }

    } while (curr_char != terminator && curr_char != '\r' && curr_char != '\n' && curr_char != EOF);

    if (!str) {
        return NULL;
    } 

    // Corrigir a alocacao
    str = (unsigned char *) realloc(str, str_len * sizeof(unsigned char));

    return str;
}

unsigned char *read_line() {
    char curr_char;
    int str_len = 0;
    unsigned char *str = NULL;

    // Consumir chars possivelmente restantes no buffer
    do {
        curr_char = getchar();
    } while (curr_char == '\r' || curr_char == '\n' || curr_char == ' ');

    // Devolver char se valido
    if (curr_char != EOF) {
        ungetc(curr_char, stdin);
    }

    str = (unsigned char *) malloc(BUFFER_SIZE * sizeof(unsigned char));

    do {
        curr_char = getchar();
        str_len++;

        if (curr_char != '\r' && curr_char != '\n' && curr_char != EOF) {
            // Teste do buffer
            if (str_len % BUFFER_SIZE == 0) {
                str = (unsigned char *) realloc(str, ((str_len / BUFFER_SIZE+1) * BUFFER_SIZE) * sizeof(unsigned char));
            }

            str[str_len - 1] = curr_char;
        }

        else {
            str[str_len - 1] = '\0';
        }

    } while (curr_char != '\r' && curr_char != '\n' && curr_char != EOF);

    if (!str) {
        return NULL;
    } 

    // Corrigir a alocacao
    str = (unsigned char *) realloc(str, str_len * sizeof(unsigned char));

    return str;
}

int string_compare(unsigned char *string_1, unsigned char *string_2) {
    // Adaptacao de strcmp para verificar se palavra vem antes na ASCII ou
    // nao.

    int diff = 0; // as strings aqui nao sao diferentes

    int i = 0;
    while (string_1[i] != '\0' && string_2[i] != '\0' && diff == 0) { // sai do while se uma das strings (ou ambas) 
                                                                    // acabarem, OU se os chars (que sao inteiros na
                                                                    // ASCII) forem diferentes, dando diff != 0
        diff += string_1[i] - string_2[i];                              
        i++;
    }

    // quanto mais avancamos na tabela ascii, maiores sao os valores pros chars

    if (diff == 0) { 
        diff = string_length(string_1) - string_length(string_2);
    }

    // Se diff == 0, strings iguais;
    // Se diff < 0, string_1 < string_2 (na ASCII, ela vem antes);
    // se diff > 0, string_2 < string_1 (na ASCII, ela vem antes).

    return diff;
}

void *memory_copy(void *dest, void *src, size_t n_bytes) {
    char *d = (char *)dest;
    char *s = (char *)src;

    for (int i = 0; i < (int)n_bytes; i++) {
        d[i] = s[i];
    }

    return dest;
}