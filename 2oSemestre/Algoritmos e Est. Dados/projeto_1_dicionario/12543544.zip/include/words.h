/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * TAD words - cabecalho
 * 
 */

#ifndef WORDS_H
#define WORDS_H

#include "constants.h"

typedef struct Word word_t;

/*
 * Cria uma estrutura de palavra, retornando-a.
 * Atribui NULL ao conteudo de palavra, ainda nao definido.
 * Retorna NULL se nao foi possivel criar a estrutura palavra.
 */
word_t *create_word();

/*
 * Le uma palavra, conferindo conteudo a essa estrutura.
 * Se nao conseguir, retorna ERROR. Se conseguir,
 * retorna TRUE.
 */ 
int read_word_info(word_t *word);

/*
 * Verifica se a leitura do conteudo de uma estrutura palavra
 * foi bem sucedida.
 */
int is_the_word_valid(int status);
void print_word_content(word_t *word);

/*
 * Libera memoria dinamicamente alocada para a estrutura palavra e seu conteudo 
 * interno. Se isso ja ocorreu, retorna ERROR. 
 * Se for bem sucedido, atribui NULL ao conteudo da estrutura e a ela propria.
 * Retorna TRUE.
 *
 */
int destroy_word(word_t **word);

int get_word_length(word_t *word);

unsigned char *get_word_content(word_t *word);

unsigned char *get_word_definition(word_t *word);

void set_word_content(word_t *word, unsigned char *value);

void set_word_definition(word_t *word, unsigned char *value);

unsigned char *allocate_word(word_t *word);

int are_words_equal(word_t *word_1, word_t *word_2);

unsigned char *allocate_word_definition(word_t *word);

unsigned char get_first_char(word_t *word);

void print_word_all_info(word_t *word);

#endif