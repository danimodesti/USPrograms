/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I — 2° semestre de 2021
 * Projeto 1 — Dicionario 
 * TAD skip list — cabecalho [visao do usuario]
 */

#include "words.h"

typedef struct SkipList skip_list_t;

// Cria uma estrutura de Skip List, retornando a. Configura os valores de 
// quantidade maxima de nos e o de probabilidade de criacao de um novo nivel,
// e tambem cria um no inicial na lista, com valor '-1' (sentinela).
skip_list_t *create(int max_level_amt, float new_level_prob);

// Insere valor na Skip List, retornando TRUE se foi possivel inseri lo e FALSE
// caso contrario.
int push(skip_list_t *sk, word_t *key);

// Busca um valor na Skip List, retornando TRUE para caso ele tenha sido
// encontrado e FALSE caso contrario.
int is_word_in_list(skip_list_t *sk, unsigned char *key, unsigned char **word_definition);

// Insere um determinado valor de forma ordenada na Skip List, retornando TRUE
// se a insercao deu certo e FALSE caso contrario.
int push(skip_list_t *sk, word_t *key);

// Remove um determinado valor da Skip List, retornando TRUE se o processo foi
// bem sucedido e FALSE caso contrario.
int pop(skip_list_t *sk, unsigned char *key);

word_t *get_word_in_list(skip_list_t *sk, unsigned char *key);

void print_skip_list(skip_list_t *sk);

void print_skip_list_by_char(skip_list_t *sk, char initial_char);

// Retorna tamanho da Skip List. Se ela for invalida, retorna ERROR.
int size(skip_list_t *sk);

// Retorna se a Skip List esta vazia ou nao. Se ela for invalida, retorna ERROR.
int is_skip_list_empty(skip_list_t *sk);

// Desaloca uma estrutura de Skip List.
void destroy(skip_list_t **sk);
