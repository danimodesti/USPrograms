/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I — 2° semestre de 2021
 * Projeto 1 — Dicionario
 * TAD constants - cabecalho [visao do usuario]
 */

#define TRUE 1
#define FALSE 0

#define SUCCESS 7
#define ERROR -1

#define BUFFER_SIZE 15