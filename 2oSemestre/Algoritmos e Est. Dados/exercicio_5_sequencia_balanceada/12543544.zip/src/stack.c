/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * Exercicio 05 - Sequencia balanceada
 * TAD stack - implementacao
 */

#include <stdio.h>
#include <stdlib.h>
#include "stack.h"   

#define TRUE 1
#define FALSE 0
#define ERROR -2 // Para nao dar conflito com o -1 de pilha vazia (topo == -1)

#define BUFFER_SIZE 50 // Define se um tamanho para alocar inicialmente para a pilha

struct my_stack {
	int top;
	char *items; 
};

my_stack_t *create() {
	my_stack_t *s = (my_stack_t *) malloc(sizeof(my_stack_t));
	
	if (!s) {
		return NULL;
	}

	// Inicialmente, teremos 50 espacos alocados
	s->items = (char *) malloc(BUFFER_SIZE * sizeof(char));
	s->top = -1; 

	return s;
}

void destroy(my_stack_t **s) { 
	if ((*s)->items) {
		free((*s)->items);
	}
	
	if(*s) { 
		free(*s);
	}

	*s = NULL;
}

int is_empty(my_stack_t *s) {
	if (!s) {
		return ERROR;
	}
	if (s->top == -1) {
		return TRUE;
	}
	else {
		return FALSE;
	}
}

// Eh virtual, pois a pilha eh dinamica. Mas da para usar caso tenha um limite
// de elementos na pilha na aplicacao, basta mudar o define no .h
int is_full(my_stack_t *s) {
	if (!s) {
		return ERROR;
	}
	if (s->top == STACK_SIZE_LIMIT) {
		return TRUE;
	}
	else {
		return FALSE;
	}
}

int push(my_stack_t *s, char x) {
	if (!s) {
		return ERROR;
	}

	// Pilha cheia para a aplicacao no caso
	if (is_full(s)) {
		return ERROR;
	}

	// Aumentar a quantidade de espacos para a pilha dinamica
	if (stack_size(s) % BUFFER_SIZE == 0) {
		s->items = (char *) realloc(s->items, ((stack_size(s) / BUFFER_SIZE + 1) * BUFFER_SIZE) * sizeof(char));
	}

	s->top++;
	s->items[s->top] = x;
	
	return TRUE; 
}

int pop(my_stack_t *s, char *x) {
	if (!s) {
		return ERROR;
	} 

	if(is_empty(s)) {
		return -1; // Indice que indica que a pilha esta vazia
	}

	*x = s->items[s->top];

	s->top--;

	// Nao realocamos para menos para evitar custos de operacoes sem necessidade.
	// Afinal, pode ser que a pilha precise dos espacos antes alocados e ocupados
	// com dados previamente na funcao push()

	return TRUE; 
}

int top(my_stack_t *s, char *x) {
	if (!s) {
		return ERROR;
	} 

	if(is_empty(s) == 1) {
		return -1; 
	}

	*x = s->items[s->top];

	return TRUE; 
}

int stack_size(my_stack_t *s) {
	return s->top + 1;
}

void print_stack(my_stack_t *s) {
	for (int i = 0; i < stack_size(s); i++) {
		printf("%c", s->items[i]);
	}
	printf("\n");
}