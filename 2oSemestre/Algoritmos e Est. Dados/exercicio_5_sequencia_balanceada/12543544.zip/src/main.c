/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * Exercicio 05 - Sequencia balanceada - aplicacao
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include "stack.h"

#define TRUE 1
#define FALSE 0

int is_pushable_element(char element);
int is_poppable_element(char element);
int are_correspondents_elements(char element_1, char element_2);
void read_until_end(char *curr_char);

int main() {
    int has_EOF = FALSE;
    int is_balanced = TRUE;

    while (!has_EOF) {
        my_stack_t *s = create();

        if (!s) {
            return EXIT_FAILURE;
        }

        int is_case_finished = FALSE;

        // Ler o caso todo
        while (!is_case_finished) {
            char curr_char = getchar();

            // Consumir quaisquer espacos
            while (curr_char == ' ') {
                curr_char = getchar();

            }

            // Testar a correspondencia dos openers e manipular a pilha
            if (is_pushable_element(curr_char)) {
                push(s, curr_char);
            }

            else if (is_poppable_element(curr_char)) {
                // Nao posso ter um fechamento quando nao ha uma abertura
                if (is_empty(s)) {
                    is_balanced = FALSE;
                }

                // Eh um correspondente de alguma abertura?
                else {
                    char top_char;
                    top(s, &top_char);

                    if (are_correspondents_elements(top_char, curr_char)) {
                        pop(s, &curr_char);
                    }

                    else {
                        is_balanced = FALSE;
                    }
                }
            }

            else if (curr_char == '"') {
                char top_char = '0';
                top(s, &top_char);

                // As aspas sao suas proprias correspondentes
                if (top_char == curr_char) {
                    pop(s, &curr_char);
                }

                else {
                    push(s, curr_char);
                }
            }

            // Terminar a linha com o caso
            else if (curr_char == '\r' || curr_char == '\n' || curr_char == EOF) {
                if (curr_char == '\r') {
                    curr_char = getchar();
                }

                is_case_finished = TRUE;

                if (curr_char == EOF) {
                    has_EOF = TRUE;
                }
            }

            // Teste se a pilha termina vazia ou nao
            if (is_case_finished && !is_empty(s)) {
                is_balanced = FALSE;
            }

            // Se chegar nesta condicao, precisa ignorar todo o caso em questao
            if (!is_balanced) {
                read_until_end(&curr_char);
            }
        }

        // Apos caso terminar de ser analisado, tenho o veredito: eh ou nao 
        // balanceado?
        if (is_balanced && is_case_finished) {
            printf("BALANCEADO\n");

        }

        // Caso terminou de ser analisado e eh balanceado
        else if (!is_balanced && is_case_finished) {
            printf("NÃO BALANCEADO\n");
            
            // Para o proximo caso, deve estar balanceado, supostamente
            is_balanced = TRUE;
        }

        destroy(&s);
    }

    return EXIT_SUCCESS;
}

int is_pushable_element(char element) {
    return (element == '(' || element == '[' || element == '{');
}

int is_poppable_element(char element) {
    return (element == ')' || element == ']' || element == '}');
}

int are_correspondents_elements(char element_1, char element_2) {
    if (element_1 == '(' && element_2 == ')') {
        return TRUE;
    }

    if (element_1 == '[' && element_2 == ']') {
        return TRUE;
    }

    if (element_1 == '{' && element_2 == '}') {
        return TRUE;
    }

    if (element_1 == '"' && element_2 == '"') {
        return TRUE;
    }

    return FALSE;
}

void read_until_end(char *curr_char) {
    while (*curr_char != '\r' && *curr_char != '\n' && *curr_char != EOF) {
        *curr_char = getchar();
    }
}