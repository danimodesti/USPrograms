/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * Exercicio 05 - Sequencia balanceada 
 * TAD stack - cabecalho [visao do usuario]
 */

#ifndef STACK_H
#define STACK_H

#define STACK_SIZE_LIMIT 200

// Definição do tipo my_stack_t (struct pilha)
typedef struct my_stack my_stack_t;

/* |create|
 * Cria uma pilha, alocando-a na Heap e retornando 
 * o devido ponteiro para a pilha criada.
 * Inicializa o topo em -1 e aloca 50 espacos para itens da pilha.
 * 
 * @return (my_stack_t *): endereco da primeira posicao
 * na Heap contendo a pilha alocada.
 * Se a funcao for mal sucedida ao alocar a pilha, 
 * retorna NULL.
 * 
 */
my_stack_t *create();

/* |destroy|
 * Recebe o ponteiro da pilha por referencia para  
 * desaloca-la e atribuir-lhe NULL. Desaloca seus elementos,
 * se existirem.
 * 
 * @param p (my_stack_t **): ponteiro para ponteiro da pilha 
 */
void destroy(my_stack_t **s);

/* |is_empty|
 * Recebe ponteiro para a pilha, a qual sera testada.
 * Se estiver vazia (numero de elementos eh zero),
 * retornara 1 (TRUE). Caso contrario, retonara 0 (FALSE).
 * Se a pilha nao existe, eh retornado ERROR.
 * 
 * @param p (my_stack_t *): ponteiro para a pilha 
 * @return (int): inteiro com funcao booleana que indica se pilha esta vazia
 */
int is_empty(my_stack_t *s);

/* |is_empty|
 * Recebe ponteiro para a pilha, a qual sera testada.
 * Se estiver cheia (numero de elementos eh STACK_SIZE_LIMIT),
 * retornara 1 (TRUE). Caso contrario, retonara 0 (FALSE).
 * Se a pilha nao existe, eh retornado ERROR.
 * 
 * @param p (my_stack_t *): ponteiro para a pilha 
 * @return (int): inteiro com funcao booleana que indica se pilha esta cheia.
 */
int is_full(my_stack_t *s);

/* |push|
 * Adiciona elemento ao topo da pilha
 * 
 * @param p (my_stack_t *): pilha a qual sera adicionado um elemento
 * @param x (char): elemento a ser adicionado a pilha especificada
 * @return (int): inteiro tipo flag para tratamento de erros.
 *  -> se for retornado TRUE, e porque deu tudo certo com a adicao.
 */
int push(my_stack_t *s, char x);

/* |pop|
 * Adiciona elemento ao topo da pilha e armazena seu valor na variavel especificada
 * 
 * @param p (my_stack_t *): pilha da qual sera desempilhado o elemento do topo.
 * @param x (char *): endereco da variavel na qual sera armazenado o valor do
 * elemento que sera tirado do topo.
 * @return (int): inteiro tipo flag para tratamento de erros.
 *  -> se for -1, indica que a pilha estava vazia.
 *  -> se for TRUE, e porque deu tudo certo com a remocao
 */
int pop(my_stack_t *s, char *x);

/* |top|
 * Consulta elemento e armazena seu valor na variavel especificada
 * 
 * @param p (my_stack_t *): pilha cujo topo sera consultado.
 * @param x (char *): endereco da variavel na qual sera armazenado o valor do
 * elemento consultado do topo da pilha especificada.
 * @return (int): inteiro tipo flag para tratamento de erros.
 *  -> se for -1, indica que a pilha estava vazia.
 *  -> se for  TRUE, e porque deu tudo certo com a consulta ao topo
 */
int top(my_stack_t *s, char *x);

/* |stack_size|
 * Retorna o tamanho atual da pilha.
 *
 * @param s (my_stack_t *): pilha cujo tamanho sera consultado.
 * 
 * @return (int): o tamanho da pilha.
 */
int stack_size(my_stack_t *s);

/* |print_stack|
 * Mostra os dados armazenados na pilha, comecando do primeiro inserido
 * e terminando no ultimo.
 * 
 * @param s (my_stack_t *): pilha cujo conteudo sera exibido na tela.
 */
void print_stack(my_stack_t *s);

#endif