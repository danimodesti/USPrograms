/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * TAD vector - cabecalho [visao do usuario]
 * 
 */

#ifndef VECTOR_H
#define VECTOR_H

typedef struct vector vector_t;

/* |create|
 * Cria vetor alocado e retorna o ponteiro para o bloco de
 * memoria alocado.
 * @param int size: tamanho do vetor que sera alocado.
 *
 * @return vector_t *: ponteiro para o primeiro byte alocado
 * para o vetor que acabou de ser criado.
 */
vector_t *create(int size);

/* |max_elem|
 * Encontra o maior elemento armazenado no vetor.
 * @param vector_t *vector: TAD vetor que sera manipulado.
 *
 * @return int: o maximo elemento.
 */
int max_elem(vector_t *vector);

/* |destroy|
 * Desaloca toda memoria relacionada ao vetor passado.
 *
 * @param vector_t **prime_index: endereco do vetor que
 * sera destruido.
 *          int prime_total_amt: dado inteiro passado no inicio do programa
 *                               pelo usuario. 
 * 
 * @return int: apenas se a funcao foi bem sucedida ou nao.
 */
int destroy(vector_t **vector);

/* |set_elem|
 * Atribui o valor 'value' ao indice 'index' do vetor. 
 *
 * @param vector_t *vector: TAD vetor que sera manipulado.
 *          int index: indice que sera manipulado no vetor.
 *          int value: valor a ser setado no indice do vetor. 
 * 
 * @return: void, apenas processamento.
 */
void set_elem(vector_t *vector, int index, int value);

/* |is_valid|
 * Verifica se um ponteiro eh nulo (ou seja, invalido) ou nao.
 *
 * @param vector_t *vector: TAD vetor que sera manipulado.
 * 
 * @return: int: apenas se eh valido ou nao.
 */
int is_valid(vector_t *vector);

/* |get_elem|
 * Busca, no TAD vector, um elemento de um vetor de inteiros.
 *
 * @param vector_t *vector: TAD vetor que sera manipulado.
 *                   int index: elemento obtido do vetor de inteiros.
 * 
 * @return: int: o elemento obtido.
 */
int get_elem(vector_t *vector, int index);

/* |get_size|
 * Busca, no TAD vector, o seu tamanho.
 *
 * @param vector_t *vector: TAD vetor que sera manipulado.
 * 
 * @return: int: o tamanho obtido do vetor.
 */
int get_size(vector_t *vector);

/* |print_vector|
 * Exibe as informacoes do vetor na tela.
 *
 * @param vector_t *vector: TAD vetor que sera manipulado.
 * 
 * @return: void - apenas processa.
 */
void print_vector(vector_t *vector);

#endif