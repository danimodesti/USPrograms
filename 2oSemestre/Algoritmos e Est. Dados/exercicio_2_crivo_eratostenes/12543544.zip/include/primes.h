/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * TAD primes - cabecalho [visao do usuario]
 * 
 */
#ifndef PRIMES_H
#define PRIMES_H
#include "vector.h"

/* |read_wanted_index_of_primes|
 * Le quais sao os elementos que o usuario deseja ver da lista de primos. 
 * @param vector_t *prime_index: vetor que contem os indices dos primos
 *                               que serao calculados e exibidos pelo crivo.
 *        int prime_total_amt:   dado inteiro passado no inicio do programa
 *                               pelo usuario.
 *
 * @return int: apenas se a funcao foi bem sucedida ou nao.
 */
int read_wanted_index_of_primes(vector_t *prime_index, int prime_total_amt);

/* |calculate_sieve_of_eratosthenes|
 * Utilizando a estrategia de definir 2 como o primeiro primo, retirando todos
 * os seus multiplos e, posteriormente, fazendo mesmo processo para todos
 * os outros numeros que sobram, ate um limite proposto, devolve quais
 * sao os primos correspondentes ao que o usuario deseja exibir, exibindo-os
 * na tela ao final do processo.
 *
 * @param vector_t *prime_index: vetor que contem os indices dos primos
 *                               que serao calculados e exibidos pelo crivo.
 *        int prime_total_amt: dado inteiro passado no inicio do programa
 *                               pelo usuario. Informa quantos primos devem
 *                               aparecer ao calcular o crivo.
 *
 * @return int: apenas se a funcao foi bem sucedida ou nao.
 */
int calculate_sieve_of_eratosthenes(vector_t *prime_index, int prime_total_amt);

#endif