/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * TAD vector - implementacao
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include "vector.h"

#define TRUE 1
#define FALSE 0
#define ERROR -1

struct vector {
    int *items;
    int size;
};

vector_t *create(int size) {
    vector_t *vector = (vector_t *) malloc(sizeof(vector_t));

    if (!vector) {
        return NULL;
    }

    vector->items = (int *) malloc(size * sizeof(int));

    if (!vector->items) {
        return NULL;
    }

    vector->size = size;

    return vector;
}

int max_elem(vector_t *vector) {
    int biggest_index = vector->items[0];
    for (int i = 1; i < vector->size; i++) {
        if (vector->items[i - 1] < vector->items[i] && biggest_index < vector->items[i]) {
            biggest_index = vector->items[i];
        }
    }

    return biggest_index;
}

int destroy(vector_t **vector) {
    if (!(*vector)->items) { 
        return ERROR;
    }
    else {
        free((*vector)->items);
    }

    (*vector)->items = NULL;

    if(!(*vector)) {
        return ERROR;
    }

    free(*vector);

    vector = NULL;

    return TRUE;
}

void set_elem(vector_t *vector, int index, int value) {
    vector->items[index] = value;
}

int is_valid(vector_t *vector) {
    if (!vector || !vector->items) {
        return FALSE;
    }
    else {
        return TRUE;
    }
}

int get_elem(vector_t *vector, int index) {
    return vector->items[index];
}

int get_size(vector_t *vector) {
    return vector->size;
}

void print_vector(vector_t *vector) {
    for (int i = 0; i < vector->size; i++) {
        printf("%d ", vector->items[i]);
    }
    printf("\n");
}