/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * Exercicio 02 - Crivo de Eratostenes [aplicar o TAD vector e o TAD primes]
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include "vector.h"
#include "primes.h"

int main() {
    int prime_total_amt;
    scanf("%d", &prime_total_amt);

    vector_t *prime_index = create(prime_total_amt);
    if (!is_valid(prime_index)) {
        return EXIT_FAILURE;
    }

    read_wanted_index_of_primes(prime_index, prime_total_amt);
    calculate_sieve_of_eratosthenes(prime_index, prime_total_amt);
    destroy(&prime_index);

    return EXIT_SUCCESS;
}