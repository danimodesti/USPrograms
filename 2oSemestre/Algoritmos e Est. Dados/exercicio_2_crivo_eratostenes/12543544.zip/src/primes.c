/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * TAD primes - implementacao
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include "vector.h"
#include "primes.h"

#define TRUE 1
#define FALSE 0
#define ERROR -1

int read_wanted_index_of_primes(vector_t *prime_index, int prime_total_amt) {
    if (prime_total_amt <= 0) {
        return ERROR;
    }
    
    int value;
    for (int i = 0; i < prime_total_amt; i++) {
        scanf("%d", &value);
        set_elem(prime_index, i, value);
    }

    return TRUE;
}

int calculate_sieve_of_eratosthenes(vector_t *prime_index, int prime_total_amt) {
     if (prime_total_amt <= 0) {
        return ERROR;
    }
    
    // isso me indica ate onde faco uma lista de primos
    int biggest_index = max_elem(prime_index);
    vector_t *prime_list = create(biggest_index);

    set_elem(prime_list, 0, 2);

    // qtd de elementos que tenho no vetor de primos
    int prime_curr_amt = 1; 
    
    // percorre numeros inteiros para ate quando eu tiver, na minha lista de 
    // primos, biggest_index elementos
    int check_prime = 3;
    
    // calcular o crivo ate preencher um vetor com biggest_index de numero de 
    //elementos primos
    for (int i = 0; prime_curr_amt < biggest_index; i++) {
        int is_prime = TRUE;
        int j = 0;
        while (is_prime && j < prime_curr_amt) {
            if (check_prime % get_elem(prime_list, j) == 0) {
                is_prime = FALSE;
            }
            else {
                j++;
            }
        }

        if (is_prime) {
            set_elem(prime_list, prime_curr_amt, check_prime);
            prime_curr_amt++;
        }
        check_prime++;
    }

    // prime_total_amt diz quantos primos devem aparecer na tela
    for (int i = 0; i < prime_total_amt; i++) {
        int curr_prime = get_elem(prime_list, get_elem(prime_index, i) - 1);
        printf("%d ", curr_prime);
    }
    printf("\n");

    destroy(&prime_list);

    return TRUE;
}