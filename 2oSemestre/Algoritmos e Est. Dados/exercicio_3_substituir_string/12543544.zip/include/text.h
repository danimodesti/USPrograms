/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * Exercicio 03 - Subst. strings
 * TAD text - cabecalho [visao do usuario]
 */


#ifndef TEXT_H
#define TEXT_H

#define ERROR -1
#define TRUE 1
#define FALSE 0
#define TXT_LIMIT 100

typedef struct text text_t;

/* 
 * Cria uma estrutura de texto, retornando-a.
 * Atribui NULL ao conteudo do texto, ainda nao definido
 * Retorna NULL se nao foi possivel criar a estrutura texto.
*/
text_t *create_text();

/*
 * Le uma linha de texto, conferindo conteudo a essa estrutura.
 * Se nao conseguir, retorna ERROR. Se conseguir,
 * retorna TRUE.
 */ 
int read_text(text_t *text);

/*
 * Verifica se a leitura do conteudo de uma estrutura texto
 * foi bem sucedida.
 */
int is_the_line_valid(int status);

/*
 * Retorna o tamanho do conteudo de uma estrutura texto.
 */
int text_size(text_t *text);

/*
 * Aloca espaco para o conteudo de um novo texto (new), cuja estrutura texto
 * deve ser previamente alocada. Depois, conserta seus 'mistakes' e retorna
 * o texto corrigido.
 * Caso haja problema na alocacao de espaco para conteudo desse texto, retorna ERROR.
 * Caso haja problema na definicao de um novo conteudo desse texto, retorna NULL.
 *
 */
text_t *replace_text(text_t *initial, text_t *mistake, text_t *to_replace, text_t *new);

void print_text(text_t *text);

/*
 * Libera memoria dinamicamente alocada para a estrutura texto e seu conteudo 
 * interno. Se isso ja ocorreu, retorna ERROR. 
 * Se for bem sucedido, atribui NULL ao conteudo da estrutura e a ela propria.
 * Retorna TRUE.
 *
 */
int destroy_text(text_t **text);

#endif