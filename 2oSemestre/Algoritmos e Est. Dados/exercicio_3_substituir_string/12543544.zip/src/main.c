/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * Exercicio 03 - Subst. strings - aplicacao
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include "text.h"

#define TXT_AMT 3

int main() {
    for (int i = 0; i < TXT_AMT; i++) {
        text_t *initial_text = create_text();
        text_t *mistaken_text = create_text();
        text_t *text_to_replace = create_text();

        if (!initial_text || !mistaken_text || !text_to_replace) {
            return EXIT_FAILURE;
        }

        int is_valid_text;
        is_valid_text = read_text(initial_text);  
        if (!is_the_line_valid(is_valid_text)) {
            return EXIT_FAILURE;
        }

        is_valid_text = read_text(mistaken_text); 
        if (!is_the_line_valid(is_valid_text)) {
            return EXIT_FAILURE;
        }

        is_valid_text = read_text(text_to_replace); 
        if (!is_the_line_valid(is_valid_text)) {
            return EXIT_FAILURE;
        }

        text_t *new_text = create_text();

        if (!new_text) {
            return EXIT_FAILURE;
        }

        new_text = replace_text(initial_text, mistaken_text, text_to_replace, new_text);
        print_text(new_text);
        destroy_text(&initial_text);
        destroy_text(&mistaken_text);
        destroy_text(&text_to_replace);

        destroy_text(&new_text);
    }

    return EXIT_SUCCESS;
}