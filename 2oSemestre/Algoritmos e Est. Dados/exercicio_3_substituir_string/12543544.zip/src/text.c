/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * Exercicio 03 - Subst. strings
 * TAD text - implementacao
 */

#include <stdio.h>
#include <stdlib.h>
#include "text.h"

struct text {
    unsigned char *content; // unsigned para tratar chars especiais da extended ascii table
    int size;
};

text_t *create_text() {
    text_t *text = (text_t *) malloc(sizeof(text_t));

    if (!text) {
        return NULL;
    }

    text->content = NULL;

    return text;
}

int read_text(text_t *text) {
    int curr_char;
    text->size = 0;
    text->content = (unsigned char *) malloc(sizeof(unsigned char));

    do {
        curr_char = getchar();
        text->size++;
        text->content = (unsigned char *) realloc(text->content, text->size * sizeof(unsigned char));
        
        if (!text->content) {
            return ERROR;
        }

        if (curr_char != '\n' && curr_char != '\r' && curr_char != EOF) {
            text->content[text->size - 1] = curr_char;
        }
        else {
            text->content[text->size - 1] = '\0';
            text->size--;
        }
    } while (curr_char != '\n' && curr_char != '\r' && curr_char != EOF);

    return TRUE;
}

int is_the_line_valid(int status) {
    if (status == ERROR) {
        return FALSE;
    }

    else {
        return TRUE;
    }
}

int text_size(text_t *text) {
    return text->size;
}

/*
 * Confere se esta varrendo um espaco valido da string
 * inicial, buscando por um 'mistake'. Nao esta em espaco
 * valido se:
 * 1. achou o inicio da string que forma o 'mistake', mas nao concluiu
 * essa string (parou a leitura no meio, pois acabou a string inicial/ o espaco
 * de busca)
 * 2. algum char encontrado nao corresponde ao char do 'mistake' - significa
 * que nao achou, ali, um 'mistake', efetivamente.
 *
 */
int is_valid_search(text_t *initial_text, text_t *mistake, int i, int j) {
    if (i + j >= initial_text->size) {
        return FALSE;
    }

    if (initial_text->content[i + j] != mistake->content[j]) {
        return FALSE;
    }

    else {
        return TRUE;
    }
}

/*
 * Procura por um 'mistake' na string initial_txt. Nao encontrando nenhum,
 * retorna ERROR, o que significa que a string nao deve ser corrigida.
 * Se achou, por outro lado, uma correspondencia de erro, retorna a posicao i
 * da string inicial em que ele ocorre.
 *
 */
int find_mistake_position(text_t *initial_txt, text_t *mistake, int start_searching) {
    int match = FALSE;
    
    int i = start_searching;
    while (initial_txt->content[i] != '\0') {
        match = TRUE;
        
        int j = 0;
        while (mistake->content[j] != '\0' && match) {
            if (!is_valid_search(initial_txt, mistake, i, j)) {
                match = FALSE;
            }
            else {
                j++;
            }
        }

        if (match) {
            return i; 
        }
        else {
            i++;
        }
    }
    
    return ERROR;
}

/*
 * Aloca o espaco necessario para o novo texto. Ele corresponde a:
 * 1. o mesmo tamanho da string inicial, se nao ha 'mistakes'
 * 2. o tamanho da string inicial, retirando-se o 'mistake' e adicionando
 * espaco para a correcao.
 * Ha retorno de ERROR se o conteudo dentro da estrutura texto nao pode ser alocado.
 *
 */
int define_new_text_size(text_t *initial, text_t *mistake, text_t *to_replace, text_t *new, int start_searching) {
    if (find_mistake_position(initial, mistake, start_searching) == ERROR) {
        new->size = initial->size + 1;
        new->content = (unsigned char *) malloc((new->size) * sizeof(unsigned char));

        if (!new->content) {
            return ERROR;
        }
    }
    
    else {
        new->size = initial->size - mistake->size + to_replace->size + 1;
        new->content = (unsigned char *) malloc((new->size) * sizeof(unsigned char));

        if (!new->content) {
            return ERROR;
        }
    }

    return TRUE;
}

/*
 * Conserta um unico erro. Se nao houver 'mistakes', apenas copia
 * o conteudo inicial. Senao, busca a posicao de erro e copia o conteudo da nova
 * string em blocos. 
 * 1. Copia a string inicial ate a posicao do 'mistake';
 * 2. ignora, na string inicial, o espaco correspondente ao 'mistake';
 * 3. copia, na nova string, o conteudo da string de correcao.
 * 4. termina de copiar a string inicial.
 *
 */
text_t *fix_error(text_t *initial, text_t *mistake, text_t *to_replace, text_t *new, int *start_searching) {
    if (find_mistake_position(initial, mistake, *start_searching) == ERROR) {
        
        int i;
        for (i = 0; i <= initial->size; i++) {
            new->content[i] = initial->content[i];
        }

        if (!new->content) {
            return NULL;
        }
    }
    
    else {
        if (!new->content) {
            return NULL;
        }

        int mistake_position = find_mistake_position(initial, mistake, *start_searching);

        // para tratar casos em que erros sao iguais aos substitutos
        *start_searching = mistake_position + to_replace->size;

        int i;
        int j = 0;
        for (i = 0; i < mistake_position; i++,j++) {
            new->content[i] = initial->content[j];
        }

        j += mistake->size;

        for (int k = 0; k < to_replace->size; k++, i++) {
            new->content[i] = to_replace->content[k];
        }

        do {
            new->content[i] = initial->content[j];

            i++;
        } while (initial->content[j++] != '\0');

        new->content[--i] = '\0';
    }
    
    return new;
}

text_t *replace_text(text_t *initial, text_t *mistake, text_t *to_replace, text_t *new) {
    int start_searching = 0;
    
    // Alocar tudo aqui
    define_new_text_size(initial, mistake, to_replace, new, start_searching);        
    new = fix_error(initial, mistake, to_replace, new, &start_searching);
    
    // Se tiver mais de um 'mistake', realocar
    while (find_mistake_position(new, mistake, start_searching) != ERROR) {
        int update_size = initial->size - mistake->size + to_replace->size + 1;
        new->content = (unsigned char *) realloc(new->content, update_size * sizeof(unsigned char));
        new = fix_error(new, mistake, to_replace, new, &start_searching);
    }

    return new;
}

void print_text(text_t *text) {
    int i = 0;
    while (text->content[i] != '\0' && i < TXT_LIMIT) {
        printf("%c", text->content[i]);
        i++;
    }
    printf("\n");
}

int destroy_text(text_t **text) {
    if (!(*text)->content) { 
        return ERROR;
    }
    else {
        free((*text)->content); 
    }

    (*text)->content = NULL;

    if(!(*text)) {
        return ERROR;
    }

    free(*text);

    text = NULL;

    return TRUE;
}