/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * Exercicio 07 - Lista ordenada 
 * TAD linked list - implementacao
 */

#include <stdio.h>
#include <stdlib.h>
#include "linked_list.h"
#include "person.h"

typedef struct node node_t;

struct node {
    person_t *data;
    node_t *next;
};

struct list {
    node_t *head, *end;
    int size;
};

list_t *create() {
    list_t *l = (list_t *) malloc(sizeof(list_t));

    if (!l) {
        return NULL;
    }

    l->head = NULL;
    l->end = NULL;
    l->size = 0;

    return l;
}

int destroy(list_t **l) {
    if (*l) {
        node_t *p = (*l)->head;

        while (p) {
            (*l)->head = p->next;

            if (p->data) {
                destroy_person(&p->data);
            }

            free(p);
            p = (*l)->head;
        }

        free(*l);

        *l = NULL;

        return SUCCESS;
    }

    return ERROR;
}

int push_by_value(list_t *l, person_t *person) {
    if (!l) {
        return ERROR;
    }

    // Vamos inserir novo no para receber elemento x
    node_t *p = (node_t *) malloc(sizeof(node_t));

    p->data = person;
    p->next = NULL;

    // Se nao houver nenhum elemento na lista, este sera o primeiro.
    if (!l->head) {
        l->head = p;
        l->end = p;
    }

    // Se houver elementos na lista,

    // o codigo inserido agora eh o maior de todos? (ultimo elemento da lista)
    else if (get_code(l->end->data) < get_code(person)) {
        l->end->next = p;
        l->end = p;
    }

    // Inserir codigo no meio
    else {
        node_t *q = l->head;
        node_t *prev = NULL;

        // Achar posicao correta
        while (get_code(q->data) < get_code(person)) {
            prev = q;
            q = q->next;
        }
        
        // O menor codigo eh o que esta sendo adicionado? 
        if (!prev) {
            p->next = l->head;
            l->head = p;
        }

        else {
            prev->next = p;
            p->next = q;
        }
    }

    l->size++;

    return SUCCESS;
}

int size(list_t *l) {
    if (!l) {
        return ERROR;
    }

    return l->size;
}

void print_list(list_t *l) {
    node_t *p = l->head;
    while (p) {
        print_person_info(p->data);
        p = p->next;
    }

    printf("\n");
}

// Retornar valor retirado por referencia
int pop_by_value(list_t *l, person_t **person, int code_to_remove) {
    if (!l) {
        return ERROR;
    }

    node_t *prev = NULL;
    node_t *p = l->head;

    // Encontrar o elemento que desejamos remover
    while (p) {
        // Elemento encontrado:
        if (get_code(p->data) == code_to_remove) {
            // Devolvendo a info da pessoa para a main
            *person = p->data;

            // 1o caso: remover elemento do inicio, como uma fila
            if (!prev) {
                l->head = p->next;  // Mudar o inicio
            }

            // 2o caso: remover elemento do fim, como uma pilha
            else if (p == l->end) {
                l->end = prev;
                l->end->next = NULL;
            }

            // 3o caso: remover elemento do meio, desfazendo o no atual
            else {
                prev->next = p->next;
            }

            free(p); // Remover elemento atual da lista
            l->size--;

            return SUCCESS;
        }

        else {
            prev = p;
            p = p->next;
        }
    }

    return ERROR;
}

// Retornar elemento retirado por referencia
int pop_by_index(list_t *l, int index, person_t **person) {
    if (!l) {
        return ERROR;
    }

    if (index >= size(l) || index < 0) {
        return ERROR;
    }

    node_t *prev = NULL;
    node_t *p = l->head;
    
    // Encontrar o elemento que desejamos remover
    for (int i = 0; i < index; i++) {
        prev = p;
        p = p->next;
    }

    // Retornar o elemento por referencia
    *person = p->data;

    // 1. Se for do inicio, index == 0 e vamos retirar o l->head e modifica lo
    // para o elemento a seguir

    if (!prev) {
        l->head = p->next;
    }

    // 2. Se for do fim, index == list_size e vamos retirar o l->end e modifica lo
    // para o elemento anterior

    else if (p == l->end) {
        l->end = prev;
        l->end->next = NULL;
    }

    // 3. Se for do meio, 0 < index < list_size e vamos retirar um no qualquer
    // da lista, modificando o next do prev para tal

    else {
        prev->next = p->next;
    }

    free(p); // Remover elemento atual da lista
    l->size--;

    return SUCCESS;
}

int push_to_index(list_t *l, int index, person_t *person) {
    if (!l) {
        return ERROR;
    }

    // Receba indice valido
    if (index < 0) {
        return ERROR;
    }

    // Vamos inserir novo no para receber elemento x
    node_t *p = (node_t *) malloc(sizeof(node_t));

    p->data = person;
    p->next = NULL;

    // Se nao tiver nada na lista, sera o primeiro indice de qualquer modo
    if (!l->head) {
        l->head = p;
        l->end = p;
    } 
    else { 
        // Adicionar ao inicio da lista
        if (index == 0) {
            p->next = l->head;
            l->head = p;
        }

        // Adicionar ao final da lista
        else if (index > size(l) - 1) {
            l->end->next = p;
            l->end = p;
        }

        // Adicionar ao meio da lista
        else {
            node_t *prev = NULL;
            node_t *n = l->head;
            // Percorrer a lista ate chegar no indice desejado
            for (int i = 0; i < index; i++) {
                prev = n;
                n = n->next;
            }

            prev->next = p;
            p->next = n;
        }
    }

    l->size++;

    return SUCCESS;
}

void rotate_list(list_t *l) {
    // Lista ja esta rotacionada
    if (l->size <= 1) {
        return;
    }
    
    // Procurar o elemento por indice, ja que sempre
    // queremos dar pop no final
    person_t *element_to_pop;
    pop_by_index(l, size(l) - 1, &element_to_pop);

    // Vamos adicionar o elemento que retiramos ao inicio da lista
    push_to_index(l, 0, element_to_pop);
}

void reverse_aux(node_t *p, node_t *q, list_t *l) {
  // Caso base: percorri a lista e cheguei ao final dela
  if (!q) {             
    l->head->next = NULL;  // O inicio eh o novo fim

    // O anterior a ele eh o novo inicio da lista
    l->head = p;  // Nova cabeca/head da lista

    return;  // Voltar na recursao
  }

  // Primeiro, percorra a lista ate o final
  reverse_aux(p->next, q->next, l);

  // Depois que voltar da recursao:
  // O p precisa ser o proximo do q
  q->next = p;
}

void revert_list(list_t *l) {
  // Lista ja esta reversa
  if (l->size <= 1) {
    return;
  }

  node_t *p = l->head;
  node_t *q = l->head->next;

  // Chame f. auxiliar recursiva
  reverse_aux(p, q, l);
}

int search_list (list_t *l, int person_code) {
    if (!l) {
        return ERROR;
    }

    // Procurar pelo codigo. Ele ja existe na lista? Se sim, nao iremos
    // adiciona lo a lista
    node_t *p = l->head;
    
    int is_element_in_list = FALSE;
    while (p && !is_element_in_list) {
        if (get_code(p->data) == person_code) {
            is_element_in_list = TRUE;
        }

        else {
            p = p->next;
        }
    }

    return is_element_in_list;
}