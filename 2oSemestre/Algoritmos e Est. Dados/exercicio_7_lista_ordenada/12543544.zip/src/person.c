/*
 * Nome: Danielle Modesti
 * Node USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * Exercicio 07 - Lista ordenada 
 * TAD person - implementacao
 */

#define NAME_BUFFER 20

#include <stdio.h>
#include <stdlib.h>
#include "person.h"

struct person {
    char *name;
    int code;
};

person_t *create_person() {
    person_t *p = (person_t *) malloc(sizeof(person_t));  
  
    if(!p) {
        return NULL;
    }

    // Inicializando campos
    p->name = NULL;
    p->code = ERROR;

    return p;
}

int destroy_person(person_t **p) {
    if (*p) {               
        free((*p)->name);         
        (*p)->name = NULL;

        free(*p);
        *p = NULL;

        return TRUE;
    }

    return FALSE;
}

int read_person_name(person_t *p) {
    if (!p) {
        return FALSE;
    }
    
    int curr_char;
    int name_size = 0;

    // Consumir chars possivelmente restantes no buffer
    do {
        curr_char = getchar();
    } while (curr_char == '\r' || curr_char == '\n' || curr_char == ' ');

    // Devolver char se valido
    if (curr_char != EOF) {
        ungetc(curr_char, stdin);
    }
    
    p->name = (char *) malloc(NAME_BUFFER * sizeof(char));

    do {
        curr_char = getchar();
        name_size++;

        if (curr_char != '\r' && curr_char != '\n' && curr_char != EOF) {
            // Teste do buffer
            if (name_size % NAME_BUFFER == 0) {
                p->name = (char *) realloc(p->name, ((name_size / NAME_BUFFER + 1) * NAME_BUFFER) * sizeof(char));
            }

            p->name[name_size - 1] = curr_char;
        }

        else {
            p->name[name_size - 1] = '\0';
        }

    } while (curr_char != '\r' && curr_char != '\n' && curr_char != EOF);

    if (!p->name) {
        return ERROR;
    } 

    // Corrigir a alocacao
    p->name = (char *) realloc(p->name, name_size * sizeof(char));

    // Limpar o buffer
    do {
        curr_char = getchar();
    } while (curr_char == '\r' || curr_char == '\n' || curr_char == ' ');

    // Devolver char se valido
    if (curr_char != EOF) {
        ungetc(curr_char, stdin);
    }

    return TRUE;
}

int read_person_info(person_t *p) {
    scanf("%d ", &p->code);
    if (p->code == ERROR) {
        return ERROR;
    }

    read_person_name(p);

    return TRUE;
}

void print_person_info(person_t *p) {
    printf("%d, %s; ", p->code, p->name);
}

int get_code(person_t *p) {
    if (!p) {
        return ERROR;
    }

    int priority = p->code;

    return priority;
}