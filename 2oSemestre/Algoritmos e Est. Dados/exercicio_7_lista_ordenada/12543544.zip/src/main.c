/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * Exercicio 07 - Lista ordenada - aplicacao
 * 
 */

#define BUFFER_SIZE 20

#include <stdio.h>
#include <stdlib.h>
#include "linked_list.h"
#include "person.h"

typedef enum Option {
    INSERT_COMMAND = 2,
    REMOVE_COMMAND = 3,
    PRINT_INFO = 4
} option_t;

char *read_command();
int content_comparison(char *string_1, char *string_2);
int string_size(char *string);
int check_command_status(char *command);

int main() {
    list_t *l = create();

    char test_entry_end;
    while ((test_entry_end = getchar()) != EOF) {
        ungetc(test_entry_end, stdin);

        char *command = read_command();

        if (check_command_status(command) == INSERT_COMMAND) {
            person_t *p = create_person();
            read_person_info(p);

            // Verificacao - ja existe esse codigo na lista?
            if (search_list(l, get_code(p))) {
                printf("INVALIDO\n");
                destroy_person(&p);
            }

            else {
                push_by_value(l, p);
            }
        }

        else if (check_command_status(command) == REMOVE_COMMAND) {
            int code_to_remove;
            scanf("%d ", &code_to_remove);


            if (!search_list(l, code_to_remove)) {
                printf("INVALIDO\n");
            }

            else {
                person_t *p;
                pop_by_value(l, &p, code_to_remove);
                destroy_person(&p);
            }
        }

        else if (check_command_status(command) == PRINT_INFO) {
            if (size(l) == 0) {
                printf("VAZIA\n");
            }
            
            else {
                print_list(l);
            }
        }

        // Outros comandos sao invalidos.
        else {
            printf("INVALIDO\n");
        }

        free(command);
    }

    destroy(&l);

    return EXIT_SUCCESS;
}

char *read_command() {
    int curr_char;
    int command_size = 0;
    char *command = NULL;

    // Consumir chars possivelmente restantes no buffer
    do {
        curr_char = getchar();
    } while (curr_char == '\r' || curr_char == '\n' || curr_char == ' ');

    // Devolver char se valido
    if (curr_char != EOF) {
        ungetc(curr_char, stdin);
    }

    command = (char *) malloc(BUFFER_SIZE * sizeof(char));

    do {
        curr_char = getchar();
        command_size++;

        if (curr_char != ' ' && curr_char != '\r' && curr_char != '\n' && curr_char != EOF) {
            // Teste do buffer
            if (command_size % BUFFER_SIZE == 0) {
                command = (char *) realloc(command, ((command_size / BUFFER_SIZE + 1) * BUFFER_SIZE) * sizeof(char));
            }

            command[command_size - 1] = curr_char;
        }

        else {
            command[command_size - 1] = '\0';
        }

    } while (curr_char != ' ' && curr_char != '\r' && curr_char != '\n' && curr_char != EOF);

    if (!command) {
        return NULL;
    } 

    // Corrigir a alocacao
    command = (char *) realloc(command, command_size * sizeof(char));

    // Limpar novamente o buffer
    do {
        curr_char = getchar();
    } while (curr_char == '\r' || curr_char == '\n' || curr_char == ' ');

    // Devolver char se valido
    if (curr_char != EOF) {
        ungetc(curr_char, stdin);
    }

    return command;
}

int content_comparison(char *string_1, char *string_2) {
    int str_1_length, str_2_length;
    str_1_length = string_size(string_1);
    str_2_length = string_size(string_2);

    if (str_1_length != str_2_length) {
        return FALSE;
    }

    int i = 0;
    while (string_1[i] != '\0') {
        if (string_1[i] != string_2[i]) {
            return FALSE;
        }
        i++;
    }

    return TRUE;
}

int check_command_status(char *command) {
    if (content_comparison("REMOVE", command)) {
        return REMOVE_COMMAND; 
    }

    if (content_comparison("INSERE", command)) {
        return INSERT_COMMAND; 
    }

    if (content_comparison("IMPRIMIR", command)) {
        return PRINT_INFO; 
    }

    return ERROR;
}

int string_size(char *string) {
    int length = 0;
    while (string[length] != '\0') {
        length++;
    }

    return length;
}