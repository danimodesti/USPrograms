/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * Exercicio 07 - Lista ordenada 
 * TAD person - cabecalho [visao do usuario]
 */

#ifndef PERSON_H
#define PERSON_H

#define TRUE 1
#define FALSE 0
#define ERROR -1

typedef struct person person_t;  

/* 
 * Cria uma estrutura de pessoa, retornando-a.
 * Atribui NULL e ERROR aos conteudos da pessoa, ainda nao definidos.
 * Retorna NULL se nao foi possivel criar a estrutura pessoa.
*/
person_t *create_person();

/*
 * Libera memoria dinamicamente alocada para a estrutura pessoa e seu conteudo 
 * interno. Se isso ja ocorreu, retorna FALSE. 
 * Se for bem sucedido, atribui NULL ao conteudo da estrutura e a ela propria.
 * Retorna TRUE.
 */
int destroy_person(person_t **p);

/*
 * Preenche informacoes da estrutura pessoa: codigo e nome (pode conter sobrenome). Retorna 
 * ERROR se leitura mal sucedida. Retorna TRUE se bem sucedida.
 *
 */
int read_person_info(person_t *p);

void print_person_info(person_t *p);

/*
 * Com base no codigo de cada pessoa 'cadastrada' na lista, retorna a prioridade,
 * sendo os menores codigos os mais prioritarios para a ordem de elementos da
 * lista.
 */
int get_code(person_t *p);

#endif