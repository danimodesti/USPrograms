/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * TAD words - cabecalho
 * 
 */

#ifndef WORDS_H
#define WORDS_H

#define TRUE 1
#define FALSE 0
#define ERROR -1

typedef struct word word_t;

/*
 * Cria uma estrutura de palavra, retornando-a.
 * Atribui NULL ao conteudo de palavra, ainda nao definido.
 * Retorna NULL se nao foi possivel criar a estrutura palavra.
 */
word_t *create_word();

/*
 * Le uma palavra, conferindo conteudo a essa estrutura.
 * Se nao conseguir, retorna ERROR. Se conseguir,
 * retorna TRUE.
 */ 
int read_word(word_t *word, unsigned char *text, int *index_to_keep_on);

/*
 * Verifica se a leitura do conteudo de uma estrutura palavra
 * foi bem sucedida.
 */
int is_the_word_valid(int status);
void print_word(word_t *word);

/*
 * Libera memoria dinamicamente alocada para a estrutura palavra e seu conteudo 
 * interno. Se isso ja ocorreu, retorna ERROR. 
 * Se for bem sucedido, atribui NULL ao conteudo da estrutura e a ela propria.
 * Retorna TRUE.
 *
 */
int destroy_word(word_t **word);
int get_word_frequency(word_t *word);

/*
 * Compara a frequencia de duas palavras. Se retornar valor maior que zero,
 * a palavra 2 eh mais frequente. Se retornar zero, ambas as palavras tem mesma
 * frequencia. Se retornar valor menor que zero, a palavra 1 eh mais frequente.
 *
 */
int frequency_compare(word_t *word_1, word_t *word_2);
int get_word_length(word_t *word);
unsigned char *get_word(word_t *word);
void set_word_frequency(word_t *word);
int are_words_equal(word_t *word_1, word_t *word_2);

/*
 * Compara duas strings e retorna TRUE caso a string 2 venha antes da 1 na ASCII,
 * ou FALSE caso as strings sejam as mesmas ou a string 1 venha antes da 2 na ASCII (significa
 * que nao ha prioridade da string 2 em relacao a 1).
 */
int string_compare(unsigned char *string_1, unsigned char *string_2);

#endif