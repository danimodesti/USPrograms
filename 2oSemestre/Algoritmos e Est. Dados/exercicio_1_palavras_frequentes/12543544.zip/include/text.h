/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * TAD text - cabecalho
 * 
 */

#ifndef TEXT_H
#define TEXT_H

#include "words.h"

#define TRUE 1
#define FALSE 0
#define ERROR -1

typedef struct text text_t;

/*
 * Cria uma estrutura de texto, retornando-a.
 * Atribui NULL ao conteudo do texto, ainda nao definido.
 * Retorna NULL se nao foi possivel criar a estrutura texto.
 */
text_t *create_text();

/*
 * Le uma linha de texto, conferindo conteudo a essa estrutura.
 * Se nao conseguir, retorna ERROR. Se conseguir,
 * retorna TRUE.
 */ 
int read_text(text_t *text);

/*
 * Verifica se a leitura do conteudo de uma estrutura texto
 * foi bem sucedida.
 */
int is_the_line_valid(int status);

void print_text(text_t *text);

/*
 * Libera memoria dinamicamente alocada para a estrutura texto e seu conteudo 
 * interno. Se isso ja ocorreu, retorna ERROR. 
 * Se for bem sucedido, atribui NULL ao conteudo da estrutura e a ela propria.
 * Retorna TRUE.
 *
 */
int destroy_text(text_t **text);

/*
 * Retorna ERROR se alguma palavra lida da estrutura texto
 * nao for valida. Adiciona apenas palavras diferentes a lista
 * de palavras. Retorna TRUE se bem sucedida.
 *
 */
int create_word_list(text_t *text);

/*
 * Ordena as palavras com base em criterios de maior frequencia
 * e de ordem alfabetica (seguindo tabela ASCII estendida).
 *
 */
void ordenated_word_list(text_t *text);

/*
 * Considera a quantidade de palavras que o usuario quer printar e
 * que indica no comeco do programa e imprime ou essa quantidade ideal
 * de palavras ou as palavras existentes (quando a quantidade de palavras
 * na lista eh menor que a quantidade ideal de palavras a serem printadas).
 *
 */
void print_word_list(text_t *text, int ideal_word_amt_to_print);

#endif