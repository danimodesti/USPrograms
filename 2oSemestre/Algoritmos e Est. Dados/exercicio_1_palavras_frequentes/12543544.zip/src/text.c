/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * TAD text - implementacao
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include "text.h"
#include "words.h"

struct text {
    unsigned char *content; 
    int text_length;
    word_t **items; // lista de palavras no texto
    int word_amt;
};

text_t *create_text() {
    text_t *text = (text_t *) malloc(sizeof(text_t));

    if (!text) {
        return NULL;
    }

    text->content = NULL;
    text->text_length = 0;
    text->items = NULL;
    text->word_amt = 0;

    return text;
}

int read_text(text_t *text) {
    int curr_char;
    text->text_length = 0;
    text->content = (unsigned char *) malloc(sizeof(unsigned char));

    // isso soluciona a leitura de uma segunda linha caso a anterior termine em
    // \r, \r\n, \n e sobre um char escapado
    // se tiver \r ou \n sobrando, consuma os
    // isso trata fim de linha com \n, \r e \r\n
    do {
        curr_char = getchar();
    } while (curr_char == '\n' || curr_char == '\r');

    if (curr_char != EOF) {
        ungetc(curr_char, stdin); // devolve, pois eh um char valido para a line lida
                                  // entao passa pro read_line
    }

    do {
        curr_char = getchar();
        text->text_length++;
        text->content = (unsigned char *) realloc(text->content, text->text_length * sizeof(unsigned char));
        
        if (!text->content) {
            return ERROR;
        }

        if (curr_char != '\n' && curr_char != '\r' && curr_char != EOF) {
            text->content[text->text_length - 1] = curr_char;
        }
        else {
            text->content[text->text_length - 1] = '\0';
            text->text_length--;
        }
    } while (curr_char != '\n' && curr_char != '\r' && curr_char != EOF);

    return TRUE;
}

int is_the_line_valid(int status) {
    if (status == ERROR) {
        return FALSE;
    }

    else {
        return TRUE;
    }
}

void print_text(text_t *text) {
    printf("%s\n", text->content);
}

int destroy_text(text_t **text) {
    // Desalocar texto completo
    if (!(*text)->content) { 
        return ERROR;
    }
    else {
        free((*text)->content); 
    }

    (*text)->content = NULL;

    // Desalocar lista de palavras que formam o texto
    if ((*text)->items) {
        for (int i = 0; i < (*text)->word_amt; i++) {
            destroy_word(&(*text)->items[i]);
        }
        free((*text)->items);
    }

    // Desalocar o texto
    if(!(*text)) {
        return ERROR;
    }

    free(*text);

    text = NULL;

    return TRUE;
}

int is_the_word_in_list(text_t *text, word_t *word) {
    for (int i = 0; i < text->word_amt; i++) {
        if (are_words_equal(text->items[i], word)) {
            set_word_frequency(text->items[i]);

            return TRUE;
        }
    }

    return FALSE;
}

int create_word_list(text_t *text) {
    int i = 0;
    while (i <= text->text_length) {
        word_t *new_word = create_word();
        int is_word_valid = read_word(new_word, text->content, &i);

        if (!is_the_word_valid(is_word_valid)) {
            return ERROR;
        }

        if (is_the_word_in_list(text, new_word)) {
            destroy_word(&new_word);
        }

        else {
            text->word_amt++;
            text->items = (word_t **) realloc(text->items, (text->word_amt) * sizeof(word_t *));
            text->items[text->word_amt - 1] = new_word;
        }
    }

    return TRUE;
}

void print_word_list(text_t *text, int ideal_word_amt_to_print) {
    int words_to_print = text->word_amt;

    if (text->word_amt > ideal_word_amt_to_print) {
        words_to_print = ideal_word_amt_to_print;
    }
    
    for (int i = 0; i < words_to_print; i++) {
        print_word(text->items[i]);
        printf("%d", get_word_frequency(text->items[i]));
        printf("\n");
    }
}

// Criterios para ordenar. Se obtiver TRUE, faz o swap do insertion sort
int comparator(word_t *word_1, word_t *word_2) {
    if (frequency_compare(word_1, word_2) > 0) { // se o elemento atual da lista
                                                 // precisar ir para o comeco dela,
                                                 // trocando com o antecedente por 
                                                 // possuir maior frequencia que ele
        return TRUE;
    }

    // elementos com mesma frequencia. Ordenar por ordem alfabetica.
    else if (frequency_compare(word_1, word_2) == 0) {
        return string_compare(get_word(word_1), get_word(word_2));
    }

    // se nao tem frequencia maior nem igual, elemento fica pra tras para ser
    // printado sem prioridade. Nao faz swap.
    
    return FALSE;
}

void insertion_sort(text_t *text) {
	int i = 1;

	// Para cada elemento na lista desordenada
	while (i < text->word_amt) {		// Tamanho do vetor
		word_t *element = text->items[i]; // fixa elemento a ser comparado com anteriores
		int j = i - 1; // indice para percorrer elementos anteriores

		// enquanto houver elementos a serem comparados e o 
		// elemento for menor do que o anterior 
		while (j >= 0 && comparator(text->items[j], element)) {
			text->items[j + 1] = text->items[j]; // movimenta valor para frente
			j--; // indice retorna uma posicao
		}
		// encontrei a posicao correta
		text->items[j + 1] = element;

		i++;
	}
}

void ordenated_word_list(text_t *text) {
    insertion_sort(text);
}