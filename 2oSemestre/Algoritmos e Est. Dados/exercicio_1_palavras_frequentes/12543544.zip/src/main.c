/*
 * Nome: Danielle Modesti
 * No USP: 12543544
 * Disciplina: Algoritmos e Estruturas de Dados I - 2° semestre de 2021
 * Exercicio 01 - Palavras mais frequentes [aplicar o TAD text]
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include "text.h"

int main() {
    char is_EOF = '0';
    while (is_EOF != EOF) {
        text_t *text = create_text();

        if (!text) {
            return EXIT_FAILURE;
        }

        int is_valid_text = read_text(text);
        if (!is_the_line_valid(is_valid_text)) {
            return EXIT_FAILURE;
        }

        int most_frequent_words_amt;
        scanf("%d", &most_frequent_words_amt);
        is_EOF = getchar();

        create_word_list(text);
        ordenated_word_list(text);
        print_word_list(text, most_frequent_words_amt);
        
        if (is_EOF != EOF) {
            ungetc(is_EOF, stdin);  
            printf("\n");      
        }

        destroy_text(&text);
    }

    return EXIT_SUCCESS;
}