Arquivo zip gerado em: 25/10/2023 16:15:43 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [6 - Arquivos] Compilador JIT de Brainf*ck