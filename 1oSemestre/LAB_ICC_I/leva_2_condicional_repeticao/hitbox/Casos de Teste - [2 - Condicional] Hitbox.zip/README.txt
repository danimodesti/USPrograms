Arquivo zip gerado em: 25/10/2023 10:44:04 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [2 - Condicional] Hitbox