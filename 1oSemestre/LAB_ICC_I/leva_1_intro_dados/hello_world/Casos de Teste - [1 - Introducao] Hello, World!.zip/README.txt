Arquivo zip gerado em: 20/08/2023 10:25:40 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [1 - Introdução] Hello, World!