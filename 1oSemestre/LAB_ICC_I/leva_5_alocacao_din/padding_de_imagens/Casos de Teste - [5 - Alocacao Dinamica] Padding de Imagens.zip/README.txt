Arquivo zip gerado em: 25/10/2023 11:58:36 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [5 - Alocação Dinâmica] Padding de Imagens