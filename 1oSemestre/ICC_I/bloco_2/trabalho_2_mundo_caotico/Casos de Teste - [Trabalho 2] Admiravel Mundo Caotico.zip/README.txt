Arquivo zip gerado em: 31/01/2023 18:36:59 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [Trabalho 2] Admirável Mundo Caótico