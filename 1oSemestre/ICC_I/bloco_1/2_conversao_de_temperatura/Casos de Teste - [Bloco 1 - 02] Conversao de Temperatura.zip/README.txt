Arquivo zip gerado em: 31/01/2023 17:40:13 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [Bloco 1 - 02] Conversão de Temperatura