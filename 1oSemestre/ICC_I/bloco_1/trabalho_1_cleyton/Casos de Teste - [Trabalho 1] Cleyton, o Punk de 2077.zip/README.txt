Arquivo zip gerado em: 31/01/2023 18:28:52 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [Trabalho 1] Cleyton, o Punk de 2077