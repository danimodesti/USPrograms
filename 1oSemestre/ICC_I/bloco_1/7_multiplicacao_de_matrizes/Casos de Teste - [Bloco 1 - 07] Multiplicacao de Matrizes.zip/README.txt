Arquivo zip gerado em: 31/01/2023 17:58:02 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [Bloco 1 - 07] Multiplicação de Matrizes