from stable_marriage import *

def main():
    stable_marriage()

if __name__ == "__main__":
    main()