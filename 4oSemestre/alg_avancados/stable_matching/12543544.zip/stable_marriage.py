# Danielle Modesti - 12543544

from person import *

def stable_marriage():
    # Qtd de vezes em que sera necessario executar o algoritmo de stable marriage
    test_amt = int(input())

    for i in range(test_amt): 
        marriage_amt = int(input()) # Qtd de casais que devem ser formados nessa execucao

        # Todos os homens estao disponiveis
        available_men = list(range(1, marriage_amt + 1))
        
        # Leitura da entrada --
        women = []
        for i in range(marriage_amt):
            line = input().split()
            line.remove(line[0])
            preferences = list(map(int, line))
            women.append(Woman(i + 1, preferences))

            # Criar lista inversa para mulheres
            women[i].set_preferences_degrees()
        
        men = []
        for i in range(marriage_amt):
            line = input().split()
            line.remove(line[0])
            preferences = list(map(int, line))
            men.append(Man(i + 1, preferences))

        # Algoritmo do Stable Marriage --
        while len(available_men) > 0:
            curr_man = men[available_men[0] - 1]
            woman_to_propose = women[curr_man.get_preferences()[curr_man.get_proposal_counter()] - 1]

            curr_man.increase_proposal_counter()
            if woman_to_propose.get_engagement_state() is None:
                engage(curr_man, woman_to_propose, available_men)
            
            else:
                # Index = man / Value = preference degree
                decreasing_preference = woman_to_propose.get_preferences_degrees()
                fiance = woman_to_propose.get_engagement_state()

                if decreasing_preference[curr_man.get_id() - 1] < decreasing_preference[fiance - 1]:
                    engage(curr_man, woman_to_propose, available_men)
                    available_men.append(fiance)
                    men[fiance - 1].get_single()

        for couple in range(marriage_amt):
            print(men[couple].get_id(), men[couple].get_engagement_state())


def engage(man, woman, available_men):
    man.get_engaged(woman)
    available_men.pop(0) # Homem nao mais disponivel
    woman.get_engaged(man)    