class Person:
    def __init__(self, index: int, preferences: list):
        self.id = index
        self.engaged_with = None # Solteir@
        self.preferences = preferences

    def get_engaged(self, other):
        self.engaged_with = other.id

    def __str__(self):
        s = f"Pessoa {self.id}\nCasad@ com: {self.engaged_with}\n"
        s += f"Preferencias p/ casar (valores = pessoas): {self.preferences}\n"

        return s
    
    def get_engagement_state(self):
        return self.engaged_with

    def get_preferences(self):
        return self.preferences

    def get_id(self):
        return self.id

class Man(Person):
    def __init__(self, index, preferences):
        super().__init__(index, preferences)
        self.proposal_counter = 0 # Ainda nao pediu a mao de ninguem

    def increase_proposal_counter(self):
        self.proposal_counter = self.proposal_counter + 1

    def get_proposal_counter(self):
        return self.proposal_counter

    def get_single(self):
        self.engaged_with = None

class Woman(Person):
    def __init__(self, index, preferences):
        super().__init__(index, preferences)

        # Index = man / Value = preference
        self.preferences_degrees =  [None] * len(preferences)
    
    def set_preferences_degrees(self):
        for i in range(len(self.preferences)):
            self.preferences_degrees[int(self.preferences[i]) - 1] = i + 1

    def get_preferences_degrees(self):
        return self.preferences_degrees