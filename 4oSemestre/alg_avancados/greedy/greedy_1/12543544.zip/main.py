# Danielle Modesti - 12543544

from covering import *

def main():
    interval_covering()

if __name__ == "__main__":
    main()