from grass import Grass
from sprinkler import Sprinkler
from sorting import merge_sort
import sys

def interval_covering():
    while True:
        try: 
            line_info = input().split()

        except EOFError:
            break
        line_info = list(map(int, line_info))
        sprinkle_expected_amt = line_info[0]
        grass = Grass(line_info[1], line_info[2])

        sprinklers = [] # Ainda nao ordenados
        sprinkler_id = 1
        for i in range(sprinkle_expected_amt):
            line_info = input().split()
            sprinkler_data = list(map(int, line_info))

            # Condicao para que irrigue sem deixar 'pedacos' de fora: raio maior
            # que o tamanho vertical da grama
            if sprinkler_data[1] > grass.get_width() / 2:
                sprinklers.append(Sprinkler(sprinkler_id, sprinkler_data[1], sprinkler_data[0], grass.get_width()))
                sprinkler_id += 1

        # Caracteristica de metodo guloso: ordenar elementos primeiro -- 
        # como buscamos O(n log n), sera usado merge sort
        merge_sort(sprinklers, 0, len(sprinklers) - 1) # ordenando pelo ponto inicial de irrigacao

        chosen = True # em relacao a escolha dos sprinklers a cada loop
        while chosen is not False and grass.get_start_point() < grass.get_length():
            i = 0
            candidates = []
            best_index = None # Indice do melhor candidato

            while i < len(sprinklers) and sprinklers[i].get_start_point() <= grass.get_start_point():
                candidates.append(sprinklers[i])
                cur_sprinkler_end = sprinklers[i].get_end_point()
                # O melhor irrigador eh aquele que preenche a area mais amplamente
                if best_index is None or cur_sprinkler_end >= grass.get_length():
                    best_index = i
                i += 1

            if len(candidates) == 0:
                print("-1")
                chosen = False # Nenhum sprinkler foi escolhido, entao nao eh possivel irrigar tudo.
            else:
                # Dos candidatos, escolher mais amplo (maior fim) concentrando
                # os resultados desejados de pto inicial de irrigacao
                chosen = candidates[best_index]
                grass.increase_sprinkle_amt()
                grass.set_new_irrigation_start(chosen.get_end_point())
                sprinklers.remove(chosen)

        if chosen:
            print(grass.get_sprinkle_amt())