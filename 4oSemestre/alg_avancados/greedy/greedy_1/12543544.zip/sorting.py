from sprinkler import __le__

# Algoritmo de ordenacao O(n log n) - estrategia de divisao & conquista

def intercalate(array: list, left_bound: int, right_bound: int):
    # Uso extra de memoria
    aux = [0] * (right_bound - left_bound + 1)

    # Recalculo do centro
    center = (left_bound + right_bound) // 2 # Divisao inteira

    # Valores iniciais dos iteradores
    i = left_bound # iterador do subvetor esquerdo
    j = center + 1 # iterador do subvetor direito
    k = 0 # iterador do vetor auxiliar

    # Enquanto houver elementos das duas listas para serem comparados, faca-o
    while i <= center and j <= right_bound:
        if array[i] <= array[j]:
            aux[k] = array[i]
            i += 1
        else:
            aux[k] = array[j]
            j += 1

        k += 1

    # Terminar de preencher -> apenas um dos dois loops abaixo ocorre
    while i <= center:
        aux[k] = array[i]
        i += 1
        k += 1
    
    while j <= right_bound:
        aux[k] = array[j]
        j += 1
        k += 1

    
    # Copiar ordenado para o vetor original
    k = 0
    for i in range(left_bound, right_bound + 1):
        array[i] = aux[k]
        k += 1

def merge_sort(array: list, left_bound: int, right_bound: int):
    # Ja acabou a ordenacao. Caso-base: conquistar
    if right_bound <= left_bound:
        return

    # Dividir
    center = (left_bound + right_bound) // 2 # Divisao inteira, sem tomar o resto

    # Ordenar a primeira metade da lista
    merge_sort(array, left_bound, center)

    # Ordenar a segunda metade da lista
    merge_sort(array, center + 1, right_bound)

    # Intercalar - combinar as duas metades, ordenadas anteriormente, em um unico vetor
    # (tambem ordenado)
    intercalate(array, left_bound, right_bound)
