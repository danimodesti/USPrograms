class Grass:
    def __init__(self, length, width):
        self.length = length # Horizontal size (it represents 'end' of irrigation covering)
        self.width = width # Vertical size
        self.sprinkle_amt = 0
        self.start_irrigating = 0 # Irrigation begins covering here/this indicated point at each time

    def increase_sprinkle_amt(self):
        self.sprinkle_amt += 1

    def get_sprinkle_amt(self):
        return self.sprinkle_amt

    def get_width(self):
        return self.width

    def get_length(self):
        return self.length

    def get_start_point(self):
        return self.start_irrigating

    def set_new_irrigation_start(self, sprinkler_end_action):
        self.start_irrigating = sprinkler_end_action

    def __str__(self):
        s = f"Tamanho horizontal da grama: {self.length}\n"
        s += f"Tamanho vertical da grama: {self.width}\n"

        return s