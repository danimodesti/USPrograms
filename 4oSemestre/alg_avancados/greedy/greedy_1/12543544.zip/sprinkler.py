import math

class Sprinkler:
    def __init__(self, id, radius, center_pos, grass_width):
        self.id = id
        self.radius = radius
        self.center_pos = center_pos
        self.start_irrigating = center_pos - math.sqrt(radius ** 2 - (grass_width / 2) ** 2)
        self.end_irrigating = center_pos + math.sqrt(radius ** 2 - (grass_width / 2) ** 2)

    # Para ordenacao de sprinklers
    def __le__(self, other):
        return self.start_irrigating <= other.start_irrigating

    def __str__(self):
        s = f"Sprinkle {self.id}\n"
        s += f"Raio do irrigador: {self.radius}\n"
        s += f"Posição do centro: {self.center_pos}\n"
        s += f"Começo da irrigação em: {round(self.start_irrigating, 3)}\n"
        s += f"Fim da irrigação em: {round(self.end_irrigating, 3)}\n"

        return s

    def get_start_point(self):
        return self.start_irrigating

    def get_end_point(self):
        return self.end_irrigating