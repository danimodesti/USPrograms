from chamber import Chamber
from specimen import Specimen
from sorting import *

def load_balancing():
    case_counter = 1

    while True:
        try:
            line_info = list(map(int, input().split()))

        except EOFError:
            break

        chamber_amt = line_info[0]
        chambers = []
        for i in range(chamber_amt):
            chambers.append(Chamber(i + 1))

        specimen_amt = line_info[1]
        specimens = []
        spec_masses = list(map(int, input().split()))

        chamber_avg_mass = 0
        for i in range(specimen_amt):
            specimens.append(Specimen(spec_masses[i]))
            chamber_avg_mass += spec_masses[i]

        chamber_avg_mass /= chamber_amt

        # Ordenar de forma crescente as massas das especies
        merge_sort(specimens, 0, len(specimens) - 1)

        # Fazer o numero de especies ser 2 vezes o numero de jaulas, colocando
        # especies 'fantasma', de massa zero. Assim, eh possivel parear '2 a 2',
        # as especies em cada jaula. Os 'fantasmas', na pratica, nao sao animais
        # de verdade, mas ajudam a facilitar a logica do programa
        while len(specimens) < 2 * chamber_amt:
            specimens.insert(0, Specimen(0))

        print(f"Set #{case_counter}")
        IMBALANCE = 0
        for i in range(chamber_amt):
            chambers[i].add_specimen_inside(specimens[i])
            chambers[i].add_specimen_inside(specimens[len(specimens) - 1 - i])
            print(f" {i}: ", end="")
            for spec in chambers[i].get_specimens_contained():
                print(f"{spec.get_spec_mass()} ", end="")
            print()
            IMBALANCE += abs(chambers[i].get_total_mass() - chamber_avg_mass)

        print("IMBALANCE = {0:.5f}\n".format(IMBALANCE))
        case_counter += 1