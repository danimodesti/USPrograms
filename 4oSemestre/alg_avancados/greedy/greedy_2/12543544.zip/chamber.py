from specimen import Specimen

class Chamber:
    def __init__(self, id):
        self.id = id
        self.specimen_amt = 0
        self.total_mass = 0
        self.specimens_contained = [] # Referencia dos objetos Specimen dentro da jaula

    def increase_specimen_amt(self):
        self.specimen_amt += 1

    def add_specimen_inside(self, specimen: Specimen):
        if specimen.get_spec_mass() > 0:
            self.specimens_contained.append(specimen)
            self.increase_specimen_amt()
            self.set_total_mass(specimen.get_spec_mass())

    def get_specimens_contained(self):
        return self.specimens_contained

    def set_total_mass(self, new_specimen_mass):
        self.total_mass += new_specimen_mass

    def get_total_mass(self):
        return self.total_mass
    
    def __str__(self):
        s = f"JAULA {self.id}\n"
        s += f"Qtd. de especies contidas: {self.specimen_amt}\n"
        s += f"Massa total na jaula: {self.total_mass}\n\n"
        s += "\tESPECIES CONTIDAS\n"

        for spec in self.specimens_contained:
            s += "\t" + str(spec) + "\n"

        return s