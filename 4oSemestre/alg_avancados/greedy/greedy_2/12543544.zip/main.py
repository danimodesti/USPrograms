# Danielle Modesti - 12543544

from balancing import load_balancing

def main():
    load_balancing()

if __name__ == "__main__":
    main()