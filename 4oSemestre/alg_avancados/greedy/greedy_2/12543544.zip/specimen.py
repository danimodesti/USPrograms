class Specimen:
    def __init__(self, mass):
        self.mass = mass

    def __le__(self, other):
        return self.mass <= other.mass

    def get_spec_mass(self):
        return self.mass

    def __str__(self):
        s = f"Animal de massa {self.mass}"

        return s