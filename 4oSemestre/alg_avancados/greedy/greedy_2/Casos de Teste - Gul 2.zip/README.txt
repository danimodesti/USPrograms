Arquivo zip gerado em: 12/05/2023 14:29:03 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Gul 2