Arquivo zip gerado em: 12/05/2023 14:32:15 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: D&C 2